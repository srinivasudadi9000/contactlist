<?php 
include('dbconfig.php');
include('includes/dbconnection.php');

$res=$callConfig->deleteRecord(TPREFIX.TBL_CUSTOMER_LIST,'id',$_GET['id']);
if($res>0)
{
echo 1;
}
else
{
echo 0;
}
?>