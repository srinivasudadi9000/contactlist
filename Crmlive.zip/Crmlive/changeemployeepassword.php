<?php include "includes/header.php";
$userObj->checkloggedin();
include "includes/leftnav.php";


?>
<?php 
if($_POST['changePassword']== "Submit"){ 
//print_r($_POST);exit;

	$userObj->changeemployeePasswordNew($_POST);

}
$allemployee_list=$userObj->getemployeelist(); 

?>
 <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
         Change Employee  Password
           
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Change Employee Password</li>
          </ol>
          
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-6"  style="width:72%;" >
              <!-- general form elements -->
              <div class="box box-primary">
                <!-- /.box-header -->
                <!-- form start -->
                 <?php 
                         if($_GET['err']!="")
                          {
						  	echo '<p class="index_suc">'.$_GET['err'].'</p>';
							//unset($_SESSION['err']);
						  
						  }
						  else if($_GET['ferr']!="")
						  {
							echo '<p class="index_err">'.$_GET['ferr'].'</p>';
							//unset($_SESSION['ferr']);
						  }
						  ?>
              <form id="changenewpassword" name="changenewpassword" method="post" action="" onSubmit="return validate();">
                  <div class="box-body">
                  <div class="form">
                  
                   <div class="form-group">
                      <label for="exampleInputPassword1" class="fieldname">EmployeeList</label>
                     <select class="form-control fieldtype" id="employeelist" name="employeelist"><option value="Select">Select</option>
                     <?php foreach($allemployee_list as $single)
					{
					?>
                    <option value="<?php echo $single->id;?>"><?php echo $single->username;?></option>
                    <?php } ?>
                     </select>
                     
                      <div style="width:100%; clear:both;"></div>
                    </div>
                       <!--<div class="form-group">
                      <label for="exampleInputPassword1" class="fieldname">Old Password</label>
                      <input type="password" class="form-control fieldtype" id="oldpassword" name="oldpassword" >
                     
                      <div style="width:100%; clear:both;"></div>
                    </div>-->
                    
                       <div class="form-group">
                      <label for="exampleInputPassword1" class="fieldname">New Password</label>
                      <input type="password" class="form-control fieldtype" id="newpassword" name="newpassword" >
                
                      <div style="width:100%; clear:both;"></div>
                    </div>
                    
                    <div class="form-group">
                      <label for="exampleInputPassword1" class="fieldname">Confirm Password</label>
                      <input type="password" class="form-control fieldtype" id="confirmpassword" name="confirmpassword" >
                      <?php //echo $now = time();?>
                   
                      <div style="width:100%; clear:both;"></div>
                      
                    </div>
                    
         
                     
                    
                    
                    </div>
                  </div><!-- /.box-body -->

                  <div class="box-footer">
                    <button type="submit" class="btn btn-primary" value="Submit" name="changePassword">Submit</button>
                  </div>
                </form>
              </div><!-- /.box -->

              <!-- Form Element sizes -->
              <!-- /.box -->

              <!-- /.box -->

              <!-- Input addon -->
              <!-- /.box -->

            </div><!--/.col (left) -->
                 <?php include('includes/rightnav.php'); ?>
            <!-- right column -->
            <!--/.col (right) -->
          </div>   <!-- /.row -->
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
<?php include "includes/footer.php"?>

<script type="text/javascript">
function validate()
{
	 
 if(document.changenewpassword.oldpassword.value=="")
	{
		alert("Please enter oldpassword");
		document.changenewpassword.oldpassword.value='';
		document.changenewpassword.oldpassword.focus();
		return false;
		
	}
	 var y=document.changenewpassword.newpassword.value;
	if (y=="")
	{
	document.changenewpassword.newpassword.focus();
	alert("Please enter the New Password");
	return false;
	}
	 var z=document.changenewpassword.confirmpassword.value;
	if (z=="")
	{
		document.changenewpassword.confirmpassword.focus();
	alert("Please enter the Confirm Password");
	return false;
	}
	var z=document.changenewpassword.confirmpassword.value;
	if (z!=y)
	{
	document.changenewpassword.confirmpassword.focus();	
	alert("Please check and Re Enter Password");
	return false;
	}
	
	return true;
	
}
</script>