<?php

require_once 'excel/reader.php';

if($_POST['import']=='Import Excel File')

{

//print_r($_POST); exit;

  $str='';

  $data = new Spreadsheet_Excel_Reader();

  $data->setOutputEncoding('CP1251');

  $data->read($_FILES['excel_file']['tmp_name']);

	error_reporting(E_ALL ^ E_NOTICE);

	

	

	 for ($i = 2; $i <= $data->sheets[0]['numRows']; $i++) {

		 $ques=array();

		for ($j = 1; $j <= $data->sheets[0]['numCols']; $j++) {

		   /* if($str=='')

			$str=$data->sheets[0]['cells'][$i][$j];

		    else

			$str=$str.",".$data->sheets[0]['cells'][$i][$j];*/

			//$str=$str.",<a href='view_products.php?id=".$rs->id."'>".$data->sheets[0]['cells'][$i][$j]."</a>;

			

			$ques[]=$data->sheets[0]['cells'][$i][$j];

		}

		//print_r($ques); die;

	 if(count($ques)>0)

	 {

		// print_r($ques); exit;

	    //$ques=explode(",", $str);

		//5

		$address=$ques[3]."\n";

		$address.=$ques[4]."\n";

		$address.=$ques[5];

		/*if(substr($ques[9],0,1)=="0")

		{

			

			$phone_number=$ques[9];

		} 

		else

		{

			$phone_number="0".$ques[9];

	

		}*/

		

		//echo $phone_number;

/* $fieldnames=array('title'=>$ques[0],'firstname'=>mysql_real_escape_string($ques[1]),'lastname'=>mysql_real_escape_string($ques[2]),'address'=>$address,'town'=>$ques[6],'country'=>$ques[7],'postcode'=>$ques[8],'shares'=>$ques[9],'company'=>$ques[10],'market'=>$ques[11],

'industry'=>$ques[12],'phone_number'=>$phone_number,'mobile_number'=>$ques[14],'sheetname'=>$ques[16],'status'=>'','email'=>$ques[15]); */

			

			

			/*$query="insert into crm_customer_list (title,email,firstname,lastname,phone_number,comments,status,address,mobile_number,town,company,country,postcode,shares,market,industry,sheetname,listname) values ('".$ques[0]."','','".mysql_real_escape_string($ques[1])."','".mysql_real_escape_string($ques[2])."','".$phone_number."','','','".$address."',' ','".$ques[6].

			"','$ques[9]','$ques[7]','$ques[8]','$ques[10]','$ques[11]','','$ques[12]','$ques[13]')";*/
			
			$query="insert into crm_customer_list (title,email,firstname,lastname,phone_number,comments,status,address,mobile_number,town,company,country,postcode,shares,market,industry,sheetname,listname) values ('".$ques[0]."',
		'',
		'".mysql_real_escape_string($ques[1])."',
		'".mysql_real_escape_string($ques[2])."',
		'".$ques[9]."',
		'',
		'',
		'".$address."',
		'',
		'',
		'".$ques[8]."',
		'".$ques[6]."',
		'".$ques[7]."',
		'',
		'',
		'',
		'',
		'')";

		//echo $query; exit; 

		mysql_query($query);

		$resid=mysql_insert_id();

			//print_r($fieldnames); exit;

			//$res=$callConfig->insertRecord(TPREFIX.TBL_CUSTOMER_LIST,$fieldnames);

			

			

		//$str='';

		if($ques[17]!="")

		{

		$commentslist=array('name'=>"admin",'comments'=>mysql_real_escape_string($ques[17]),'emp_id'=>$resid);

		

		$res=$callConfig->insertRecord(TPREFIX.TBL_COMMENTS_LIST,$commentslist);

		}

		//print_r($);

			  

	 }

	//if( 'lotnumber'!= "" ){

		

	

	}

	

	header("location:".SITEURL."/Leads/1?err=Imported successfully");

	

}





?>

<script>

function validate_excel()

{

   var valid_extensions = /(.xls)$/i; 

   

  if(document.frmexcel.excel_file.value=='')

  {

     alert("Please upload a excel file");

	 document.frmexcel.excel_file.focus();

	 return false;

  }

    else if(!valid_extensions.test(document.frmexcel.excel_file.value))

  { 

    alert("Please Upload .xls  file only for Ex:97-2003 save copy Execl ");

	 document.frmexcel.excel_file.focus();

	 return false;

  }

}

</script>

   

            

 



  <!--Logmiddlewrape-->

            





                     

                          <!--End left-->

                          

                          <!--right-->

                

                            

         <form action="" method="post" name="frmexcel" onSubmit="return validate_excel();" enctype="multipart/form-data">



<input type="file" name="excel_file" />



<input type="submit" name="import" value="Import Excel File"  class="import" />



<input type="hidden" name="book_id" value="<?=$_GET['id']?>" />

</form>    



              