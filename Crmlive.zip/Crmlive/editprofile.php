<?php include("includes/header.php");
 include("includes/leftnav.php");
     
	
        $profile=$userObj->getprofilelist($_SESSION['id']);
	$profile1=$userObj->getprofile1list($_SESSION['id']);
	//print_r($profile);die;
	
if($_POST['submit']=="Update")
{//print_r($_FILES);
//print_r($_POST);exit;
//$id=$_GET['id'];

$update=$userObj->UpdateuserProfile($_POST);
//print_r($update);die;

}
?>
	<?php	global $callConfig;
     if($_POST['submited']=='Update'){
	//$psswd = $callConfig->passwordEncrypt($_POST['password']);
	  $quer="update crm_user_login set firstname='".$_POST['firstname']."',lastname='".$_POST['lastname']."',disname='".$_POST['dname']."',email='".$_POST['email']."',address='".$_POST['address']."',phonenumber='".$_POST['phonenumber']."',mobilenumber='".$_POST['mobilenumber']."' where id='".$_POST['hdn_id']."'";
	  //echo $quer; exit;
	 $result=mysql_query($quer);
	if($result){ 
	?>
	<script>
	alert("Updated Successfully");
	</script>
	<?php } 
	$callConfig->headerRedirect("employeelistview.php?id=".$_POST['hdn_id']); 	
	} ?>
	<?php  
	$qq=mysql_query("select * from crm_user_login where id='".$_GET['id']."'");
				           $profile=mysql_fetch_object($qq); 
						   //print_r($res);exit;
		?>
         <script type="text/javascript">
        function checkemail(value)
		{//alert("dgfasgdh");
			 
		var xmlhttp;
        if (window.XMLHttpRequest)
          {// code for IE7+, Firefox, Chrome, Opera, Safari
          xmlhttp=new XMLHttpRequest();
          }
        else
          {// code for IE6, IE5
          xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
          }
        xmlhttp.onreadystatechange=function()
        {
          if (xmlhttp.readyState==4 && xmlhttp.status==200)
          {
			  //alert(xmlhttp.responseText);

            var res=xmlhttp.responseText;
			if(res==1){
				document.getElementById("display").innerHTML="Email already exists";
				document.customer.email.value="";
				document.customer.email.focus();
			}
			else{
				document.getElementById("display").innerHTML="";
			}
			
			  }
          }
        xmlhttp.open("GET","checkusemail.php?emailid="+value,true);
		//alert("first");
		
        xmlhttp.send();
		
		}
		
	
		
	
</script>
    <div class="wrapper">
      
      


      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12" style="width:72%;">
              <!-- /.box -->
<div class="box">
 <div class="box-header">
                  <h3 class="box-title">Edit Employee Details</h3>
                </div>
<form method="post"  name="customer" action="" onSubmit="return validate();">
<div style="border:0px solid #d3d3d3;margin:auto; min-height:826px;" >
  <table style="position:relative;margin:15px ;color:#2f4f4f;font-family:calibri;padding-left:120px;padding-top:15px;">
   
       <tr>
      <td class="tablespacing1"><label>First Name:</label></td>
      <td class="tablespacing"><input type="text" name="firstname" class="inputfieldswrap" id="firstname" value="<?php echo $profile->firstname;?>">
        
    </tr>
       
        <tr>
            <td class="tablespacing1"><label>Last Name:</label></td>
            <td class="tablespacing"><input type="text" name="lastname" class="inputfieldswrap" id="lastname" value="<?php echo $profile->lastname;?>">
             
        </tr>
		<tr>
            <td class="tablespacing1"><label>Display Name:</label></td>
            <td class="tablespacing"><input type="text" name="dname" class="inputfieldswrap" id="dname" value="<?php echo $profile->disname;?>">
             
        </tr>
        <tr>
            <td class="tablespacing1"><label >Email:</label></td>
            <td class="tablespacing"><input type="text" class="text_large required inputfieldswrap"  name="email" id="email" value="<?php echo $profile->email;?>" onChange="return checkemail(this.value);">
            <label id="display" style="color:#F00; font-size:16px;padding:0px 0px 0px 0px;"></label>
             
            
        </tr>
        <tr>
            <td class="tablespacing1"><label>Mobile Number:</label></td>
            <td class="tablespacing"><input type="text" name="mobilenumber" class="inputfieldswrap" id="mobilenumber"  value="<?php echo $profile->mobilenumber;?>" />
             
        </tr>
         <tr>
            <td class="tablespacing1"><label>Phone Number:</label></td>
            <td class="tablespacing"><input type="text" name="phonenumber" class="inputfieldswrap" id="phonenumber" value="<?php echo $profile->phonenumber;?>"  />
			
             </td>
        </tr>
         <tr>
            <td class="tablespacing1"><label>Address:</label></td>
            <td class="tablespacing">
            <textarea name="address" id="address"class="inputfields1wrap" rows="6" cols="36" /><?php echo $profile->address;?></textarea>
                    </tr>
        
        <tr>
        	<td class="tablespacing1"></td>
			<input type="hidden" name="hdn_id" id="hdn_id" value="<?php echo $profile->id;?>">
			<td class="tablespacing">
           <div class="reg_btn"><input type="submit" name="submited"  class="btn btn-primary" value="Update" style="width:100px;margin-top:20px;"></div>
            </td>
            
                              
                                <div class="clear_fix"></div>
                              
            </td>
        </tr>
    </table>
    </div>
</form>
</div>
              <!-- /.row -->
          </div>
             <?php include("includes/rightnav.php"); ?>
          </div>
        </section><!-- /.content -->

      </div><!-- /.content-wrapper -->
     
    </div><!-- ./wrapper -->





<script type="text/javascript">
function validate()
{
	 
 if(document.customer.firstname.value=="")
	{
		alert("Please enter firstname");
		document.customer.firstname.value='';
		document.customer.firstname.focus();
		return false;
		
	}
	
 	 if(document.customer.lastname.value=="")
	{
		alert("Please enter lastname");
		document.customer.lastname.value='';
		document.customer.lastname.focus();
		return false;
		
	}
	
	 var phoneno1 = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/; 	
 	 if(document.customer.mobilenumber.value.match(phoneno1)==null)
	{
		alert("Please enter mobilenumber");
		document.customer.mobilenumber.value='';
		document.customer.mobilenumber.focus();
		return false;
		
	}
	 var phoneno = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/; 	
 	 if(document.customer.phonenumber.value.match(phoneno)==null)
	{
		alert("Please enter phonenumber");
		document.customer.phonenumber.value='';
		document.customer.phonenumber.focus();
		return false;
		
	}
		
 	 if(document.customer.address.value=="")
	{
		alert("Please enter address");
		document.customer.address.value='';
		document.customer.address.focus();
		return false;
		
	}
	
	
	return true;
	
}
</script>
<?php include("includes/footer.php");?> 