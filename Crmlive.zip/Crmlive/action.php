<?php
error_reporting(0);
//include('dbconfig.php');
//include("model/user.class.php");
//$userObj=new userClass();


//print_r($_POST);
session_start();
$connection=mysql_connect("localhost",'ky1ecrmn_user','migratecrm@123');
$db=mysql_select_db('ky1ecrmn_migratedatabase',$connection);
//echo "SELECT * FROM crm_leads_notes where user_id=".$_SESSION['id'];
$check = mysql_num_rows(mysql_query("SELECT * FROM crm_leads_notes where user_id=".$_SESSION['id']));
//echo $check;
if($check>0)
	{
		if($_POST['hidden_tab1']=="tab1")
			{
				//echo werr;
				$content=mysql_real_escape_string($_POST['content_tab1']);
							
				$res=mysql_query("update crm_leads_notes set content_tab1='".$content."' where user_id=".$_SESSION['id']);
				$tab1=mysql_fetch_object(mysql_query("SELECT * from crm_leads_notes WHERE  user_id=".$_SESSION['id']));
				
				echo $tab1->content_tab1; 
				
			}
		elseif($_POST['hidden_tab2']=="tab2")
			{
				$content=mysql_real_escape_string($_POST['content_tab2']);
				$insert1=mysql_query("update crm_leads_notes set content_tab2='".$content."' where user_id=".$_SESSION['id']);
				$tab2=mysql_fetch_object(mysql_query("SELECT * from crm_leads_notes WHERE user_id=".$_SESSION['id']));
			     
			echo $tab2->content_tab2;
			}
			
		
		elseif($_POST['hidden_tab3']=="tab3")
			{
				$content=mysql_real_escape_string($_POST['content_tab3']);
				 $insert2=mysql_query("update crm_leads_notes set content_tab3='".$content."' where user_id=".$_SESSION['id']);
				$tab3=mysql_fetch_object(mysql_query("SELECT * from crm_leads_notes WHERE user_id=".$_SESSION['id']));
			     
				echo $tab3->content_tab3;
			}	
					elseif($_POST['hidden_tab4']=="tab4")
			{
				$content=mysql_real_escape_string($_POST['content_tab4']);
				 $insert2=mysql_query("update crm_leads_notes set content_tab4='".$content."' where user_id=".$_SESSION['id']);
				$tab4=mysql_fetch_object(mysql_query("SELECT * from crm_leads_notes WHERE user_id=".$_SESSION['id']));
			     
				echo $tab4->content_tab4;
			}
	         elseif($_POST['hidden_tab5']=="tab5")
			{
				$content=mysql_real_escape_string($_POST['content_tab5']);
				 $insert2=mysql_query("update crm_leads_notes set content_tab5='".$content."' where user_id=".$_SESSION['id']);
				$tab5=mysql_fetch_object(mysql_query("SELECT * from crm_leads_notes WHERE user_id=".$_SESSION['id']));
			     
				echo $tab5->content_tab5;
			}
			elseif($_POST['hidden_tab6']=="tab6")
			{
				$content=mysql_real_escape_string($_POST['content_tab6']);
				 $insert2=mysql_query("update crm_leads_notes set content_tab6='".$content."' where user_id=".$_SESSION['id']);
				$tab6=mysql_fetch_object(mysql_query("SELECT * from crm_leads_notes WHERE user_id=".$_SESSION['id']));
			     
				echo $tab6->content_tab6;
			}
	}
else
	{
	if($_POST['hidden_tab1']=="tab1")
		{
			$content=mysql_real_escape_string($_POST['content_tab1']);
			 $res=mysql_query("insert into crm_leads_notes (content_tab1,user_id) values('$content',".$_SESSION['id'].")");
			
			$tab1=mysql_fetch_object(mysql_query("SELECT * from crm_leads_notes WHERE  user_id=".$_SESSION['id']));
				
				echo  $tab1->content_tab1; 
			
		//; $res; exit;
			
		}
	elseif($_POST['hidden_tab2']=="tab2")
		{
			$content=mysql_real_escape_string($_POST['content_tab2']);
		   $insert1=mysql_query("insert into crm_leads_notes (content_tab2,user_id) values('$content',".$_SESSION['id'].")"); 
		    
			$tab2=mysql_fetch_object(mysql_query("SELECT * from crm_leads_notes WHERE user_id=".$_SESSION['id']));
			     
				echo  $tab2->content_tab2;
		
		}
	
	elseif($_POST['hidden_tab3']=="tab3")
		{
			$content=mysql_real_escape_string($_POST['content_tab3']);
			$insert2=mysql_query("insert into crm_leads_notes (content_tab3,user_id) values('$content',".$_SESSION['id'].")");
			
			$tab3=mysql_fetch_object(mysql_query("SELECT * from crm_leads_notes WHERE user_id=".$_SESSION['id']));
			     
				 echo $tab3->content_tab3;
			
		}	
		elseif($_POST['hidden_tab4']=="tab4")
		{
			$content=mysql_real_escape_string($_POST['content_tab4']);
			$insert2=mysql_query("insert into crm_leads_notes (content_tab4,user_id) values('$content',".$_SESSION['id'].")");
			
			$tab4=mysql_fetch_object(mysql_query("SELECT * from crm_leads_notes WHERE user_id=".$_SESSION['id']));
			     
				 echo $tab4->content_tab4;
			
		}
		elseif($_POST['hidden_tab5']=="tab5")
		{
			$content=mysql_real_escape_string($_POST['content_tab5']);
			$insert2=mysql_query("insert into crm_leads_notes (content_tab5,user_id) values('$content',".$_SESSION['id'].")");
			
			$tab5=mysql_fetch_object(mysql_query("SELECT * from crm_leads_notes WHERE user_id=".$_SESSION['id']));
			     
				 echo $tab5->content_tab5;
			
		}
		elseif($_POST['hidden_tab6']=="tab6")
		{
			$content=mysql_real_escape_string($_POST['content_tab6']);
			$insert2=mysql_query("insert into crm_leads_notes (content_tab6,user_id) values('$content',".$_SESSION['id'].")");
			
			$tab6=mysql_fetch_object(mysql_query("SELECT * from crm_leads_notes WHERE user_id=".$_SESSION['id']));
			     
				 echo $tab6->content_tab6;
			
		}
	}


?>

	