<?php include("includes/header.php");

include("includes/leftnav.php");

$userObj->checkloggedin();

//print $_GET['eid']; exit;

$rec_count=$userObj->getAllAssignleedslistCount($_GET['eid']);

$limit = 200;

isset($_GET['page'])?$page=$_GET['page']:$page=1;

$start = (($page-1)*$limit);	



//echo $rec_count;

$pagecount = ceil($rec_count/$limit);

//echo $pagecount;

//$data =$frontObj->getallnewsdata($start,$limit); 



$allleads=$userObj->getAllAssignleedslist($start,$limit,$_GET['eid']);

//print "<pre>";

//print_r($allleads);

$allemployees=$userObj->getAllemployeeslist();

//print "<pre>";

//print_r($allemployees);

if($_POST['delete']=="Delete")

{

	$userObj->deleteLeedFromUser($_POST);

	//print_r($_POST);

	//exit;

}

if ($_POST['submit']=='submit') {

	//print_r($_POST); exit; 

	$userObj->asignToEmployee($_POST);

	}

?>

<script>

function gotoRequiredPage(pageId){



	window.location.replace("<?php print SITEURL ?>/AssignLeadsView/<?php echo $_GET['eid'] ?>?page="+pageId);

	}

</script>

<script type="text/javascript">

$(function() {

setTimeout(function() { $(".index_suc").fadeOut(1500); }, 5000)

setTimeout(function() { $(".index_err").fadeOut(1500); }, 5000)

});

</script>

<script>

function checkEmp(){

	

	if(document.getElementById("employeename").value=='')

  {

     alert("Please Select Employee");

	 document.leedlist.employeename.focus;

	 return false;

  }

	

	if( $('input[name="leadsid[]"]:checked').length == 0 )

    {

        alert("You must check atleast one Leed to assign");

        return false;

    }



	}

</script>



        

            <!-- left column -->

            <div class="col-md-6">

              <!-- general form elements -->

             

                <!-- /.box-header -->

                <!-- form start -->

              <div class="content-wrapper">

        <!-- Content Header (Page header) -->

        <section class="content-header">

          <h1>

           LEADS LIST

          

          </h1>

          <!--<ol class="breadcrumb">

            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>

            <li><a href="#">Tables</a></li>

            <li class="active">Data tables</li>

          </ol>-->

        </section>



        <!-- Main content -->

        <section class="content">

          <div class="row">

            <div class="col-xs-12">

                          <div class="box">

                <div class="box-header">

                    <script type="text/javascript" src="<?php print SITEURL?>/js/checkuncheckall.js"></script>

                  <h3 class="box-title"><span style="margin-left:10px;"><img src="<?php print SITEURL?>/images/leeds_list new.png"><b style="margin-left:10px;">LEADS LIST</b></span></h3>

                    <form name="leedlist" method="post" action="" >

                   <div  style="float:right;">

                   

                     <input type="button" id="submit" value="Back" class="btn btn-primary" style="width:100px;margin-left:0px;"  onclick="window.location.href='<?php print SITEURL?>/EmployeeList'">

                     </div>

                              <?php 

                         if($_GET['err']!="")

                          {

						  	echo '<p class="index_suc">'.$_GET['err'].'</p>';

							//unset($_SESSION['err']);

						  

						  }

						  else if($_GET['ferr']!="")

						  {

							echo '<p class="index_err">'.$_GET['ferr'].'</p>';

							//unset($_SESSION['ferr']);

						  }

						  ?>

                          </h3>

                </div><!-- /.box-header -->

                

                <div class="box-body">

                 <table cellpadding="3px" cellspacing="1px" width="100%" border="0" style="">

					   <tr>

					   <td colspan="5" style="text-align:right; padding-bottom:10px;"><input type="submit" name="delete" value="Delete" class="btn btn-primary" style="width:100px;"/></td>

					   </tr>

					   </table>

                  <table id="example1" class="table table-bordered table-striped">

                    <thead>

                      <tr>

						<th align="left">Lead Name</th>

                        <th align="left">Email</th>

						<th align="left">company</th>

                        <th align="left">Phone Number</th>

                        <th align="left">Status</th>

                        <th align="center">

						<input type="checkbox" name="check" id="check" value="" onclick="checkAlluncheckAll('leedlist', 'leadsid')"/><label for="check" onclick="test();">&nbsp;</label>

                        

						 </th>

                      </tr>

                    </thead>

                    <tbody>

                         <?php

					    $ii=0;

						if(!empty($allleads))

						{

					    foreach($allleads as $all_leads) {

							//print_r($all_leads);

                       $userDetails=$userObj->getUserDetails($all_leads->user_id);

					   if($ii%2==0)

					   {

						   $color="even";

						}

						else

						{

							$color="odd";

						}

					   ?>

                      <tr class=<?php print $color;?>>

                 

                       <td align="left" style="width:30%;" ><?php echo "<p style='width:100%;word-wrap:break-word;'>".$all_leads->title ." ".$all_leads->firstname." ".$all_leads->lastname; "</p>"?></td>

             <td align="left" style="width:15%;" ><?php echo "<p style='width:100%;word-wrap:break-word;'>". $all_leads->email;"</p>"?></td>

                        <td align="left" style="width:15%;" ><?php echo "<p style='width:100%;word-wrap:break-word;'>". $all_leads->company;"</p>"?></td>

						<td align="center" style="width:30%;" ><?php echo "<p style='width:100%;word-wrap:break-word;'>+44". substr($all_leads->phone_number,1);"</p>"?></td>

                      	<td align="center"><?php print $all_leads->status?> </td>

						 <td align='center' width="25%" >

                        <input type="checkbox" name="leadsid[]" value="<?php print $all_leads->id?>" id="leadsid" /></td> 

                      </tr>

                     

                    <?php

					   $ii++;

					    }

						}

						else

						{

							?>

                            <tr>

                            	<td colspan="5"> No Leads</td>

                            </tr>

                            <?php 

						}

						?>

                   

                        

                    </tbody>

                  </table>

                  </div>

                        <?php

					echo '<div class="pagclass">';

					echo pagination($rec_count,$limit,$pagecount,$page,$start);

					echo '</div>'; 

					?>

                       </form>

              

                </div><!-- /.box-body -->

              </div><!-- /.box -->

            </div><!-- /.col -->

            </section>

          </div><!-- /.row -->

  

      </div>

             



              <!-- Form Element sizes -->

              <!-- /.box -->



              <!-- /.box -->



              <!-- Input addon -->

              <!-- /.box -->



            </div><!--/.col (left) -->

            <!-- right column -->

            <!--/.col (right) -->

          </div>   <!-- /.row -->

        </section>

<?php 

function pagination($no_of_rows,$limit,$pagecount,$page,$start)

{

	if($pagecount>1)

	{

		if($page!=1){

			$pre=$_GET['page']-1;

		?>

        <a class="pagf" href="?page=<?php echo $pre;?>">Previous</a>

        <?php

		}

		?>

        <select onchange="gotoRequiredPage(this.value)">

        <option value="">Select</option>

        

        

        <?php

		for($i=1;$i<=$pagecount;$i++)

		{

			$cls = $page==$i?'class = "activepage"':'class = "pagn"';

			

			?>

            <option value="<?php echo $i;?>" <?php if($_GET['page']==$i){ ?>  selected="selected" <?php }?>><?php echo $i;?></option>

            <?php

		}

		?>

        </select>

        <?php

		if($page<$i-1){

			$next=$_GET['page']+1;

			?>

             <a class="pagf" href="?page=<?php echo $next;?>">Next</a>

            <?php

			}

		//echo '<a class="pagl" href="?page='.($i-1).'">Last</a>';



	}

}



?>



 <?php include("includes/footer.php");?>

