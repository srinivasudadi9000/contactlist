<?php include("includes/header.php");?>

<?php include "includes/leftnav.php";

$userObj->checkloggedin();



?>



<?php 

if($_SESSION['role']=='sales')

{

$leadscount = $userObj->getTotalLeadsCount($_SESSION['id']);

$coldleadscount = $userObj->getTotalLeadsCountBySataus($_SESSION['id'],'Cold_Lead');

$teedleadscount = $userObj->getTotalLeadsCountBySataus($_SESSION['id'],'Teed');

$closedeadscount = $userObj->getTotalLeadsCountBySataus($_SESSION['id'],'Closed');

$openleadscount = $userObj->getTotalLeadsCountBySataus($_SESSION['id'],'Open');



}

?>

 <?php 

    

	 $allemplists=$userObj->getAllEmployeeList();

	 $totopencount=$userObj->getStatusCount('Open');

	 $totteedcount=$userObj->getStatusCount('Teed');

	 $totcoldcount=$userObj->getStatusCount('Cold_Lead');

	 $totclosedcount=$userObj->getStatusCount('Closed');

	 

	 

	 

	 //print_r($allemplist);

	 $count=0;

	 $opencount=array();

	 $teedcount=array();

	 $closedcount=array();

	 foreach($allemplists as $allemplist)

	 {

	 if($allemplist->firstname=="")

	 {

	 }

	 else

	 {

	 //$newlist=$userObj->getAllEmployeeAmmount($allemplist->id);

	 //print_r();

	$opencount[$count]=$userObj->getAllEmployeeStatusCount('open_date',$allemplist->id);

	  $teedcount[$count]=$userObj->getAllEmployeeStatusCount('teed_date',$allemplist->id);

	  $closedcount[$count]=$userObj->getAllEmployeeStatusCount('closed_date',$allemplist->id);

	 // echo $closedcount1."sdfsdffffffffffffffffffffffffffffffffff"; exit;

	 $emparr[$count]=$allemplist->firstname;

	 //$empopen[$i]=

	 //$emparr[$i]=$allemplist->firstname;

	 $count++;

	 }

	 

	 

	 }

	 //print "<pre>";

	//print_r($opencount);

 	/* Total one year count for open */

	 $presentyearopenq1=$userObj->getCountFirstquater(date('Y'),'open_date');

	 $presentyearopenq2=$userObj->getCountSecondquater(date('Y'),'open_date');

	 $presentyearopenq3=$userObj->getCountThirdquater(date('Y'),'open_date');

	 $presentyearopenq4=$userObj->getCountFourthquater(date('Y'),'open_date');

	

  	/* Total one year count for closed*/

	$presentyearclosedq1=$userObj->getCountFirstquater(date('Y'),'closed_date');

	$presentyearclosedq2=$userObj->getCountSecondquater(date('Y'),'closed_date');

	$presentyearclosedq3=$userObj->getCountThirdquater(date('Y'),'closed_date');

	$presentyearclosedq4=$userObj->getCountFourthquater(date('Y'),'closed_date');

	

	/* Total one year count for teed*/

	$presentyearteedq1=$userObj->getCountFirstquater(date('Y'),'teed_date');

	$presentyearteedq2=$userObj->getCountSecondquater(date('Y'),'teed_date');

	$presentyearteedq3=$userObj->getCountThirdquater(date('Y'),'teed_date');

	$presentyearteedq4=$userObj->getCountFourthquater(date('Y'),'teed_date');

	

	

	

?>



<!--<script type="text/javascript">

  window.onload = function () {

	 

    var chart1 = new CanvasJS.Chart("totalrevenuegraph",

    {

      title:{

        text: "Total Revenue Graph"

      },

      animationEnabled: true,

      legend: {

        cursor:"pointer",

        itemclick : function(e) {

          if (typeof (e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {

              e.dataSeries.visible = false;

          }

          else {

              e.dataSeries.visible = true;

          }

          chart.render();

        }

      },

      axisY: {

        title: "Medals"

      },

      toolTip: {

        shared: true,  

        content: function(e){

          var str = '';

          var total = 0 ;

          var str3;

          var str2 ;

          for (var i = 0; i < e.entries.length; i++){

            var  str1 = "<span style= 'color:"+e.entries[i].dataSeries.color + "'> " + e.entries[i].dataSeries.name + "</span>: <strong>"+  e.entries[i].dataPoint.y + "</strong> <br/>" ; 

            total = e.entries[i].dataPoint.y + total;

            str = str.concat(str1);

          }

          str2 = "<span style = 'color:DodgerBlue; '><strong>"+e.entries[0].dataPoint.label + "</strong></span><br/>";

          str3 = "<span style = 'color:Tomato '>Total: </span><strong>" + total + "</strong><br/>";

          

          return (str2.concat(str)).concat(str3);

        }



      },

      data: [

      {        

        type: "bar",

        showInLegend: true,

        name: "Open",

        color: "gold",

        dataPoints: [

        { y: <?php echo $presentyearopenq1;?>, label: "JAN-MAR"},

        { y: <?php echo $presentyearopenq2;?>, label: "APR-JUN"},

        { y: <?php echo $presentyearopenq3;?>, label: "JUL-SEP"},        

        { y: <?php echo $presentyearopenq4;?>, label: "OCT-DEC"}    

        



        ]

      },

      {        

        type: "bar",

        showInLegend: true,

        name: "Teed",

        color: "silver",          

        dataPoints: [

        { y: <?php echo $presentyearteedq1;?>, label: "JAN-MAR"},

        { y: <?php echo $presentyearteedq2;?>, label: "APR-JUN"},

        { y: <?php echo $presentyearteedq3;?>, label: "JUL-SEP"},        

        { y: <?php echo $presentyearteedq4;?>, label: "OCT-DEC"}    

       

        ]

      },

      {        

        type: "bar",

        showInLegend: true,

        name: "Closed",

        color: "#A57164",

        dataPoints: [

        { y: <?php echo $presentyearclosedq1;?>, label:  "JAN-MAR"},

        { y: <?php echo $presentyearclosedq2;?>, label: "APR-JUN"},

        { y: <?php echo $presentyearclosedq3;?>, label: "JUL-SEP"},        

        { y: <?php echo $presentyearclosedq4;?>, label: "OCT-DEC"}   

       

        ]

      }



      ]

    });



chart1.render();





   

    var chart2 = new CanvasJS.Chart("employeesalesgraph",

    {



			title:{

				text:"Employee Sales Graph"				



			},

                        animationEnabled: true,

			axisX:{

				interval: 1,

				gridThickness: 0,

				labelFontSize: 10,

				labelFontStyle: "normal",

				labelFontWeight: "normal",

				labelFontFamily: "Lucida Sans Unicode"



			},

			axisY2:{

				interlacedColor: "rgba(1,77,101,.2)",

				gridColor: "rgba(1,77,101,.1)"



			},



			data: [

			{     

				type: "bar",

                name: "Open",

				axisYType: "secondary",

				color: "#014D65",				

				dataPoints: [

				

				<?php

		$ii=0;

		

		for($i=0;$i<sizeof($emparr);$i++){

			if($emparr[$i]!=''){?>{ y: <?php echo $opencount[$i]?>, label: "<?php echo $emparr[$i]; ?>"}<?php	}if((sizeof($emparr)-1)!=$ii){ echo ","; }

			$ii++;

		}

		

		 ?>

				]

			},

			{     

				type: "bar",

                name: "Teed",

				axisYType: "secondary",

				color: "Yellow",				

				dataPoints: [

				<?php

		$ii=0;

		

		for($i=0;$i<sizeof($emparr);$i++){

			if($emparr[$i]!=''){?>{ y: <?php echo $teedcount[$i]?>, label: "<?php echo $emparr[$i]; ?>"}<?php	}if((sizeof($emparr)-1)!=$ii){ echo ","; }

			$ii++;

		}

		

		 ?>

				]

			},

			{     

				type: "bar",

                name: "Closed",

				axisYType: "secondary",

				color: "Red",				

				dataPoints: [

				

				<?php

		$ii=0;

			

		for($i=0;$i<sizeof($emparr);$i++){

			if($emparr[$i]!=''){?>{ y: <?php echo $closedcount[$i]?>, label: "<?php echo $emparr[$i]; ?>"}<?php	}if((sizeof($emparr)-1)!=$ii){ echo ","; }

			$ii++;

		}

		

		 ?>

				]

			}

			

			]

		});



chart2.render();



}

</script>
-->


<div class="content-wrapper">

        <!-- Content Header (Page header) -->

        <section class="content-header">

          <h1>

            Dashboard

          <!--  <small>Control panel</small>-->

          </h1>

          <ol class="breadcrumb">

            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>

            <li class="active">Dashboard</li>

          </ol>

        </section>



        <!-- Main content -->

        <section class="content">

          <!-- Small boxes (Stat box) -->

          <div class="row">

            <div class="col-lg-3 col-xs-6">

              <!-- small box -->

              <div class="small-box bg-aqua">

                <div class="inner">

                  <h3><?php 

				  if($_SESSION['role']=="sales")

				  {

					  echo $openleadscount;

				 

				  }

				  else

				  {

				    echo  $totopencount;	  

					 }?></h3>

                  <p>Open Leads</p>

                </div>

                <div class="icon">

                  <i class="ion ion-person-add"></i>

                </div>

                <a href="#" class="small-box-footer"><!--More info <i class="fa fa-arrow-circle-right"></i>--></a>

              </div>

            </div><!-- ./col -->

            <div class="col-lg-3 col-xs-6">

              <!-- small box -->

              <div class="small-box bg-green">

                <div class="inner">

                  <h3><?php 

				  if($_SESSION['role']=="sales")

				  {

				  echo $coldleadscount;

				  }

				  else

				  {

					  echo  $totcoldcount;

				  }?></h3>

                  <p>Cold Lead</p>

                </div>

                <div class="icon">

                  <i class="ion ion-person-add"></i>

                </div>

                <a href="#" class="small-box-footer"><!--More info <i class="fa fa-arrow-circle-right"></i>--></a>

              </div>

            </div><!-- ./col -->

            <div class="col-lg-3 col-xs-6">

              <!-- small box -->

              <div class="small-box bg-yellow">

                <div class="inner">

                  <h3><?php 

				  if($_SESSION['role']=="sales")

				  {

				     echo  $teedleadscount;

				  }

				  else

				  {

					   echo  $totteedcount;

				  }

				  ?></h3>

                  <p>Teed</p>

                </div>

                <div class="icon">

                  <i class="ion ion-person-add"></i>

                </div>

                <a href="#" class="small-box-footer"><!--More info <i class="fa fa-arrow-circle-right"></i>--></a>

              </div>

            </div><!-- ./col -->

            <div class="col-lg-3 col-xs-6">

              <!-- small box -->

              <div class="small-box bg-red">

                <div class="inner">

                  <h3><?php 

				   if($_SESSION['role']=="sales")

				  {

				  echo  $closedeadscount;

				  }

				  else

				  {

				  echo  $totclosedcount;

				  

				  }

				  ?></h3>

                  <p>Closed</p>

                </div>

                <div class="icon">

                  <i class="ion ion-person-add"></i>

                </div>

                <a href="#" class="small-box-footer"><!--More info <i class="fa fa-arrow-circle-right"></i>--></a>

              </div>

            </div><!-- ./col -->

          </div><!-- /.row -->

          <!-- Main row -->

          <div class="row">

               <div class="col-lg-20">        

              <div class="innercol-lg-20">

             

              <div id="totalrevenuegraph" style="height: 300px;">

              </div>

              

              

              </div>

              </div>

              <div class="col-lg-20">        

              <div class="innercol-lg-20">

          <?php //echo print_r($emparr);

		    //print_r($opencount);

		    //print_r($closedcount);

		    //print_r($teedcount);

		  

		  ?>

               <div id="employeesalesgraph" style="height:600px;">

              </div>

              

              </div>

              </div>

              

              </div>  

              

              

              

              

               

                

              </div>

              <!-- /.box -->



              <!-- solid sales graph -->

              <!-- /.box -->



              <!-- Calendar -->

              <!-- /.box -->



            </section><!-- right col -->

          </div>





<?php include("includes/footer.php");?> 