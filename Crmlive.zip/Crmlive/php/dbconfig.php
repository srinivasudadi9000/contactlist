<?php

class DBConnection{

	function getConnection(){

	  //change to your database server/user name/password

		mysql_connect("localhost","wwwkyl3c_kylecrm","kylecrm@123") or

         die("Could not connect: " . mysql_error());

    //change to your database name

		mysql_select_db("wwwkyl3c_crmnew") or 

		     die("Could not select database: " . mysql_error());

	}

}

?>