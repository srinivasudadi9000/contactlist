<?php include("includes/headermeta.php");
include("includes/leftnav.php");
$allmessages=$userObj->getBoardMessages();
//print_r($allmessages);
if($_POST['submit']=="submit")
{
	//print_r($_POST);
	$userObj->insertBoard($_POST);
}
if($_GET['action']=="delete")
{
	//print_r($_POST);	
	$userObj->deleteMessage($_GET['id']);
}
if($_POST['editform']=="Save")
{
	//print_r($_POST);	exit;
	$userObj->UpdateAdminBoardMessage($_POST);
}?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>AdminLTE 2 | Dashboard</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 3.3.2 -->
    <link href="../../bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- Font Awesome Icons -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons -->
    <link href="http://code.ionicframework.com/ionicons/2.0.0/css/ionicons.min.css" rel="stylesheet" type="text/css" />
    <!-- Theme style -->
    <link href="../../dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <!-- AdminLTE Skins. Choose a skin from the css/skins 
         folder instead of downloading all of them to reduce the load. -->
    <link href="../../dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="skin-blue">
    <div class="wrapper">
      
      
      <!-- Left side column. contains the logo and sidebar -->
     

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
           Registration
            
          </h1>
          
        </section>
<section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-6">
              <!-- general form elements -->
              <div class="box box-primary">
                <!-- /.box-header -->
                <!-- form start -->
              <form id="boardform" name="boardform" method="post" action="">
                  <div class="box-body">
                  
                     <div class="form-group">
                      <label>Description:</label>
                       <textarea name="description" class="form-control" style="height:200px; width:650px; padding:10px;" ></textarea>
                      
                    </div>
                  </div><!-- /.box-body -->

                  <div class="box-footer">
                    <button type="submit" class="btn btn-primary"  name="submit" value="submit">Submit</button>
                  </div>
                </form>
                <h4 >Messages </h4>
                <div id="testDiv3"> 
 <?php 
 
 
 echo "<table width='100%'>
 <tr style='border-bottom:1px solid #ccc;height:50px;'>
		<th align='left' style='padding-left:50px;color:#000;font-size:14px;'>
		Message
		</th>
		<th align='left' style='padding-left:5px;color:#000;font-size:14px;'>
		Edit
		</th>
		<th align='left' style='padding-left:5px;color:#000;font-size:14px;'>
		Delete
		</th>
		<th align='left' style='padding-left:5px;color:#000;font-size:14px;'>
		
		Date
		</th>
		</tr>";
		
		
 	foreach($allmessages as $all_messages)
	{
		echo "<tr style=';'>
		
		<td align='left' style='width:70%;padding-left:50px;'><p style='width:350px;;word-wrap:break-word;'>".$all_messages->description."</p></td>
		<td  align='left'><a href=".SITEURL."/board.php?eid=".$all_messages->id."&action=edit><img src='".SITEURL."/images/edit_icon.png'/></a></td>
		<td  align='left'><a href=".SITEURL."/board.php?id=".$all_messages->id."&action=delete><img src='".SITEURL."/images/delete.png'/></a></td>
		<td  align='left' style='width:200px;'>".$all_messages->createdon."</td></tr>";
	}
	
	echo "</table>";	
	
	
	
 ?>
    </div>
                
              </div><!-- /.box -->
              

              <!-- Form Element sizes -->
              <!-- /.box -->

              <!-- /.box -->

              <!-- Input addon -->
              <!-- /.box -->

            </div><!--/.col (left) -->
            <!-- right column -->
            <!--/.col (right) -->
          </div>   <!-- /.row -->
        </section>