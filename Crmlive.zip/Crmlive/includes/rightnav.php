<?php  
include('../dbconfig.php');

$tabdata = $userObj->getRightnavtab1data();


//print_r($tabdata);
?>
<?php /*?>include("model/user.class.php");
$userObj=new userClass();

<div class="calender_part">
<div class="calender_img">
<link rel="stylesheet" type="text/css" href="<?php print SITEURL?>/css/calendar.css"/>
<script type="text/javascript" src="<?php print SITEURL?>/js/jquery.min.js"></script>
<script>var $jquery=jQuery.noConflict();</script>
<script type="text/javascript" src="<?php print SITEURL?>/js/jquery.calendar.js"></script>
<script type="text/javascript">
$jquery(document).ready(function() {
	var date = new Date();
	var d = date.getDate();
	var m = date.getMonth();
	var y = date.getFullYear();
	var h = {};

	$jquery("#calendar").fullCalendar({
		header: h,
		selectable: true,
		select: function( startDate, endDate, allDay, jsEvent, view ) {
			var newstart = 	$jquery.fullCalendar.formatDate(startDate, "yyyy-MM-dd");
			
			$("#start").html('<span>'+newstart+'</span>');
			var start = $("#start").html();
		  
		$jquery("#today").hide();
		$jquery.ajax({
			type: "get",
			url: "<?php print SITEURL?>/ajaxphp/ajax.php?r=confirm_booking&start="+start,
			data: "",
			success: function(response) {
						
				$("#confirm").fadeOut();
				$("#response").html(response);
			}
		});
		
		},
		
		editable: true,
		draggable: true,
		droppable: false
	});
});
</script>
<script type="text/javascript">
$jquery(function() {
$jquery(".delete").click(function(){
var element = $(this);
var del_id = element.attr("id");
var info = 'id=' + del_id;
if(confirm("Are you sure you want to delete this?"))
{
$jquery.ajax({
   type: "POST",
   url: "<?php print SITEURL?>/delete.php",
   data: info,
   success: function(){ 
 }
});
 $jquery(this).parents(".show").animate({ backgroundColor: "#003" }, "slow")
  .animate({ opacity: "hide" }, "slow");
 }
return false;
});
});
</script>


	
	   <div class="rightcal">
	   <div id="calendar"></div>
			    </div>
                <div class="pull-right align-right margin-10">
				<p hidden="hidden" id="start"></p>
				<br/><div id="response"></div>
			</div>
		</div>



			<?php 
			//$link = mysqli_connect('localhost','root','','crmnew') or die("Error " . mysqli_error($link));
			//var_dump($link);
           /* if (mysqli_connect_errno()){
            echo "Failed to connect to mysqli: " . mysqli_connect_error();
            exit;
                                       }*/
	/*$count = strip_tags("select count(*) from `jqcalendar` where `StartTime` LIKE '%".$_GET['start']."%'");
	$countquery = mysqli_query($link,$count);
	while($count1 = mysqli_fetch_array($countquery)){
				}
	$sql=strip_tags("SELECT  * from `jqcalendar` where `StartTime` LIKE '%".date('Y-m-d')."%'");
	$result=mysqli_query($link,$sql);
   $res=mysqli_num_rows($result);
     
      ?>
	 <div id="today" class="pull-right align-right margin-20" >
	 <div class="do_list_wrap" style="margin-top:10px;margin-right:100px;color:#3c8dbc; width:100px;"><b>To do List</b></div>
	 <div class="today_wrapper">
		<h2 style="text-align:center; width:100%;"><?php echo "Today"; ?></h2>
		<ul class="food_timings">
			<?php
			if($res>0){
			$i=1;
			while($row=mysqli_fetch_array($result,MYSQLI_ASSOC)){ 
			
			?>
            <?php if($_SESSION['name']==$row['name_id']){ ?>
            <li class="show" style="word-wrap:break-word;"><?php echo $row['Subject']; ?><span class="action"><a href="#" id="<?php echo $row['Id']; ?>" class="delete" title="Delete"><img src="<?php print SITEURL?>/images/delete_img_19.png"></a></span></li>
			<?php
			}
				$i++; 
			
			}
			
			}else{ 	
			echo "<li style='background-color:#fff; position:relative; right:25px; padding:12px 0px; text-align:center; font-size:18px; color:#f00; opacity:2;'>No Events</li>";}
			?>
			
		</ul>          
		<a href="<?php print SITEURL?>/ToDoList"><input type="button" value="View All Events" style=" background-color:#3c8dbc; -webkit-border-radius:10px; -moz-border-radius:10px; border-radius:10px; width:90%; height:35px; border:none; color:#fff; font-family:'Open Sans', sans-serif; font-weight:600; font-size:16px; margin-top:20px; text-decoration:underline; text-align:center;"></a>
		<div class="clear_fix"></div>            
	</div>
</div>
         <?php ?>             
            </div>
                </div>	
                  <div class="clear_fix"></div>
                    </div>        
 
                     </div><?php */?>

 
 
<script type="text/javascript" src="<?php print SITEURL?>/js/jquery.min.js"></script>
<script type="text/javascript">
$(function() {
$(".submit_button1").click(function() {
var textcontent = $("#content_tab1").val();
var tabname = $("#hidden_tab1").val();
var dataString = 'content_tab1='+ textcontent+"&hidden_tab1="+tabname;
//alert(dataString);
if(textcontent=='')
{
alert("Enter some text..");
$("#content_tab1").focus();
}
else
{
//alert(dataString);
$("#flash").show();
$("#flash").fadeIn(400).html('<span class="load">Loading..</span>');
$.ajax({
type: "POST",
url: "<?php echo SITEURL?>/action.php",
data: dataString,
cache: true,
success: function(html){
$("#edittab").val(html);
$("#content_tab1").val(html);
$("#loaddadta1").hide();

$("#flash").hide();
$("#content_tab1").focus();
}  
});
}
return false;
});
});
</script>

<script type="text/javascript" src="<?php print SITEURL?>/js/jquery.min.js"></script>
<script type="text/javascript">
$(function() {
$(".submit_button2").click(function() {
var textcontent = $("#content_tab2").val();
var tabname = $("#hidden_tab2").val();
var dataString = 'content_tab2='+ textcontent+"&hidden_tab2="+tabname;
//alert(dataString);
if(textcontent=='')
{
alert("Enter some text..");
$("#content_tab2").focus();
}
else
{
//alert(dataString);
$("#flash").show();
$("#flash").fadeIn(400).html('<span class="load">Loading..</span>');
$.ajax({
type: "POST",
url: "<?php echo SITEURL?>/action.php",
data: dataString,
cache: true,
success: function(html){
	//alert(html);
$("#content_tab2").val(html);
$("#loaddadta2").hide();
$("#flash").hide();
$("#content_tab2").focus();
}  
});
}
return false;
});
});
</script>



<script type="text/javascript" src="<?php print SITEURL?>/js/jquery.min.js"></script>
<script type="text/javascript">
$(function() {
$(".submit_button3").click(function() {
var textcontent = $("#content_tab3").val();
var tabname = $("#hidden_tab3").val();
var dataString = 'content_tab3='+ textcontent+"&hidden_tab3="+tabname;
//alert(dataString);
if(textcontent=='')
{
alert("Enter some text..");
$("#content_tab3").focus();
}
else
{
//alert(dataString);
$("#flash").show();
$("#flash").fadeIn(400).html('<span class="load">Loading..</span>');
$.ajax({
type: "POST",
url: "<?php echo SITEURL?>/action.php",
data: dataString,
cache: true,
success: function(html){
$("#content_tab3").val(html);
$("#loaddadta3").hide();
//document.getElementById('content_tab3').value='';
$("#flash").hide();
$("#content_tab3").focus();
}  
});
}
return false;
});
});
 </script>

<script type="text/javascript" src="<?php print SITEURL?>/js/jquery.min.js"></script>
<script type="text/javascript">
$(function() {
$(".submit_button4").click(function() {
var textcontent = $("#content_tab4").val();
var tabname = $("#hidden_tab4").val();
var dataString = 'content_tab4='+ textcontent+"&hidden_tab4="+tabname;
//alert(dataString);
if(textcontent=='')
{
alert("Enter some text..");
$("#content_tab4").focus();
}
else
{
//alert(dataString);
$("#flash").show();
$("#flash").fadeIn(400).html('<span class="load">Loading..</span>');
$.ajax({
type: "POST",
url: "<?php echo SITEURL?>/action.php",
data: dataString,
cache: true,
success: function(html){
$("#content_tab4").val(html);
$("#loaddadta4").hide();
//document.getElementById('content_tab4').value='';
$("#flash").hide();
$("#content_tab4").focus();
}  
});
}
return false;
});
});
</script>

<script type="text/javascript" src="<?php print SITEURL?>/js/jquery.min.js"></script>
<script type="text/javascript">
$(function() {
$(".submit_button5").click(function() {
var textcontent = $("#content_tab5").val();
var tabname = $("#hidden_tab5").val();
var dataString = 'content_tab5='+ textcontent+"&hidden_tab5="+tabname;
//alert(dataString);
if(textcontent=='')
{
alert("Enter some text..");
$("#content_tab5").focus();
}
else
{
//alert(dataString);
$("#flash").show();
$("#flash").fadeIn(400).html('<span class="load">Loading..</span>');
$.ajax({
type: "POST",
url: "<?php echo SITEURL?>/action.php",
data: dataString,
cache: true,
success: function(html){
$("#content_tab5").val(html);
$("#loaddadta5").hide();
//document.getElementById('content_tab5').value='';
$("#flash").hide();
$("#content_tab5").focus();
}  
});
}
return false;
});
});
 </script>
 
 
 <script type="text/javascript" src="<?php print SITEURL?>/js/jquery.min.js"></script>
<script type="text/javascript">
$(function() {
$(".submit_button6").click(function() {
var textcontent = $("#content_tab6").val();
var tabname = $("#hidden_tab6").val();
var dataString = 'content_tab6='+ textcontent+"&hidden_tab6="+tabname;
//alert(dataString);
if(textcontent=='')
{
alert("Enter some text..");
$("#content_tab6").focus();
}
else
{
//alert(dataString);
$("#flash").show();
$("#flash").fadeIn(400).html('<span class="load">Loading..</span>');
$.ajax({
type: "POST",
url: "<?php echo SITEURL?>/action.php",
data: dataString,
cache: true,
success: function(html){
$("#content_tab6").val(html);
$("#loaddadta6").hide();
//document.getElementById('content_tab6').value='';
$("#flash").hide();
$("#content_tab6").focus();
}  
});
}
return false;
});
});
 </script>

 </script>


<style>
.tabs_list    { font-family:Arial, Helvetica, sans-serif;   }
.tabs_list li { width:17.6%; margin-right:1.3%; float:left; background-color:#dddddd; font-weight:700; font-size:12px;                -webkit-border-top-left-radius: 5px; -webkit-border-top-right-radius: 5px; -moz-border-radius-topleft: 5px;                -moz-border-radius-topright: 5px; border-top-left-radius: 5px; border-top-right-radius: 5px; }
.tabs_list li a  { padding:7px 0px;  display:block; color:#929292; margin-left: 0px; }
.tabs_list li:hover a{ background-color:#666666; color:#fff;webkit-border-top-left-radius: 5px; -webkit-border-top-right-radius: 5px; -moz-border-radius-topleft: 5px;                -moz-border-radius-topright: 5px; border-top-left-radius: 5px; border-top-right-radius: 5px; }
.tabdisc   { border:1px solid #ebebeb;  -webkit-border-bottom-right-radius: 7px;
-webkit-border-bottom-left-radius: 7px;
-moz-border-radius-bottomright: 7px;
-moz-border-radius-bottomleft: 7px;
border-bottom-right-radius: 7px;
border-bottom-left-radius: 7px; padding:10px 15px;  }
.tabdisc p  { color:#a3a3a3; font-size:13px; margin-top:5px; }
.active_tab{background-color:#666666; color:#fff;webkit-border-top-left-radius: 5px; -webkit-border-top-right-radius: 5px; -moz-border-radius-topleft: 5px;                -moz-border-radius-topright: 5px; border-top-left-radius: 5px; border-top-right-radius: 5px; margin-left:-37px;}
.rightlowerdiv{    width: 100%;
    word-wrap: break-word;
    text-align: justify;
    max-height: 500px;
    overflow-y: auto;}
.righttextarea{	width:99%; font-size:14px; height:500px; resize:none; margin-top:20px; border:1px solid #aaaaaa;}
</style>

<div class="calender_part">
<div class="calender_img">
<link rel="stylesheet" type="text/css" href="<?php print SITEURL?>/css/calendar.css"/>
<ul class="tabs_list">
       <li id="tab1" class="active_tab"><a href="#" title="Product Description">T 1</a></li>
       <li id="tab2"><a href="#" title="Product’s Review">T 2 </a></li>
       <li id="tab3"><a href="#" title="Messages">T 3</a></li>
       <li id="tab4"><a href="#" title="Messages">T 4</a></li>
       <li id="tab5"><a href="#" title="Messages">T 5</a></li>
       <li id="tab6"><a href="#" title="Messages">T 6</a></li>
       <div class="clear_fix"></div>
      </ul>
     <div class="tabdisc" id="tab_disc1">
      <form  method="post" name="form" action="">
       <textarea  class="righttextarea" name="content_tab1" id="content_tab1" ><?php  echo $tabdata->content_tab1;  ?></textarea>
        
       <br />
        <input type="hidden" value="tab1" name="hidden_tab1" id="hidden_tab1" class="hidden_tab1" />
       <input type="submit" value="Save" name="submit_tab1" class="submit_button1" style="text-align:center; margin-top:10px;"/>
       </form>
       <div class="rightlowerdiv" id="show1">
		
       </div>
        <!--<div class="rightlowerdiv" id="loaddadta1">
		<?php 
	   echo $tabdata->content_tab1; 
	   ?>
       </div>-->
     </div>
	 <div id="flash"></div>
    
     <div class="tabdisc" id="tab_disc2" style="display:none;">
       <form  method="post" name="form" action="">
       <textarea class="righttextarea" name="content_tab2" id="content_tab2" ><?php  echo $tabdata->content_tab2; ?></textarea><br />
       <input type="hidden" value="tab2" id="hidden_tab2" name="hidden_tab2" class="hidden_tab2" />
       <input type="submit" value="Save" name="submit_tab2" class="submit_button2" style="text-align:center; margin-top:10px;"/>
       
       </form>
        <div class="rightlowerdiv" id="show2">
		
       </div>
       <!-- <div class="rightlowerdiv" id="loaddadta2" >
		<?php 
	   echo $tabdata->content_tab1; 
	   ?>
       </div>-->
     </div>
     
	  <div id="flash"></div>
    
     <div class="tabdisc" id="tab_disc3" style="display:none;"> 
	   <form  method="post" name="form" action="">
       <textarea class="righttextarea" name="content_tab3" id="content_tab3" >
	   <?php 
	   echo $tabdata->content_tab3; 
	   ?></textarea><br />
          <input type="hidden" value="tab3" id="hidden_tab3" name="hidden_tab3" class="hidden_tab3" />
   <input type="submit" value="Save" name="submit_tab3" class="submit_button3" style="text-align:center; margin-top:10px;"/>
       
       </form>
        <div class="rightlowerdiv" id="show3">
		
       </div>
       <!-- <div class="rightlowerdiv" id="loaddadta3" >
		<?php 
	   echo $tabdata->content_tab3; 
	   ?>
       </div>-->
	   
     </div>
     
     
	 <div id="flash"></div>
     
      
<div class="tabdisc" id="tab_disc4" style="display:none;">
      <form  method="post" name="form" action="">
       <textarea class="righttextarea" name="content_tab4" id="content_tab4" ><?php echo $tabdata->content_tab4; ?></textarea><br />
        <input type="hidden" value="tab4" name="hidden_tab4" id="hidden_tab4" class="hidden_tab4" />
       <input type="submit" value="Save" name="submit_tab4" class="submit_button4" style="text-align:center; margin-top:10px;"/>
       </form>
       <div class="rightlowerdiv" id="show4">
		
       </div>
       <!-- <div class="rightlowerdiv" id="loaddadta4">
		<?php 
	   echo $tabdata->content_tab4; 
	   ?>
       </div>--></div>
     
	 <div id="flash"></div>
     
     
     <div class="tabdisc" id="tab_disc5" style="display:none;">
      <form  method="post" name="form" action="">
       <textarea class="righttextarea" name="content_tab5" id="content_tab5" ><?php  echo $tabdata->content_tab5;?></textarea><br />
        <input type="hidden" value="tab5" name="hidden_tab5" id="hidden_tab5" class="hidden_tab5" />
       <input type="submit" value="Save" name="submit_tab5" class="submit_button5" style="text-align:center; margin-top:10px;"/>
       </form>
       <div class="rightlowerdiv" id="show5">
		
       </div>
        <!--<div class="rightlowerdiv" id="loaddadta5">
		<?php 
	   echo $tabdata->content_tab5; 
	   ?>
       </div>--></div>
     
	 <div id="flash"></div>
     
     
     <div class="tabdisc" id="tab_disc6" style="display:none;">
      <form  method="post" name="form" action="">
       <textarea class="righttextarea" name="content_tab6" id="content_tab6" ><?php echo $tabdata->content_tab6; ?></textarea><br />
        <input type="hidden" value="tab6" name="hidden_tab6" id="hidden_tab6" class="hidden_tab6" />
       <input type="submit" value="Save" name="submit_tab6" class="submit_button6" style="text-align:center; margin-top:10px;"/>
       </form>
       <div class="rightlowerdiv" id="show6">
		
       </div>
       <!-- <div class="rightlowerdiv" id="loaddadta6">
		<?php 
	   echo $tabdata->content_tab6; 
	   ?>
       </div>-->
       </div>
     
	 <div id="flash"></div>
     
     </div>
     
</div>


 
<script src="http://code.jquery.com/jquery-latest.min.js"
 <script type="text/javascript"></script>
<script type="text/javascript">
$(document).ready(function(e){
    $('#tab1').click(function(e) {
        $('#tab_disc1').show();
		$('#tab_disc2').hide();
		$('#tab_disc3').hide();
		$('#tab_disc4').hide();
		$('#tab_disc5').hide();
		$('#tab_disc6').hide();
		
    });
	$('#tab2').click(function(e) {
        $('#tab_disc1').hide();
		$('#tab_disc2').show();
		$('#tab_disc3').hide();
		$('#tab_disc4').hide();
		$('#tab_disc5').hide();
		$('#tab_disc6').hide();
    });
	$('#tab3').click(function(e) {
        $('#tab_disc1').hide();
		$('#tab_disc2').hide();
		$('#tab_disc3').show();
		$('#tab_disc4').hide();
		$('#tab_disc5').hide();
		$('#tab_disc6').hide();
    });
	 $('#tab4').click(function(e) {
        $('#tab_disc1').hide();
		$('#tab_disc2').hide();
		$('#tab_disc3').hide();
		$('#tab_disc4').show();
		$('#tab_disc5').hide();
		$('#tab_disc6').hide();
    });
     $('#tab5').click(function(e) {
        $('#tab_disc1').hide();
		$('#tab_disc2').hide();
		$('#tab_disc3').hide();
		$('#tab_disc4').hide();
		$('#tab_disc5').show();
		$('#tab_disc6').hide();
    });
    $('#tab6').click(function(e) {
        $('#tab_disc1').hide();
		$('#tab_disc2').hide();
		$('#tab_disc3').hide();
		$('#tab_disc4').hide();
		$('#tab_disc5').hide();
		$('#tab_disc6').show();
	});
});
</script>