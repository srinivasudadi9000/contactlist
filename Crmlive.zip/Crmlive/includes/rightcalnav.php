<?php echo include('../dbconfig.php');?>
<div class="calender_part">
<div class="calender_img">
<!--<script type="text/javascript" src="<?php print SITEURL?>/js/jquery.min.js"></script>-->
<link rel="stylesheet" type="text/css" href="<?php print SITEURL?>/css/calendar.css"/>
<script type="text/javascript" src="<?php print SITEURL?>/js/jquery.calendar.js"></script>
<script type="text/javascript">
$(document).ready(function() {
	var date = new Date();
	var d = date.getDate();
	var m = date.getMonth();
	var y = date.getFullYear();
	var h = {};

	$("#calendar").fullCalendar({
		header: h,
		selectable: true,
		select: function( startDate, endDate, allDay, jsEvent, view ) {
			var newstart = $.fullCalendar.formatDate(startDate, "yyyy-MM-dd");
			//var newend = $.fullCalendar.formatDate(endDate, "y%-d-m");
			$("#start").html('<span>'+newstart+'</span>');
			var start = $("#start").html();
		//var end = $("#end span").html();
        // alert("hi");
		 
		$("#today").hide();
		$.ajax({
			type: "get",
			url: "<?php print SITEURL?>/ajaxphp/ajax.php?r=confirm_booking&start="+start,
			data: "",
			success: function(response) {			
				$("#confirm").fadeOut();
				$("#response").html(response);
			}
		});
			//$("#end").html('<strong>End </strong><br/><span>'+newend+'</span>');
			//$("#confirm").fadeIn();
		},
		
		editable: true,
		draggable: true,
		droppable: false
	});

	
});
</script>
<script type="text/javascript">
$(function() {
$(".delete").click(function(){
var element = $(this);
var del_id = element.attr("id");
var info = 'id=' + del_id;
if(confirm("Are you sure you want to delete this?"))
{
 $.ajax({
   type: "POST",
   url: "<?php print SITEURL?>/delete.php",
   data: info,
   success: function(){ 
 }
});

  $(this).parents(".show").animate({ backgroundColor: "#003" }, "slow")
  .animate({ opacity: "hide" }, "slow");
 }
return false;

});
});
</script>



	
			<div class="rightcal">
				<div id="calendar"></div>
			</div>

			<div class="pull-right align-right margin-10">
				<p hidden="hidden" id="start"></p>
					
           
				
				<br/><div id="response"></div>
			</div>
		</div>



                 <?php 
/*$link = mysqli_connect('localhost','root','','crmnew') or die("Error " . mysqli_error($link));
	if (mysqli_connect_errno()){
		echo "Failed to connect to MySQL: " . mysql_connect_error();
		exit;
	}
*/	//echo "select count(*) from `jqcalendar` where `StartTime` LIKE '%".$_GET['start']."%'"; exit;
	$count = strip_tags("select count(*) from `jqcalendar` where `StartTime` LIKE '%".$_GET['start']."%'");
	$countquery = mysqli_query($link,$count);
	while($count1 = mysqli_fetch_array($countquery)){
		//print_r($count1); exit;
		//echo $count1['count(*)']; 
		}
	$sql=strip_tags("SELECT  * from `jqcalendar` where `StartTime` LIKE '%".date('Y-m-d')."%'");
	$result=mysqli_query($link,$sql);
	$res=mysqli_num_rows($result);
    //echo date('Y-m-d'); 
//while($row=mysql_fetch_array($result,mysql_ASSOC)){ 
//print_r($row);
//echo $row['StartTime']; 
//echo date('Y-m-d');.
if($row['StartTime']!=date('Y-m-d')){
 ?>
	<div id="today" class="pull-right align-right margin-20" >
	<div class="do_list_wrap" style="margin-top:10px;margin-right:100px;color:#3c8dbc;"><b>To do List</b></div>
	 <div class="today_wrapper12">
		<h2 style="padding-right:200px;"><?php echo "Today"; ?></h2>
		<ul class="food_timings">
			<?php
			if($res>0){
			
			while($row=mysqli_fetch_array($result,MYSQLI_ASSOC)){ 
			//echo $row; exit;
			//print_r($row);
			
				?>
                 <?php if($_SESSION['name']==$row['name_id']){ ?>
                 <li class="show" style="word-wrap:break-word;"><?php echo $row['Subject'] ?><span class="action"><a href="#" id="<?php echo $row['Id']; ?>" class="delete" title="Delete"><img src="<?php print SITEURL?>/images/delete_img_19.jpg"></a></span></li><?php 
			
			}
			}
			
			}
			 else 
		 { 	
		 echo "<div style='background-color:#fff; position:relative; right:25px; padding:12px 0px; text-align:center; font-size:18px; color:#f00; opacity:2;'>No Events</div>";
		 } 
			?>
            <a href="<?php print SITEURL; ?>/ToDoList"><input type="button" value="View All Events" style=" background-color:#3c8dbc; -webkit-border-radius:10px; -moz-border-radius:10px; border-radius:10px; width:90%; height:35px; border:none; color:#fff; font-family:'Open Sans', sans-serif; font-weight:600; font-size:16px; margin-top:20px; text-decoration:underline; text-align:center;"></a>
			<div class="clear_fix"></div>
		</ul>                      
	</div>
</div>
         <?php } ?>             
                  </div>
                      
                 
                 </div>	

                <div class="clear_fix"></div>

            </div>        
          </div>