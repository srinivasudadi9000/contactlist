<?php
include("model/db.class.php");
$callConfig=new configClass();

$callConfig->configConnection();

?> 	          