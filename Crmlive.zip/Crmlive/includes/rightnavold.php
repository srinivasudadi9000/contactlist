<?php  include('../dbconfig.php');?>
<div class="calender_part">
<div class="calender_img">
<link rel="stylesheet" type="text/css" href="<?php print SITEURL?>/css/calendar.css"/>
<script type="text/javascript" src="<?php print SITEURL?>/js/jquery.min.js"></script>
<script>var $jquery=jQuery.noConflict();</script>
<script type="text/javascript" src="<?php print SITEURL?>/js/jquery.calendar.js"></script>
<script type="text/javascript">
$jquery(document).ready(function() {
	var date = new Date();
	var d = date.getDate();
	var m = date.getMonth();
	var y = date.getFullYear();
	var h = {};

	$jquery("#calendar").fullCalendar({
		header: h,
		selectable: true,
		select: function( startDate, endDate, allDay, jsEvent, view ) {
			var newstart = 	$jquery.fullCalendar.formatDate(startDate, "yyyy-MM-dd");
			
			$("#start").html('<span>'+newstart+'</span>');
			var start = $("#start").html();
		  
		$jquery("#today").hide();
		$jquery.ajax({
			type: "get",
			url: "<?php print SITEURL?>/ajaxphp/ajax.php?r=confirm_booking&start="+start,
			data: "",
			success: function(response) {
						
				$("#confirm").fadeOut();
				$("#response").html(response);
			}
		});
		
		},
		
		editable: true,
		draggable: true,
		droppable: false
	});
});
</script>
<script type="text/javascript">
$jquery(function() {
$jquery(".delete").click(function(){
var element = $(this);
var del_id = element.attr("id");
var info = 'id=' + del_id;
if(confirm("Are you sure you want to delete this?"))
{
$jquery.ajax({
   type: "POST",
   url: "<?php print SITEURL?>/delete.php",
   data: info,
   success: function(){ 
 }
});
 $jquery(this).parents(".show").animate({ backgroundColor: "#003" }, "slow")
  .animate({ opacity: "hide" }, "slow");
 }
return false;
});
});
</script>


	
	   <div class="rightcal">
	   <div id="calendar"></div>
			    </div>
                <div class="pull-right align-right margin-10">
				<p hidden="hidden" id="start"></p>
				<br/><div id="response"></div>
			</div>
		</div>



			<?php 
			//$link = mysqli_connect('localhost','root','','crmnew') or die("Error " . mysqli_error($link));
			//var_dump($link);
           /* if (mysqli_connect_errno()){
            echo "Failed to connect to mysqli: " . mysqli_connect_error();
            exit;
                                       }*/
	$count = strip_tags("select count(*) from `jqcalendar` where `StartTime` LIKE '%".$_GET['start']."%'");
	$countquery = mysqli_query($link,$count);
	while($count1 = mysqli_fetch_array($countquery)){
				}
	$sql=strip_tags("SELECT  * from `jqcalendar` where `StartTime` LIKE '%".date('Y-m-d')."%'");
	$result=mysqli_query($link,$sql);
   $res=mysqli_num_rows($result);
     
      ?>
	 <div id="today" class="pull-right align-right margin-20" >
	 <div class="do_list_wrap" style="margin-top:10px;margin-right:100px;color:#3c8dbc; width:100px;"><b>To do List</b></div>
	 <div class="today_wrapper">
		<h2 style="text-align:center; width:100%;"><?php echo "Today"; ?></h2>
		<ul class="food_timings">
			<?php
			if($res>0){
			$i=1;
			while($row=mysqli_fetch_array($result,MYSQLI_ASSOC)){ 
			
			?>
            <?php if($_SESSION['name']==$row['name_id']){ ?>
            <li class="show" style="word-wrap:break-word;"><?php echo $row['Subject']; ?><span class="action"><a href="#" id="<?php echo $row['Id']; ?>" class="delete" title="Delete"><img src="<?php print SITEURL?>/images/delete_img_19.png"></a></span></li>
			<?php
			}
				$i++; 
			
			}
			
			}else{ 	
			echo "<li style='background-color:#fff; position:relative; right:25px; padding:12px 0px; text-align:center; font-size:18px; color:#f00; opacity:2;'>No Events</li>";}
			?>
			
		</ul>          
		<a href="<?php print SITEURL?>/ToDoList"><input type="button" value="View All Events" style=" background-color:#3c8dbc; -webkit-border-radius:10px; -moz-border-radius:10px; border-radius:10px; width:90%; height:35px; border:none; color:#fff; font-family:'Open Sans', sans-serif; font-weight:600; font-size:16px; margin-top:20px; text-decoration:underline; text-align:center;"></a>
		<div class="clear_fix"></div>            
	</div>
</div>
         <?php ?>             
            </div>
                </div>	
                  <div class="clear_fix"></div>
                    </div>        
                      </div>