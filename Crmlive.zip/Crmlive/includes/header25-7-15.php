<?php include_once('headermeta.php');
//print_r($_SESSION);

$duration = (70 * 60);

if(isset($_SESSION['started']))
{
    // show banner and hide form
    if((time() - $_SESSION['started'] - $duration) > 0)
    {
       header("Location:logout.php?errormessage=session");
    }
}
else
{
  $_SESSION['started'] = time();
}
?>

<?php if($_SESSION['id']!="")
{
?>
  <body class="skin-blue">
  <div class="wrapper">
  <header class="main-header">
        <!-- Logo -->
        <a href="<?php echo $SITEURL;?>/Dashboard" class="logo">
        <!-- 
        <b>Admin</b>LTE-->
        <img src="<?php echo SITEURL;?>/images/login_logo_03new.png" />
        </a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <!-- <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
          </a> -->
          <div class="box-tools pull-right">
                    <div class="has-feedback" style="text-align:center;">
                     
                      <!--<span class="glyphicon glyphicon-search form-control-feedback"></span>-->
                    </div>
                  </div>
       <!--  <div class="login_img" style="float:right;width:20%; background:#000;">
             
              <ul class="dropdown">
              
             <a href="#"><span style="color:#fff;">Your Logged in as <?php echo $_SESSION['name']; ?></span></a>
        		<ul >
        		<a href="<?php print SITEURL?>/logout.php">	<span style="color:#fff;">Logout</span></a>
             	</ul>
              
               <!--<select><option>John Doe</option></select>
             </ul>
             
             </div>-->
             
             <div class="search_wrapper">
            <?php if($_SESSION['role']=='sales')
			{
			?>
    
			 <?php } ?>
			 <div class="search_icon">
			 <?php if($_SESSION['role']=='sales')
		{
		/*echo "<div style='background-color:#3b3b43;height: 49px;'><span style='color:#3c8dbc;font-size:20px;'> Total Leads : ".$leadscount."</span></div>";*/
		}
		?>
             </div>
             
             <div class="icons_wrap"><a href="<?php print SITEURL; ?>/ToDoList"><img src="<?php print SITEURL?>/images/alarm.png" height="15" width="15" style="margin-top:20px;margin-left:20px;"><div class='circle'><?php echo  $getcount; ?></div></a></div>
             
             <div class="login_img" style="float:right;width:28%;">
             
              <ul class="dropdown" style="padding-top:14px;">
               
              <li>
              <a href="#"><span style="color:#fff; font-size:16px;">Your Logged in as <?php echo $_SESSION['name']; ?></span></a>
                <a href="<?php print SITEURL?>/logout.php"><span style="color:#fff; font-size:16px; background-color:#000; -webkit-box-shadow: 4px 4px 24px -4px rgba(0,0,0,0.75);
-moz-box-shadow: 4px 4px 24px -4px rgba(0,0,0,0.75);
box-shadow: 4px 4px 24px -4px rgba(0,0,0,0.75); padding: 3px;">Logout</span></a>
                </li>
               <!--<select><option>John Doe</option></select>-->
             </ul>
             
             </div>
             
             <div class="clear_fix"></div>
             
            </div>
             
             
        </nav>
        
      </header>
      
      <script type="text/javascript" src="<?php echo SITEURL?>/js/graphs/canvasjs.min.js"></script>
      
      <?php }?>