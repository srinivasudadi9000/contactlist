<?php include_once('headermeta.php');
$_SESSION['count']=$getDDRCount;


?>
<script type="text/javascript">
var foo="<?php echo $_SESSION['count'] ?>";
//alert(foo);

</script>
<?php if($_SESSION['id']!="")
{
?>
  <body class="skin-blue">
  <div class="wrapper">
  <header class="main-header">
        <!-- Logo -->
        <a href="<?php echo SITEURL;?>/Dashboard" class="logo">
        <!-- 
        <b>Admin</b>LTE-->
        <img src="<?php echo SITEURL;?>/images/login_logo_03new.png" />
        </a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <!-- <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
          </a> -->
          <div class="box-tools pull-right">
                    <div class="has-feedback" style="text-align:center;">
                     
                      <!--<span class="glyphicon glyphicon-search form-control-feedback"></span>-->
                    </div>
                  </div>
       <!--  <div class="login_img" style="float:right;width:20%; background:#000;">
             
              <ul class="dropdown">
              
             <a href="#"><span style="color:#fff;">Your Logged in as <?php echo $_SESSION['name']; ?></span></a>
        		<ul >
        		<a href="<?php print SITEURL?>/logout.php">	<span style="color:#fff;">Logout</span></a>
             	</ul>
              
               <!--<select><option>John Doe</option></select>
             </ul>
             
             </div>-->
             
             <div class="search_wrapper">
            <?php if($_SESSION['role']=='sales')
			{
			?>
    
			 <?php } ?>
			 <div class="search_icon">
			 <?php if($_SESSION['role']=='sales')
		{
		/*echo "<div style='background-color:#3b3b43;height: 49px;'><span style='color:#3c8dbc;font-size:20px;'> Total Leads : ".$leadscount."</span></div>";*/
		}
		?>
             </div>
             <div class="icons_wrap"><a href="<?php //print SITEURL; ?>/ToDoList" class="icon_image">
             	<?php /*?><img src="<?php print SITEURL?>/images/alarm.png" height="15" width="15" style="margin-top:20px;margin-left:20px;visibility: hidden;">
             	<div class='circle' style="visibility: hidden;"><?php //echo  $getcount; ?></div><?php */?></a>
             <div class="ddrblg_right">
        	<a href="<?php print SITEURL; ?>/ADD_DDR" style="padding:18px;"><input type="submit" value="DDR +"></a>
             <!--  <a href="<?php //print SITEURL; ?>/ADD_DDR">
             	<img src="<?php //print SITEURL; ?>/images/addsymbol_03.png" alt="" class="addsymbol"></a>
             -->
            <a href="<?php print SITEURL; ?>/DDR_LIST"><img src="<?php print SITEURL; ?>/images/orangeicon_03.png" alt="" class="markimg"></a>
              <?php if($getDDRCount) { ?>
            <span><?php echo $getDDRCount; ?></span>
            <?php } ?>
        </div><!--ddrblg_right-->
        <div class="clear_fix"></div>
             
             </div>
             
             <div class="login_img" style="float:right;width:28%;margin-right: 15%;">
             
              <ul class="dropdown" style="">
               
              <li>
              <a href="#"><span style="color:#fff; font-size:16px;">Your Logged in as <?php echo $_SESSION['name']; ?></span></a>
                <a href="<?php print SITEURL?>/logout.php"><span style="color:#fff; font-size:16px; background-color:#000; -webkit-box-shadow: 4px 4px 24px -4px rgba(0,0,0,0.75);
-moz-box-shadow: 4px 4px 24px -4px rgba(0,0,0,0.75);
box-shadow: 4px 4px 24px -4px rgba(0,0,0,0.75); padding: 3px;">Logout</span></a>
                </li>
               <!--<select><option>John Doe</option></select>-->
             </ul>
             
             </div>
              <form action="" method="post" name="search">
            	<div class="login_img" style="float:right;width:18%; ">
             		<input type="text" name="lead_search" id="search" value="<?php echo $_GET['result']?>" style="float:left;width: 75%;height: 25px">
					<input type="submit" name="search" value="search" style="float:right; margin-left:-22px;">
             	</div>
             </form>
             <div class="clear_fix"></div>
             
            </div>
             
             
        </nav>
        
      </header>
      
      <script type="text/javascript" src="<?php echo SITEURL?>/js/graphs/canvasjs.min.js"></script>
      
      <?php }?>
