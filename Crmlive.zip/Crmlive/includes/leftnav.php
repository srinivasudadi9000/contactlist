<?php 

$coldleadcount=$customerObj->getCountNumber('Cold_Lead',$_SESSION['id']);

$opencount=$customerObj->getCountNumber('Open',$_SESSION['id']);

$teedcount=$customerObj->getCountNumber('Teed',$_SESSION['id']);

$closedcount=$customerObj->getCountNumber('Closed',$_SESSION['id']);

$deadcount=$customerObj->getCountNumber('Dead',$_SESSION['id']);

$dudcount=$customerObj->getCountNumber('Dud',$_SESSION['id']);

$drivecount=$customerObj->getCountNumber('Drive',$_SESSION['id']);

$eveningcount=$customerObj->getCountNumber('Evening_Call',$_SESSION['id']);

$clientcount=$customerObj->getCountNumber('Client',$_SESSION['id']);

$employeeleadcount=$customerObj->getleadCount($_SESSION['id']);

$deletedleadlist=$customerObj->getDeleteLeadCount($_SESSION['id']);
?>

<aside class="main-sidebar">

        <!-- sidebar: style can be found in sidebar.less -->

        <section class="sidebar">
          <div class="user-panel">
            <div class="pull-left image">
            </div>
          </div>
          <?php if($_SESSION['role']=='admin'){ ?>

          <ul class="sidebar-menu">

            <li class="<?php if(basename($_SERVER['PHP_SELF'])=="dashboard.php") {?>class="active" <?php } ?> treeview">
              <a href="<?php print SITEURL?>/Dashboard" class="dashbaord_icon active">  <i class="fa fa-dashboard"></i> <span>Dashboard</span></a><i class="fa fa-angle-left pull-right"></i>

            </li>

              <li class="<?php if(basename($_SERVER['PHP_SELF'])=="changepassword.php") {?>class="active" <?php } ?> treeview">
              <a href="<?php print SITEURL?>/ChangePassword" class="dashbaord_icon active">  <i class="fa fa-dashboard"></i> <span>Change Password</span></a><i class="fa fa-angle-left pull-right"></i>
            </li>
            
            <li class="<?php if(basename($_SERVER['PHP_SELF'])=="changeemployeepassword.php") {?>class="active" <?php } ?> treeview">
              <a href="<?php print SITEURL?>/ChangeEmployeePassword" class="dashbaord_icon active">  <i class="fa fa-dashboard"></i> <span>Change EmployeePassword</span></a><i class="fa fa-angle-left pull-right"></i>
            </li>

             <li class="<?php if(basename($_SERVER['PHP_SELF'])=="paidbusiness.php") {?>class="active" <?php } ?> treeview">

              <a href="<?php print SITEURL?>/PaidBusiness" class="dashbaord_icon active">  <i class="fa fa-dashboard"></i> <span>Paid Business</span></a><i class="fa fa-angle-left pull-right"></i>

            </li>

             <li <?php if(basename($_SERVER['PHP_SELF'])=="board.php") {?>class="active" <?php } ?>><a href="<?php print SITEURL?>/AdminBoard" class="board_icon active"> <i class="fa fa-dashboard"></i>  <span>The Board</span></a><i class="fa fa-angle-left pull-right"></i></li>

             <li class="<?php if(basename($_SERVER['PHP_SELF'])=="leedslist.php") {?>class="active" <?php } ?> treeview">

              <a href="#" class="dashbaord_icon active">  <i class="fa fa-dashboard"></i> <span>Leads</span>

              <i class="fa fa-angle-left pull-right"></i></a>

               <ul class="treeview-menu">

              <li <?php if(basename($_SERVER['PHP_SELF'])=="leedslist.php") {?>class="active" <?php } ?> ><a href="<?php print SITEURL?>/Leads/1">  <i class="fa fa-circle-o"></i><span>View Leads List</span></a></li>

                <li  <?php if(basename($_SERVER['PHP_SELF'])=="customerregistration.php") {?>class="active" <?php } ?>><a href="<?php print SITEURL?>/CustomerRegistration" class="add_icon active">  <i class="fa fa-circle-o"></i><span>Add New Lead</span></a></li>

                </ul>

                </li>

              </li>

              

              

              <li class="<?php if(basename($_SERVER['PHP_SELF'])=="paidbusiness.php") {?>class="active" <?php } ?> treeview">

              <a href="#" class="dashbaord_icon active">  <i class="fa fa-dashboard"></i> <span>Employees</span> 

              <i class="fa fa-angle-left pull-right"></i></a>

              <ul class="treeview-menu">

               <li <?php if(basename($_SERVER['PHP_SELF'])=="employeelist.php") {?>class="active" <?php } ?> ><a href="<?php print SITEURL?>/EmployeeList"> <i class="fa fa-circle-o"></i><span>View Employee List</span></a></li>

               <li  <?php if(basename($_SERVER['PHP_SELF'])=="registration.php") {?> class="active"<?php } ?>><a href="<?php print SITEURL?>/Register" class="dashbaord_reg active"> <i class="fa fa-circle-o"></i> <span>Add New Employee</span></a></li>

                

              </ul>

            

              </li>
 <li <?php if(basename($_SERVER['PHP_SELF'])=="datadriverequest.php") {?>class="active" <?php } ?>><a href="<?php print SITEURL?>/DDR_LIST" class="board_icon active"> <i class="fa fa-dashboard"></i>  <span>Assigned DDR List</span></a><i class="fa fa-angle-left pull-right"></i></li>
 
  <li <?php if(basename($_SERVER['PHP_SELF'])=="saved_driveslists.php") {?>class="active" <?php } ?>><a href="<?php print SITEURL?>/SAVE_DDR_LIST" class="board_icon active"> <i class="fa fa-dashboard"></i>  <span>Not Assigned DDR List</span></a><i class="fa fa-angle-left pull-right"></i></li>
				

        		<li  <?php if($_GET['status']=="Cold_Lead") {?>class="active" <?php } ?>><a href="<?php print SITEURL?>/CustomerList/Cold_Lead" class="cold_lead_icon">  <i class="fa fa-cog" style="margin-right: 6px;"></i><span>Cold Lead &nbsp;&nbsp;</span></a></li>

               <li <?php if($_GET['status']=="Open") {?>class="active" <?php } ?>><a href="<?php print SITEURL?>/CustomerList/Open" class="open_icon">    <i class="fa fa-envelope"></i> <span>Week Opens &nbsp;&nbsp;</span></a></li>

             <li <?php if($_GET['status']=="Teed") {?>class="active" <?php } ?>><a href="<?php print SITEURL?>/CustomerList/Teed" class="teed_icon"><i class="fa fa-envelope"></i> <span>Teed &nbsp;&nbsp;</span></a></li>

             <li <?php if($_GET['status']=="Closed") {?>class="active" <?php } ?>><a href="<?php print SITEURL?>/CustomerList/Closed" class="closed_icon">   <i class="fa fa-unlock"></i><span>Closed &nbsp;&nbsp;</span></a></li>

              <li <?php if($_GET['status']=="Client") {?>class="active" <?php } ?>><a href="<?php print SITEURL?>/CustomerList/Client" class="client_icon"> <i class="fa fa-dashboard"></i> <span>Client&nbsp;&nbsp;</span></a></li>

                  <li <?php if($_GET['status']=="Dead") {?>class="active" <?php } ?>><a href="<?php print SITEURL?>/CustomerList/Dead" class="dead_icon"> <i class="fa fa-dashboard"></i>  <span>Dead &nbsp;&nbsp;</span></a></li>

               <li <?php if($_GET['status']=="Dud") {?>class="active" <?php } ?>><a href="<?php print SITEURL?>/CustomerList/Dud" class="dud_icon"> <i class="fa fa-dashboard"></i> <span>Dud &nbsp;&nbsp;</span></a></li>

                  <li <?php if($_GET['status']=="Drive") {?>class="active" <?php } ?>><a href="<?php print SITEURL?>/CustomerList/Drive" class="drive_icon">  <i class="fa fa-dashboard"></i><span>Drives &nbsp;&nbsp;</span></a></li>
       

            <li <?php if($_GET['status']=="Evening_Call") {?>class="active" <?php } ?>><a href="<?php print SITEURL?>/CustomerList/Evening_Call" class="evngcall_icon"><i class="fa fa-phone"></i> <span>Evening Call&nbsp;&nbsp;</span></a></li>

            

             <li <?php if($_GET['status']=="Closed") {?>class="active" <?php } ?>><a href="<?php print SITEURL?>/ClosedList/Closed" class="closed_icon"><i class="fa fa-dashboard"></i> <span>Closed List</span></a></li>

              
  <li <?php if($_GET['status']=="Pulled_Client") {?>class="active" <?php } ?>><a href="<?php print SITEURL?>/CustomerList/Pulled_Client" class="closed_icon"><i class="fa fa-dashboard"></i> <span>Pulled Client</span></a></li>
    
	 <li  <?php if(basename($_SERVER['PHP_SELF'])=="deletedleadlist.php") {?> class="active"<?php } ?>><a href="<?php print SITEURL?>/DeleteLeads" class="dashbaord_reg active"> </i> <span>Deleted Leads List(<?php echo $deletedleadlist;?>)</span></a></li>            

          </ul>

           <?php } if($_SESSION['role']=='sales'){ ?>

                     <ul class="sidebar-menu">

         <!--   <li class="header">MAIN NAVIGATION</li> -->

            

           <li class="<?php if(basename($_SERVER['PHP_SELF'])=="dashboard.php") {?>class="active" <?php } ?> treeview">

              <a href="<?php print SITEURL?>/Dashboard" class="dashbaord_icon active">  <i class="fa fa-dashboard"></i> <span>Dashboard</span></a><i class="fa fa-angle-left pull-right"></i>

            

            

            </li>

            

             <li class="<?php if(basename($_SERVER['PHP_SELF'])=="paidbusiness.php") {?>class="active" <?php } ?> treeview">

              <a href="<?php print SITEURL?>/PaidBusiness" class="dashbaord_icon active">  <i class="fa fa-dashboard"></i> <span>Paid Business</span></a><i class="fa fa-angle-left pull-right"></i>

            

            </li>

               <li class="<?php if(basename($_SERVER['PHP_SELF'])=="paidbusiness.php") {?>class="active" <?php } ?> treeview">

              <a href="<?php print SITEURL?>/SalesBoard" class="dashbaord_icon active">  <i class="fa fa-dashboard"></i> <span>The Board</span></a><i class="fa fa-angle-left pull-right"></i>

              </li>

              <li class="<?php if(basename($_SERVER['PHP_SELF'])=="paidbusiness.php") {?>class="active" <?php } ?> treeview">

              <a href="<?php print SITEURL?>/notes.php" class="dashbaord_icon active"><i class="fa fa-comment"></i>

<span>Notes</span>

              </i></a>

               

                </li>



             <li  <?php if($_GET['status']=="Cold_Lead") {?>class="active" <?php } ?>><a href="<?php print SITEURL?>/CustomerList/Cold_Lead" class="cold_lead_icon">  <i class="fa fa-cog" style="margin-right: 6px;"></i><span>Cold Lead &nbsp;&nbsp;(<?php echo $coldleadcount;?>)</span></a></li>

     

             <li <?php if($_GET['status']=="Open") {?>class="active" <?php } ?>><a href="<?php print SITEURL?>/CustomerList/Open" class="open_icon">    <i class="fa fa-envelope"></i> <span>Week Opens &nbsp;&nbsp;(<?php echo $opencount;?>)</span></a></li>



             <li <?php if($_GET['status']=="Teed") {?>class="active" <?php } ?>><a href="<?php print SITEURL?>/CustomerList/Teed" class="teed_icon"><i class="fa fa-envelope"></i> <span>Teed &nbsp;&nbsp;(<?php echo $teedcount;?>)</span></a></li>



             <li <?php if($_GET['status']=="Closed") {?>class="active" <?php } ?>><a href="<?php print SITEURL?>/CustomerList/Closed" class="closed_icon">   <i class="fa fa-unlock"></i><span>Closed &nbsp;&nbsp;(<?php echo $closedcount;?>)</span></a></li>



              <li <?php if($_GET['status']=="Client") {?>class="active" <?php } ?>><a href="<?php print SITEURL?>/CustomerList/Client" class="client_icon"> <i class="fa fa-dashboard"></i> <span>Client&nbsp;&nbsp;(<?php echo $clientcount;?>)</span></a></li>



                  <li <?php if($_GET['status']=="Dead") {?>class="active" <?php } ?>><a href="<?php print SITEURL?>/CustomerList/Dead" class="dead_icon"> <i class="fa fa-dashboard"></i>  <span>Dead &nbsp;&nbsp;(<?php echo $deadcount;?>)</span></a></li>



               <li <?php if($_GET['status']=="Dud") {?>class="active" <?php } ?>><a href="<?php print SITEURL?>/CustomerList/Dud" class="dud_icon"> <i class="fa fa-dashboard"></i> <span>Dud &nbsp;&nbsp;(<?php echo $dudcount;?>)</span></a></li>

               

              

                <li <?php if($_GET['status']=="Drive") {?>class="active" <?php } ?>><a href="<?php print SITEURL?>/CustomerList/Drive" class="drive_icon">  <i class="fa fa-dashboard"></i><span>Drives &nbsp;&nbsp;(<?php echo $drivecount;?>)</span></a></li>



        

            <li <?php if($_GET['status']=="Evening_Call") {?>class="active" <?php } ?>><a href="<?php print SITEURL?>/CustomerList/Evening_Call" class="evngcall_icon"><i class="fa fa-phone"></i> <span>Evening Call&nbsp;&nbsp;(<?php echo $eveningcount;?>)</span></a></li>

           

            <li <?php if(basename($_SERVER['PHP_SELF'])=="employeeleads.php"){?>class="active" <?php } ?>><a href="<?php print SITEURL?>/EmployeeLeads/1" class="drive_icon">  <i class="fa fa-dashboard"></i><span>Employee Leads &nbsp;&nbsp;(<?php echo $employeeleadcount;?>)</span></a></li>

          </ul>

               <?php } ?>

        </section>

        <!-- /.sidebar -->

      </aside>