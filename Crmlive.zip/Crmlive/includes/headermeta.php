<?php 
include('dbconfig.php');
include('includes/dbconnection.php');


include("model/user.class.php");
include("model/customer.class.php");
include("model/employee.class.php");
$userObj=new userClass();
$customerObj=new customerClass();
$empObj=new employeeClass();
$getcount = $userObj->getcount();
$leadscount = $userObj->getTotalLeadsCount($_SESSION['id']);
$allAlerts = $userObj->getAllAlerts($_SESSION['id']);
$getDDRCount = $userObj->getDDRCount($_SESSION['id']);
//if ($_POST['search']=='Search') {
//print_r($_POST); exit; 
//$allleads->getSearchResults($start,$limit,$serachword);
//header("location:".SITEURL."/CustomerList/".$_GET['status']."?searchword=".$_POST['searchlead']);
//header("location:".SITEURL."/searchlist.php?status=".$_GET['status']."&searchword=".$_POST['searchlead']);
//}	
$msg = $userObj->getadmincount();
$getadmincount=$msg->messageCount;
if(isset($_POST['search'])) {
	if ($_POST['search']=='search'){
		header("Location:".SITEURL.'/SearchResult/1/'.$_POST['lead_search']);
		
		//$getsearchdata=$userObj->getSearchdata($_POST['lead_search']);
		//$allleads->getSearchResults($start,$limit,$serachword);
		//header("location:".SITEURL."/CustomerList/".$_GET['status']."?searchword=".$_POST['searchlead']);
		//header("location:".SITEURL."/searchlist.php?status=".$_GET['status']."&searchword=".$_POST['searchlead']);
	}	
}
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
      <link rel="shortcut icon" href="<?php echo SITEURL; ?>/images/favicon.png">
    <title>CRM | Dashboard</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 3.3.2 -->
    <link href="<?php echo SITEURL;?>/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />    
    <!-- FontAwesome 4.3.0 -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons 2.0.0 -->
    <link href="http://code.ionicframework.com/ionicons/2.0.0/css/ionicons.min.css" rel="stylesheet" type="text/css" />    
    <!-- Theme style -->
    <link href="<?php echo SITEURL;?>/dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <!-- AdminLTE Skins. Choose a skin from the css/skins 
         folder instead of downloading all of them to reduce the load. -->
    <link href="<?php echo SITEURL;?>/dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />
    <!-- iCheck -->
    <link href="<?php echo SITEURL;?>/plugins/iCheck/flat/blue.css" rel="stylesheet" type="text/css" />
    <!-- Morris chart -->
   <!-- <link href="<?php echo SITEURL;?>/plugins/morris/morris.css" rel="stylesheet" type="text/css" /> -->
    <!-- jvectormap -->
  <!--   <link href="<?php echo SITEURL;?>/plugins/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" /> -->
    <!-- Date Picker -->
    <link href="<?php echo SITEURL;?>/plugins/datepicker/datepicker3.css" rel="stylesheet" type="text/css" />
    <!-- Daterange picker -->
   <!-- <link href="<?php echo SITEURL;?>/plugins/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" /> -->
    <!-- bootstrap wysihtml5 - text editor -->
   <!-- <link href="<?php echo SITEURL;?>/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" /> -->
    
    <link rel="stylesheet" type="text/css" href="<?php print SITEURL?>/css/style.css"/>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
  </head>
  <script type="text/javascript">
var auto_refresh = setInterval(
function ()
{
 
 //var ddrcount = "<?php //echo $userObj->getDDRCount($_SESSION['id']);?>";
 var recent_ddrcount = "<?php echo $userObj->getRecentDDRCount($_SESSION['id']);?>";
 console.log("recent_ddrcount : "+recent_ddrcount);
 if(parseInt(recent_ddrcount) > 0) {
  alert('you hav received new ddr request');
 }
 
}, 30000); // refresh every 10000 milliseconds
</script>



<script type="text/javascript"> 
function display_c(){
var refresh=1000; // Refresh rate in milli seconds
mytime=setTimeout('display_ct()',refresh)
}

function display_ct() {
var strcount
var x 
var x1
var currentTime = new Date()
var month = currentTime.getMonth() + 1
var day = currentTime.getDate()
var year = currentTime.getFullYear()

var hours = currentTime.getHours()
var minutes = currentTime.getMinutes()
var seconds= currentTime.getSeconds()
 //x=month + "-" + day + "-" + year
 

if (month < 10){
 month = "0" + month
 }
 if (day < 10){
  day = "0" + day
 }
 var currentDate=year + "-" + month + "-" + day
if (minutes < 10){
minutes = "0" + minutes
}
if (seconds < 10){
 seconds = "0" + seconds
}

x=hours + ":" + minutes +":"+seconds+" "
<?php foreach($allAlerts as $get_allDDRDetails) {?>
var alertDateTime = "<?php echo $get_allDDRDetails->alert_time;?>";
var Company = "<?php echo $get_allDDRDetails->company_name;?>";
//console.log("Company : "+Company);
var str1 = alertDateTime.split(" ");
var datePart = str1[0];
var timePart = str1[1];
var str2 = timePart.split(":");
var hours1 = str2[0];
var minutes1 = str2[1];
var seconds1 = str2[2];
x1=hours1 + ":" + minutes1 + ":"+seconds1+" "

var datePart1 ="'"+datePart+"'";
var currentDate1 ="'"+currentDate+"'";

if(datePart == currentDate) {
 console.log("x : "+x);
 console.log("x1 : "+x1);
	if(x==x1)
	 {
	  alert("You have reminder now for DDR of Company : "+Company);
	 }
 }
 
<?php }  ?>

document.getElementById('ct').innerHTML = x;
tt=display_c();
 }
</script>
<body onload="display_ct();">
<span id='ct' style="display: none;visibility: hidden;"></span>
