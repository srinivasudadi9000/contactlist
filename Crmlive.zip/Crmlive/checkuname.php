<?php
include('dbconfig.php');
include('includes/dbconnection.php');
if(isset($_GET['uname']))
{   //echo "hi" ; exit;  
		 $query="SELECT * FROM crm_user_login WHERE username='".$_GET['uname']."'";
		
		$res=mysql_query($query) or die(mysql_error());
		$result=mysql_num_rows($res);
		//echo $result;exit;
		if($result>0)
		{
			echo 1;
		}
		else
		{
		    echo 2;
			return true;
		}
		
		
}
    
	
?>
