<?php 
include('dbconfig.php');
include('includes/dbconnection.php');
include("model/user.class.php");
include("model/customer.class.php");
include("model/employee.class.php");
$userObj=new userClass();
$empObj=new employeeClass();
$customerObj=new customerClass();
//echo $_GET['id'];
/*
$query="SELECT * FROM crm_customer_list WHERE id='".$_GET['cid']."'";
$details=$callConfig->getRow($query);
//print_r($details);
$result=(array)$details;
echo json_encode($result); 

$duration = (100 * 60);

if(isset($_SESSION['started']))
{
    // show banner and hide form
    if((time() - $_SESSION['started'] - $duration) > 0)
    {
       header("Location:".SITEURL."/logout.php?errormessage=session");
    }
}
else
{
  $_SESSION['started'] = time();
}
*/
?>

				
                    <div id="testDiv4" style="padding-left: 10px;" >
                    <?php if($_GET['cid']!="" && $_GET['status']!="")
					{
					$userObj->updateLeadStatus($_GET['cid']);
					?>
					<!--<div class="editprofile">
					<span style="float:right;"> <a href="<?php print SITEURL?>/testing.php?id=<?php echo $_GET['cid'];?>" class='fancybox fancybox.ajax'>Edit Lead</a></span>
                     </div>-->
					<?php 
					
					$previous_id=$userObj->getPreviousRecord($_GET['cid'],$_GET['status']);
					  $next_id=$userObj->getNextRecord($_GET['cid'],$_GET['status']);
					if($_SESSION['role']=="sales")
					{
					if($previous_id=="")
					{
					echo "";
					}
					else
					{
					?>
				<div class="previousrecord">	<a href="#" onclick="getLeadDetails(<?php echo $previous_id?>,'<?php echo  $_GET['status']?>')"><span style="margin-left:-10px;"><img src="<?php print SITEURL?>/images/next-back_06.png"/></span></a></div>
					
					<?php 
					}
					if($next_id=="")
					{
					echo "";
					}
					else
					{
					?>
			
					<div class="nextrecord" ><a href="#" onclick="getLeadDetails(<?php echo $next_id?>,'<?php echo  $_GET['status']?>')"><span style="float:right;margin-right: 14px;"><img src="<?php print SITEURL?>/images/next-back_03.png"/></span></a></div>
					<?php
					}
					}
					$customerdetails=$customerObj->getCustomerData($_GET['cid']);
					$getcomments = $customerObj->getComment($_GET['cid']);
					$customerAnswer=$customerObj->getCustomerAnswer($_GET['cid']); 			//to get customer Question answers
					
						//print_r($customerAnswer);
					//print_r($getcomments);

						?>
                         <div style="width:100%; clear:both;"></div>
						<form name="customerdeatails" method="post" >

                       <ul class="navinner_list">
                        <li>Last updated on <?php echo $customerdetails->createdon ?></li>
                       <div class="editprofile" style="position:relative; bottom:24px;">
					<span style="float:right;"> <a href="<?php print SITEURL?>/testing.php?id=<?php echo $_GET['cid'];?>" class='fancybox fancybox.ajax'>Edit Lead</a></span>
                     </div>
                            <li><a href="#"><img src="<?php print SITEURL?>/images/contact_imgs_31.png"> <?php echo $customerdetails->title." ".$customerdetails->firstname." ".$customerdetails->lastname; ?></a></li>
                            <li><a href="#"><img src="<?php print SITEURL?>/images/contact_imgs_36.png"> <?php echo $customerdetails->email; ?></a></li>
                            <li><img src="<?php print SITEURL?>/images/contact_imgs_43.png"> <span class="big_font">+44<?php echo substr($customerdetails->phone_number,1); ?></span></li>
                             <li><img src="<?php print SITEURL?>/images/phone_icon.png"> <span class="big_font">+44<?php echo substr($customerdetails->mobile_number,1); ?></span></li>
                              <li><img src="<?php print SITEURL?>/images/phone_icon.png"> <?php echo $customerdetails->company; ?></li>
                            <li><a href="#"><img src="<?php print SITEURL?>/images/address_icon.png"> <?php echo $customerdetails->address."</br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$customerdetails->town."</br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$customerdetails->postcode; ?></a></li>
                              
                       	<input type="hidden" name="hidden_id" value="<?php print $customerdetails->id?>"/>
                       	

                       </ul>
                        <div class="questions" >
					<ul class="innerques" style="padding:0px;">
                    <input type="hidden" name="action" value="<?php echo $customerAnswer->customer_id?>" />
                        <li><span>Interested in reco:&nbsp;&nbsp;&nbsp;</span><textarea cols="30" rows="2" class="textarea" name="q1_reco"><?php echo $customerAnswer->q1_reco;?></textarea></li>
                  <li><span>Occupation? Retired?:&nbsp;&nbsp;&nbsp;</span>
                  <textarea cols="30" rows="2" class="textarea" name="q2_retired"><?php echo $customerAnswer->q2_retired;?></textarea></li>
                        <li><span>Portfolio?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q19_portfolio"><?php echo $customerAnswer->q19_portfolio;?></textarea></li>
                   <li><span>Do they have a broker?:&nbsp;&nbsp;&nbsp;</span>
                   <textarea cols="30" rows="2" class="textarea" name="q3_broker"><?php echo $customerAnswer->q3_broker;?></textarea></li>
                        <li><span>Tell them about AtoZ service:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q4_service"><?php echo $customerAnswer->q4_service;?></textarea></li>
                        <li><span>Level of investment?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q5_investment"><?php echo $customerAnswer->q5_investment;?></textarea></li>
                        <li><span>Interested in Growth,Income?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q6_income"><?php echo $customerAnswer->q6_income;?></textarea></li>
                        <li><span>Can they make a decision?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q7_decision"><?php echo $customerAnswer->q7_decision;?></textarea></li>
                        <li><span>Mobile?E-mail?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q8_email"><?php echo $customerAnswer->q8_email;?></textarea></li>
                        <li><span>Best time to call?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q9_call"><?php echo $customerAnswer->q9_call;?></textarea> </li>
                        <li><span>Mentioned commodities?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q10_commodities"><?php echo $customerAnswer->q10_commodities;?></textarea></li>
                        <li><span>Tell them we make people Money?Again and again:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q11_money"><?php echo $customerAnswer->q11_money;?></textarea></li>
                        <li><span>What sectors do they like?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q12_sectors"><?php echo $customerAnswer->q12_sectors;?></textarea></li>
                        <li><span>Give Company Details?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q13_company"><?php echo $customerAnswer->q13_company;?></textarea></li>
                        <li><span>I.D:&nbsp;&nbsp;&nbsp;</span><textarea cols="30" rows="2" class="textarea" name="q14_id"><?php echo $customerAnswer->q14_id;?></textarea></li>
                        <li><span>Hobbies?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q15_hobbies"><?php echo $customerAnswer->q15_hobbies;?></textarea></li>
                        <li><span>Family?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q16_family"><?php echo $customerAnswer->q16_family;?></textarea></li>
                        <li><span>Do they have internet?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q17_internet"><?php echo $customerAnswer->q17_internet;?></textarea></li>
                        <li><span>Are they an active investor?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q18_investor"><?php echo $customerAnswer->q18_investor;?></textarea></li>
                    
					  
                       
                        <!--comment_wrapper-->                       
					  <li><span>Status</span>    
                     <select name="status" id="status" style="width: 230px;float:right;height:30px;">
                    <option value="" >--Select--</option>
                    <option value="Cold_Lead" <?php if($customerdetails->status=="Cold_Lead") { ?>selected="selected"<?php } ?>>Cold Lead</option>
                    <option value="Open" <?php if($customerdetails->status=="Open") { ?>selected="selected"<?php } ?>>Open</option>
                    <option value="Dud" <?php if($customerdetails->status=="Dud") { ?>selected="selected"<?php } ?>>Dud</option>
                     <option value="Teed" <?php if($customerdetails->status=="Teed") { ?>selected="selected"<?php } ?>>Teed</option>
                    <option value="Dead" <?php if($customerdetails->status=="Dead") { ?>selected="selected"<?php } ?>>Dead</option>
                    <option value="Closed" <?php if($customerdetails->status=="Closed") { ?>selected="selected"<?php } ?>>Closed</option>
                    <option value="Drive" <?php if($customerdetails->status=="Drive") { ?>selected="selected"<?php } ?>>Drive</option>
                     <option value="Evening_Call" <?php if($customerdetails->status=="Evening_Call") { ?>selected="selected"<?php } ?>>Evening Call</option>
                    <option value="Client" <?php if($customerdetails->status=="Client") { ?>selected="selected"<?php } ?>>Client</option>
					 <option value="Pulled_Client" <?php if($customerdetails->status=="Pulled_Client") { ?>selected="selected"<?php } ?>>Pulled_Client</option>
					</select></li>
                    </ul>
                    </div>
                     <div class="drivebox" ><input type="text" name="drive_date" placeholder="Drive Date" class="text_large required"  id="onboarddate2" value="<?php print $customerdetails->drive_date; ?>"></div>                   
                    <div class="clear_fix"></div>
                    <div class="reg_btn" >
                      <input type="submit" name="submit" value="Submit"  />              
                    </div> 
                    
                       <div  class="comment_wrapper" >
                        <h3 style="color:1fb5ac;">Messages <strong>: </strong></h3>
                    
                    <div style="border:1px solid #cdcfcf;height:200px;margin-top:20px;overflow:auto;font-size:12px;/*width:470px;*/">
                     <div class="messagesdate" style="border:1px solid #cdcfcf;height:30px;border-top:none;border-left:none;border-right:none;">
                    <p class="sender">Sender</P>
                    <P class="bmessage">Messages</P>
                    <p class="datetime">Date|Time</p>
                     <p class="edit">Edit|Delete</p>
				
					<div style="clear:both;"></div>
					</div>
                    <?php foreach($getcomments as $getcomment){ ?>
					<div id="comment<?php echo $getcomment->id?>">
                    <p style="float:left;width:20%;margin-left:5px;"><?php echo $getcomment->name;?></P>
                    <P style="float:left;width:28%;"><?php echo wordwrap($getcomment->comments,18,"<br>\n",TRUE);?>
                    <p style="float:left;width:30%;"><?php echo $getcomment->inserted_on;?></p>
                    
                    <p style="float:left;"><a href="<?php print SITEURL?>/editcomment.php?commentid=<?php echo $getcomment->id;?>" class='fancybox fancybox.ajax'><img src="<?php echo SITEURL;?>/images/edit_03.png" /></a>/<a href="#" onclick="deleteComment(<?php echo $getcomment->id;?>)" ><img src="<?php echo SITEURL;?>/images/delete1.png" /></a> </p>
                    <div style="clear:both;"></div>
					 </div> 
					<?php } ?>
                   
                    </div>
                    
                     <div class="comment_wrapper">
                     <h3>Comments</h3>       
                      <textarea name="comments" style="height:80px;"><?php //echo $customerdetails->comments?></textarea>
                    </div>
                      
                        <div class="reg_btn" style="margin-top:20px;">
                          <input type="hidden" name="hidden_name" value="<?php echo $_SESSION['name']; ?>" />
                      <input type="submit" name="comment" value="Submit" class="reg_btn" />              
                    </div>
             
            </form>
            <?php } 
			else if($_GET['status']!="" && $_GET['cid']=="")
			{
				 if(!empty($allcustomerlist))
				 {
				$customerdetails=$customerObj->getCustomerData($customer[0]);
				$getcomments = $customerObj->getComment($customer[0]);
				$customerAnswer=$customerObj->getCustomerAnswer($customer[0]); 		
				//print_r($customerAnswer);
				
				?>
                 <div style="width:100%; clear:both;"></div>
                <form name="customerdeatails" method="post" >

                       <ul class="navinner_list">
                        <li>Last updated on  <?php echo $customerdetails->createdon ?></li>
                            <li><a href="#"><img src="<?php print SITEURL?>/images/contact_imgs_31.png"> <?php echo $customerdetails->title." ".$customerdetails->firstname." ".$customerdetails->lastname; ?></a></li>
                            <li><a href="#"><img src="<?php print SITEURL?>/images/contact_imgs_36.png"> <?php echo $customerdetails->email; ?></a></li>
                            <li><img src="<?php print SITEURL?>/images/contact_imgs_43.png"> <span class="big_font">+44<?php echo substr($customerdetails->phone_number,1); ?></span></li>
                               <li><img src="<?php print SITEURL?>/images/phone_icon.png"> <span class="big_font">+44<?php echo substr($customerdetails->mobile_number,1); ?></span></li>
                                <li><img src="<?php print SITEURL?>/images/phone_icon.png"> <?php echo $customerdetails->company; ?></li>
                            <li><a href="#"><img src="<?php print SITEURL?>/images/address_icon.png"> <?php echo $customerdetails->address."</br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$customerdetails->town."</br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$customerdetails->postcode; ?></a></li>
                       	<input type="hidden" name="hidden_id" value="<?php print $customerdetails->id?>"/>

                       </ul>
					  <div class="questions">
					<ul class="innerques" style="padding:0px;">
                    <input type="hidden" name="action" value="<?php echo $customerAnswer->customer_id?>" />
                        <li><span>Interested in reco:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q1_reco"><?php echo $customerAnswer->q1_reco;?>
                        </textarea></li>
                  <li><span>Occupation? Retired?:&nbsp;&nbsp;&nbsp;</span>
                  <textarea cols="30" rows="2" class="textarea" name="q2_retired"><?php echo $customerAnswer->q2_retired;?>
                   </textarea></li>
                        <li><span>Portfolio?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q19_portfolio"><?php echo $customerAnswer->q19_portfolio;?></textarea></li>
                   <li><span>Do they have a broker?:&nbsp;&nbsp;&nbsp;</span>
                   <textarea cols="30" rows="2" class="textarea" name="q3_broker"><?php echo $customerAnswer->q3_broker;?></textarea></li>
                        <li><span>Tell them about AtoZ service:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q4_service"><?php echo $customerAnswer->q4_service;?></textarea></li>
                        <li><span>Level of investment?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q5_investment"><?php echo $customerAnswer->q5_investment;?></textarea></li>
                        <li><span>Interested in Growth,Income?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q6_income"><?php echo $customerAnswer->q6_income;?></textarea></li>
                        <li><span>Can they make a decision?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q7_decision"><?php echo $customerAnswer->q7_decision;?></textarea></li>
                        <li><span>Mobile?E-mail?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q8_email"><?php echo $customerAnswer->q8_email;?></textarea></li>
                        <li><span>Best time to call?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q9_call"><?php echo $customerAnswer->q9_call;?></textarea> </li>
                        <li><span>Mentioned commodities?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q10_commodities"><?php echo $customerAnswer->q10_commodities;?></textarea></li>
                        <li><span>Tell them we make people Money?Again and again:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q11_money"><?php echo $customerAnswer->q11_money;?></textarea></li>
                        <li><span>What sectors do they like?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q12_sectors"><?php echo $customerAnswer->q12_sectors;?></textarea></li>
                        <li><span>Give Company Details?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q13_company"><?php echo $customerAnswer->q13_company;?></textarea></li>
                        <li><span>I.D:&nbsp;&nbsp;&nbsp;</span><textarea cols="30" rows="2" class="textarea" name="q14_id"><?php echo $customerAnswer->q14_id;?></textarea></li>
                        <li><span>Hobbies?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q15_hobbies"><?php echo $customerAnswer->q15_hobbies;?></textarea></li>
                        <li><span>Family?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q16_family"><?php echo $customerAnswer->q16_family;?></textarea></li>
                        <li><span>Do they have internet ?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q17_internet"><?php echo $customerAnswer->q17_internet;?></textarea></li>
                        <li><span>Are they an active investor?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q18_investor"><?php echo $customerAnswer->q18_investor;?></textarea></li>
                    <li><span>Status</span>    
                     <select name="status" id="status" style="width: 230px;float:right;height:30px;">
                    <option value="" >--Select--</option>
                    <option value="Cold_Lead" <?php if($customerdetails->status=="Cold_Lead") { ?>selected="selected"<?php } ?>>Cold Lead</option>
                    <option value="Open" <?php if($customerdetails->status=="Open") { ?>selected="selected"<?php } ?>>Open</option>
                    <option value="Teed" <?php if($customerdetails->status=="Teed") { ?>selected="selected"<?php } ?>>Teed</option>
                    <option value="Dud" <?php if($customerdetails->status=="Dud") { ?>selected="selected"<?php } ?>>Dud</option>
                    <option value="Dead" <?php if($customerdetails->status=="Dead") { ?>selected="selected"<?php } ?>>Dead</option>
                    <option value="Closed" <?php if($customerdetails->status=="Closed") { ?>selected="selected"<?php } ?>>Closed</option>
                     <option value="Drive" <?php if($customerdetails->status=="Drive") { ?>selected="selected"<?php } ?>>Drive</option>
					 <option value="Evening_Call" <?php if($customerdetails->status=="Evening_Call") { ?>selected="selected"<?php } ?>>Evening Call</option>
                  <option value="Client" <?php if($customerdetails->status=="Client") { ?>selected="selected"<?php } ?>>Client</option>
				   <option value="Pulled_Client" <?php if($customerdetails->status=="Pulled_Client") { ?>selected="selected"<?php } ?>>Pulled_Client</option>
				   </select></li></ul></div>
                    <div class="drivebox" ><input type="text" name="drive_date" placeholder="Drive Date" class="text_large required"  id="cutoffdate1" value="<?php print $customerdetails->drive_date; ?>"></div>
                    <div class="reg_btn">
                      	<input type="hidden" name="hidden_id" value="<?php print $customerdetails->id?>"/>
                      <input type="submit" name="submit" value="Submit" class="reg_btn" />              
                    </div>
                    
                    <div class="comment_wrapper">
                      <h3 style="color:1fb5ac;">Messages <strong>: </strong></h3>
                    
                    <div style="border:1px solid #cdcfcf;height:200px;margin-top:20px;overflow:auto;/*width:470px;/*font-size:12px;">
                     <div class="messagesdate" style="border:1px solid #cdcfcf;height:30px;border-top:none;border-left:none;border-right:none;">
                    <p class="sender">Sender</P>
                    <P class="bmessage">Messages</P>
                    <p class="datetime">Date|Time</p>
                     <p class="edit">Edit|Delete</p>
				
					<div style="clear:both;"></div>
					</div>
                    <?php foreach($getcomments as $getcomment){ ?>
					<div id="comment<?php echo $getcomment->id?>">
                    <p style="float:left;width:20%;margin-left:5px;"><?php echo $getcomment->name;?></P>
                    <P style="float:left;width:28%;"><?php echo wordwrap($getcomment->comments,18,"<br>\n",TRUE);?></P>
                    <p style="float:left;width:30%;"><?php echo $getcomment->inserted_on;?></p>
                    <p style="float:left;"><a href="<?php print SITEURL?>/editcomment.php?commentid=<?php echo $getcomment->id;?>" class='fancybox fancybox.ajax'>Edit</a>/<a href="#" onclick="deleteComment(<?php echo $getcomment->id;?>)" >Delete</a> </p>
                     <div style="clear:both;"></div>
					 </div> 
					<?php } ?>
                      </div>
                        <div class="comment_wrapper">
                     <h3>Comments</h3>       
                      <textarea name="comments" style="height:80px;width:435px;"><?php //echo $customerdetails->comments?></textarea>
                    </div>
                      <div class="reg_btn" style="margin-top:20px;">
                      <input type="hidden" name="hidden_name" value="<?php echo $_SESSION['name']; ?>" />
                      <input type="submit" name="comment" value="Submit" class="reg_btn" />              
                    </div>
                    
                
            </form>
  
                <?php 
			} }
			?>
                  </div>
				  