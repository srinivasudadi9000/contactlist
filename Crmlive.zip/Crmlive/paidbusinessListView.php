<?php include("includes/header.php");

include("includes/leftnav.php");

$userObj->checkloggedin();



if ($_POST["register"] == "submit") {

	$userObj->registerPaid($_POST);

	}

if ($_POST['edit']=="submit") {

	$userObj->editPaidUser($_POST);

	//print_r($_POST);

	}	

if($_GET['action']=="delete")

{



$empObj->deleteEmployeePaidRecord($_GET['eid'],$_GET['empId']);

}



//$insertId;

	$allEmployeeList=$userObj->getAllemployeeslist();

//print_r($allEmployeeList);

	if(!empty($allEmployeeList))

	{		$i=0;

			foreach($allEmployeeList as $emp_list)

			{

					$emp[$i] = $emp_list->id;

					$i++;

			}  

			//print_r($emp);

			

	}

	if($_GET['eid']==""){

		$insertId=$emp[0];

		}

		else{

			$insertId=$_GET['eid'];

			}	

?>

 <script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>

<script type="text/javascript">

    $(document).ready(function(){

        $("#status").change(function(){

		$(".drivebox").hide();

            $( "select option:selected").each(function(){

                if($(this).attr("value")=="Drive"){ 

                    //$(".box").hide();

                    $(".drivebox").show();

                }

                

            });

        }).change();

    });

</script>

    <div class="wrapper">





      <!-- Content Wrapper. Contains page content -->

      <div class="content-wrapper">

       



        <!-- Main content -->

        <section class="content">

          <div class="row">

            <div class="col-md-3">

          

             <div style="height:720px;overflow: hidden;" id="textbox">

              <div class="box box-solid">

                <div class="box-header with-border">

                  <h3 class="box-title">Employees</h3>

                </div>

                <div class="box-body no-padding">

               <ul class="nav nav-pills nav-stacked">





                       <!-- <li><a href="#" class="coldlead_imgs"><span>Employees</span></a></li>-->

                        

                        <?php if(!empty($allEmployeeList))

						  {

				 		 ?>  

                        <?php foreach($allEmployeeList as $all_customerlist)

						{

							

					?>                     

                        <li <?php if($_GET['eid']==$all_customerlist->id || ($emp[0]==$all_customerlist->id && $_GET['eid']=="")) 

                         {?>class="active" <?php } 

						

						 ?>

                        

                        ><a href="<?php print SITEURL?>/PaidBusiness/<?php echo $all_customerlist->id?>"

                        

                        ><?php echo  $all_customerlist->firstname?></a></li>

                       <?php 

					   } 

					   ?>

                        

                       <?php }

					   else 

					   {

						   echo "<li>No Records</li>";

						}

					   ?> 

                      </ul>

                </div><!-- /.box-body -->

              </div>

              </div><!-- /. box -->

              <!-- /.box -->

            </div>

          <!-- /.col -->

            <div class="col-md-9" >

            <div class="box box-primary">

                                  <?php if($_GET['action']=="addPaidRecord")

					  {

						?>

						 <h4 style="padding:10px;">

                              

                                <img src="<?php print SITEURL?>/images/add-paid-business1.png"><b style="color:#3c8dbc;padding:10px;"> ADD PAID BUSINESS RECORD	 </b>

                                

                              </h4>  

                        <div class="fullform">

							                    

                      <form id="paidbusiness" name="paidbusiness" method="post" action="">







   <table class="table_form" style="position:relative;margin-left:45px;color:#5a5f5f; font-family:'Open Sans', sans-serif; font-weight:400; line-height:0; font-size:14px; padding-top:15px;">

   

  <input type="hidden" name="employee_id" value="<?php echo $insertId;?>" />

    <tr>

      <td >Amount  <span style="margin-left:40px;"></span></td>

    <td>  <input type="text" name="amount" id="amount" class="form-control"  style="margin-top:20px;"  /> <br />

    <span>

        <label id="eamount" style="visibility:hidden;color:red;">Please enter Amount</label>

        </span>

        </td>

    </tr>

    <tr>

      <td>Period</td><span></span>

      <td><select id="month" name="month" class="text_short"  style="margin-top:20px;" >

        <option value="">Select Month</option>

        <option value="1">Jan</option>

         <option value="2">Feb</option>

          <option value="3">Mar</option>

           <option value="4">Apr</option>

            <option value="5">May</option>

             <option value="6">Jun</option>

              <option value="7">Jul</option>

               <option value="8">Aug</option>

                <option value="9">Sep</option>

                 <option value="10">Oct</option>

                 <option value="11">Nov</option>

                 <option value="12">Dec</option>

        </select>

         <select id="year" name="year" class="text_short">

        <option value="">Select Year</option>

        <option value="2012">2012</option>

        <option value="2013">2013</option>

        <option value="2014">2014</option>

         <option value="2015">2015</option>

          <option value="2016">2016</option>

           <option value="2017">2017</option>

      

             <option value="2018">2018</option>

              <option value="2019">2019</option>

               <option value="2020">2020</option>
               
               <option value="2021">2021</option>

                <option value="2022">2022</option>

                 <option value="2023">2023</option>

                  <option value="2024">2024</option>

                   <option value="2025">2025</option>

                    <option value="2026">2026</option>

                     <option value="2027">2027</option>

                      <option value="2028">2029</option>

                       <option value="2030">2030</option>

                        <option value="2031">2031</option>

                         <option value="2032">2032</option>

                          <option value="2033">2033</option>

                           <option value="2034">2034</option>

                           <option value="2035">2035</option>

        </select><br />

                <span>

        <label id="emonthyear" style="visibility:hidden;color:red;">Please Select Month & Year</label>

        </span>

        </td>

    </tr>

   

    <tr>

      <td>Written</td><span></span>

      <td>  <input type="text" name="written" class="form-control"   style="margin-top:20px;"  id="written" >

      <br />

          <span>

            <label id="ewritten" style="visibility:hidden;color:red;">Please Fill out this field</label>

            </span></td>

    </tr>

   

      <tr>

            <td>Cleared</td><span></span>

            <td><input type="text" name="cleared" id="cleared" class="form-control"  style="margin-top:20px;"   /><br />

            <span>

             <label id="ecleared" style="visibility:hidden;color:red;">Please Fill out this field</label>

             </span>

             </td>

        </tr>

   

    <!-- </table>

  

 <table style="position:relative;left:200px;" >-->

  <tr><td></td><td>

  <div class="reg_btn" style="float:left;"><input type="submit" id="submit" class="btn btn-primary" value="submit" name="register" style="width:100px;margin-top:20px;"></div>

  

  

 <div class="reg_btn" style="float:left;margin-left:10px;"><input type="reset" class="btn btn-primary" value="clear" style="width:100px;margin-top:20px;"></div></td></tr>

</table>



</form>

</div>

                        <?php

						}

					else if($_GET['action']=='edit')

					{

					$details=$userObj->getEmployeePaidDetails($_GET['empId']);

					//print_r($details);

						hidden_id

						?>

						 <h4 style="padding:10px;">

                               <div  style="float:right;">

                            

                <input type="button" id="submit" value="Back" class="btn btn-primary" style="width:100px;margin-left:0px;" onclick="window.location.href='<?php print SITEURL?>/PaidBusiness/<?php echo $insertId;?>';">

                             

                              </div>

                                <img src="<?php print SITEURL?>/images/add-paid-business2.png"><b style="color:#3c8dbc"> EDIT PAID BUSINESS RECORD	 </b>

                                

                              </h4>  

                        <div class="fullform">

							                    

                      <form id="paidbusiness" name="paidbusiness" method="post" action="">







   <table class="table_form" style="position:relative; margin-left: 53px;color:#5a5f5f; font-family:'Open Sans', sans-serif; font-weight:400; font-size:14px; padding-top:15px; line-height:0;">

   

  <input type="hidden" name="employee_id" value="<?php echo $insertId;?>" />

  <tr>

      <td >Amount  <span style="margin-left:40px;"></span></td>

    <td>  <input type="text" name="amount" id="amount"  class="form-control"   style="margin-top:20px;" value="<?php echo $details->amount?>" /> 

	<input type="hidden" name="hidden_id" id="hidden_id" value="<?php echo $_GET['empId']?>" /> 

	<br />

    <span>

        <label id="eamount" style="visibility:hidden;color:red;">Please enter Amount</label>

        </span>

        </td>

    </tr>

    

    <tr>

      <td>Period</td><span></span>

      <td><select id="month" name="month" class="text_short"  style="margin-top:20px;">

        <option value="">Select Month</option>

        <option value="1" <?php if($details->month=='1'){?> selected<?php }?>>Jan</option>

         <option value="2" <?php if($details->month=='2'){?> selected<?php }?>>Feb</option>

          <option value="3" <?php if($details->month=='3'){?> selected<?php }?>>Mar</option>

           <option value="4" <?php if($details->month=='4'){?> selected<?php }?>>Apr</option>

            <option value="5" <?php if($details->month=='5'){?> selected<?php }?>>May</option>

             <option value="6" <?php if($details->month=='6'){?> selected<?php }?>>Jun</option>

              <option value="7" <?php if($details->month=='7'){?> selected<?php }?>>Jul</option>

               <option value="8" <?php if($details->month=='8'){?> selected<?php }?>>Aug</option>

                <option value="9" <?php if($details->month=='9'){?> selected<?php }?>>Sep</option>

                 <option value="10" <?php if($details->month=='10'){?> selected<?php }?>>Oct</option>

                 <option value="11" <?php if($details->month=='11'){?> selected<?php }?>>Nov</option>

                 <option value="12" <?php if($details->month=='12'){?> selected<?php }?>>Dec</option>

        </select>

         <select id="year" name="year" class="text_short">

        <option value="">Select Year</option>

        <option value="2012" <?php if($details->year=='2012'){?> selected<?php }?> >2012</option>

        <option value="2013" <?php if($details->year=='2013'){?> selected<?php }?>>2013</option>

        <option value="2014" <?php if($details->year=='2014'){?> selected<?php }?>>2014</option>

         <option value="2015" <?php if($details->year=='2015'){?> selected<?php }?>>2015</option>

          <option value="2016" <?php if($details->year=='2016'){?> selected<?php }?>>2016</option>

           <option value="2017" <?php if($details->year=='2017'){?> selected<?php }?>>2017</option>

            <option value="2018" <?php if($details->year=='2018'){?> selected<?php }?>>2018</option>

             <option value="2019" <?php if($details->year=='2019'){?> selected<?php }?>>2019</option>

              <option value="2020" <?php if($details->year=='2020'){?> selected<?php }?>>2020</option>

               <option value="2021" <?php if($details->year=='2021'){?> selected<?php }?>>2021</option>

                <option value="2022" <?php if($details->year=='2022'){?> selected<?php }?>>2022</option>

                 <option value="2023" <?php if($details->year=='2023'){?> selected<?php }?>>2023</option>

                  <option value="2024" <?php if($details->year=='2024'){?> selected<?php }?>>2024</option>

                   <option value="2025" <?php if($details->year=='2025'){?> selected<?php }?>>2025</option>

                    <option value="2026" <?php if($details->year=='2026'){?> selected<?php }?>>2026</option>

                     <option value="2027" <?php if($details->year=='2027'){?> selected<?php }?>>2027</option>

                      <option value="2028" <?php if($details->year=='2028'){?> selected<?php }?>>2028</option>

					 <option value="2029" <?php if($details->year=='2029'){?> selected<?php }?>>2029</option>

         	

					 <option value="2030" <?php if($details->year=='2030'){?> selected<?php }?>>2030</option>

                        <option value="2031" <?php if($details->year=='2031'){?> selected<?php }?>>2031</option>

                         <option value="2032" <?php if($details->year=='2032'){?> selected<?php }?>>2032</option>

                          <option value="2033" <?php if($details->year=='2033'){?> selected<?php }?>>2033</option>

                           <option value="2034" <?php if($details->year=='2034'){?> selected<?php }?>>2034</option>

                           <option value="2035" <?php if($details->year=='2035'){?> selected<?php }?>>2035</option>

        </select><br />

                <span>

        <label id="emonthyear" style="visibility:hidden;color:red;">Please Select Month & Year</label>

        </span>

        </td>

    </tr>

   

    <tr>

      <td>Written</td><span></span>

      <td>  <input type="text" name="written" id="written" class="form-control"   style="margin-top:20px;" value="<?php echo $details->written; ?>" >

      <br />

          <span>

            <label id="ewritten" style="visibility:hidden;color:red;">Please Fill out this field</label>

            </span></td>

    </tr>

   

      <tr>

            <td>Cleared</td><span></span>

            <td><input type="text" name="cleared" id="cleared"  class="form-control"   style="margin-top:20px;" value="<?php echo $details->cleared; ?>"/><br />

            <span>

             <label id="ecleared" style="visibility:hidden;color:red;">Please Fill out this field</label>

             </span>

             </td>

        </tr>

   

    <!-- </table>

  

 <table style="position:relative;left:200px;" >-->

  <tr><td></td><td>

  <div class="reg_btn" style="float:left;"><input type="submit" id="submit" value="submit" class="btn btn-primary" style="width:100px;margin-top:20px;" name="edit"/></div>

  

  

 <div class="reg_btn" style="float:left;margin-left:10px;"><input type="reset" value="clear" class="btn btn-primary" style="width:100px;margin-top:20px;"></div></td></tr>

</table>



</form>

</div>

						<?php

					}

            	

					else {

													if($_GET['eid']!="" )

								{

								//print $_GET['eid'];

								$PaidList=$empObj->getPaidBusinessList($_GET['eid']);

							//print_r($PaidList);

								} 

								else if($_GET['eid']=="")

								{

									 if(!empty($allEmployeeList))

									 {

									$PaidList=$empObj->getPaidBusinessList($emp[0]);

									//print_r($PaidList);



									 }

								}

								?>

								<?php 

								if($_GET['action']=='edit')

								{

								echo "hii";

								}

								?>

								<div>

                                 <?php 

                         if($_GET['err']!="")

                          {

						  	echo '<p class="index1_suc" >'.$_GET['err'].'</p>';

							//unset($_SESSION['err']);

						  

						  }

						  else if($_GET['ferr']!="")

						  {

							echo '<p class="index_err">'.$_GET['ferr'].'</p>';

							//unset($_SESSION['ferr']);

						  }

						  ?>

            	<h4>

                                

                                &nbsp;&nbsp;&nbsp;&nbsp;<img src="<?php print SITEURL?>/images/add-paid-business1.png">&nbsp;&nbsp;&nbsp;&nbsp;<b style="color:#3c8dbc">PAID BUSINESS LIST	 </b>

                                

                              <div  style="float:right;margin-right: 12px;">

                            
  <?php if($_SESSION['role']=="admin") 
			  {
			  ?>             

                <input type="button" id="submit" value="Add" class="btn btn-primary" style="width:100px;margin-left:0px;" onclick="window.location.href='<?php print SITEURL?>/PaidBusiness/<?php echo $insertId;?>?action=addPaidRecord';">

               <?php }?> 
                             

                              </div></h4>

              <div class="box-body">

                  <table id="example1" class="table table-bordered table-striped">

                    <thead>

                      <tr>

                        <th align="center">Amount</th>

                        <th>Written</th>

                        <th>Cleared</th>

                        <th>Month & Year</th>

                        <th>Delete</th>

                        <th>Edit</th>

                      </tr>

                    </thead>

                   <?php

					    $ii=0;

						if(!empty($PaidList))

						{

					    foreach($PaidList as $all_employees) {

                       //$userDetails=$userObj->getUserDetails($all_leads->user_id);

					   if($ii%2==0)

					   {

						   $color="even";

						}

						else

						{

							$color="odd";

						}

					   ?>

                       

                       <tr class=<?php print $color;?>>

                       

                        <td align="center"  ><?php echo "<p style='width:100%;word-wrap:break-word;'>".  $all_employees->amount; "</p>"?></td>

                        <td align="center"  ><?php echo "<p style='width:100%;word-wrap:break-word;'>".  $all_employees->written; "</p>"?></td>

                         <td align="center" ><?php echo "<p style='width:100%;word-wrap:break-word;'>".  $all_employees->cleared; "</p>"?></td>

                        <td align="center"  ><?php echo "<p style='width:100%;word-wrap:break-word;'>".  $all_employees->month ."/".$all_employees->year;"</p>"?></td>

                        <!--<td align="center" width="10%" class="delete" id="<?php echo $all_employees->id; ?>" style="cursor:pointer"><?php print $all_employees->status?></td>

-->                         <td align="center" ><a href="<?php print SITEURL?>/PaidBusiness/<?php print $all_employees->employee_id;?>?empId=<?php print $all_employees->id;?>&action=delete"><img src="<?php echo SITEURL ?>/images/trash-icon_02.png"/></a></td>

							 <td align="center" ><a href="<?php print SITEURL?>/PaidBusiness/<?php print $all_employees->employee_id;?>?empId=<?php print $all_employees->id;?>&action=edit"><img src="<?php echo SITEURL ?>/images/edit_03.png"/></a></td>

                       

					   </tr>

                       <?php

					   $ii++;

					    }

						}

						else

						{

							?>

                            <tr>

                            	<td colspan="6"> No Orders</td>

                            </tr>

                            <?php 

						}

						?>

                       </tbody>

                       

                    </tfoot>

                  </table>

                </div><!-- /. box -->

            </div><!-- /.col -->

                 <?php 

						}

						?>

                        

                        

            </div>

         

          </div><!-- /.row -->

         <?php include("includes/rightnav.php"); ?>    

        </section><!-- /.content -->

         

<link href="<?php print SITEURL?>/libs/prettify/prettify.css" type="text/css" rel="stylesheet"/>

<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>

<script type="text/javascript">var $j = jQuery.noConflict();</script>

<script type="text/javascript" src="<?php print SITEURL?>/libs/prettify/prettify.js"></script>

<script type="text/javascript" src="<?php print SITEURL?>/js/jquery.slimscroll.js"></script>



<script type="text/javascript">

$j(function ($) {

 

	    $j('#textbox').slimScroll({

          color: '#3c8dbc',

		  wheelStep : 1,

		  height:720

      });

	  

	



    });

	

</script>

         

      </div><!-- /.content-wrapper -->

    <?php echo include("includes/footer.php");?>



