<?php 
include("includes/header.php");

include("includes/leftnav.php"); 

$userObj->checkloggedin();
if($_POST['leadsid']!="")
{
	$userObj->deleteleadspermenant($_POST);	
}
if($_GET['page']!=""){
	$page=$_GET['page'] ;
}else{
	$page=1;
}
$rec_count=$userObj->getAllDeleteEmployeeLeadsCount();
$limit = 50;
if($_GET['fld']!="")
{
$fld=$_GET['fld'];
}
else
{
$fld="id";
}
if($_GET['ord']!="")
{
$order=$_GET['ord'];
}
else
{
$order="DESC";
}

isset($_GET['page'])?$page=$_GET['page']:$page=1;
$start = (($page-1)*$limit);	
$pagecount = ceil($rec_count/$limit);


$allleads=$userObj->getAllDeleteEmployeeLeads($start,$limit,$fld,$order);
?>
<script>
	function gotoRequiredPage(pageId){
		window.location.replace("<?php print SITEURL ?>/DeleteLeads/"+pageId);
	}
</script>
<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>
<script>
	var popup=jQuery.noConflict();
</script>
<script type="text/javascript" src="<?php print SITEURL?>/js/checkuncheckall.js"></script>

<script>
function checkEmp()
{
	if(document.getElementById("employeename").value=='')
	{
		alert("Please Select Employee");
		document.leedlist.employeename.focus;
		return false;
	}
	
	if( popup('input[name="leadsid[]"]:checked').length == 0 )
	{
		alert("You must check atleast one Leed to assign");
		return false;
	}
}

function deleteformsubmit()
{
	document.deleteleadsform.submit();
}
function deleteadminleadid(id){
	//alert(id);
	var q=confirm("Are you sure want to delete");
	if(q){
			if (window.XMLHttpRequest)
		{
			if (window.XMLHttpRequest) {
			// code for IE7+, Firefox, Chrome, Opera, Safari
			xmlhttp=new XMLHttpRequest();
			} else { // code for IE6, IE5
			xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
			}
			xmlhttp.onreadystatechange=function() {
			
			if (xmlhttp.readyState==4 && xmlhttp.status==200) {
				var text=xmlhttp.responseText;
			
			if(text==1)
			{
		
				document.getElementById("admindel"+id).remove();
				alert("Successfully deleted");
			}			
			else
			{
				
				alert("Failed to delete");
				
			}
			
			}
			}
			xmlhttp.open("GET","<?php print SITEURL?>/admindeletelead.php?id="+id,true);
			xmlhttp.send();
		
	}
	}
}
</script>
<div class="wrapper">
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
	<!-- Content Header (Page header) -->
        <!-- Main content -->
        <section class="content">
        	<div class="row">
        		<div class="col-xs-12">
        		<!-- /.box -->
        			<div class="box">
        				<h4><span style="margin-left: 10px;"><img src="<?php print SITEURL?>/images/leeds_list _new.png"><b style="margin-left:10px;">LEADS LIST</b></span>
                            <?php 
                            if($_SESSION['ferr']!="")
                            {
                            	echo '<p class="index_suc">'.$_SESSION['ferr'].'</p>';
                            	unset($_SESSION['ferr']);
                            }
                            else if($_SESSION['err']!="")
                            {
                            	echo '<p class="index_err">'.$_SESSION['err'].'</p>';
                            	unset($_SESSION['err']);
                            }
                            ?>
						</h4>
                        <div class="box-body">
							<div class="innerdivtable">
                            <div style="clear:both;">
                                <div style="float:unset;">
                                	<div style="width:100%;">
                           				<div style="width:50%;float:left;">
                                        	<input type="button" value="Delete" class="btn btn-primary" onclick="deleteformsubmit()">
                                        </div>
                           			</div>
                                	<form action="" name="deleteleadsform" method="post">
                  					<table id="example111" class="table table-bordered table-striped">
                    					<thead>
                                            <tr>
                                                 <th><input type="checkbox" name="check" id="check" value="" onclick="checkAlluncheckAll('deleteleadsform', 'leadsid')"/><label for="check" onclick="test();">&nbsp;</label></th>
                                                <th>Lead Name
                                                    <div class="sort" style="float:right;" >
                                                    	<a href="<?php echo SITEURL ?>/deletedleadlist.php?ord=ASC&fld=firstname&page=<?php echo $_GET['page']?>" class="up" title="up"></a>
                                                    	<a href="<?php echo SITEURL ?>/deletedleadlist.php?ord=DESC&fld=firstname&page=<?php echo $_GET['page']?>" class="down" title="down"></a>
                                                    </div>
                                                </th>
                                                <th>Email
                                                    <div class="sort" style="float:right;" >
                                                        <a href="<?php echo SITEURL ?>/deletedleadlist.php?ord=ASC&fld=firstname&page=<?php echo $_GET['page']?>" class="up" title="up"></a>
                                                        <a href="<?php echo SITEURL ?>/deletedleadlist.php?ord=DESC&fld=firstname&page=<?php echo $_GET['page']?>" class="down" title="down"></a>
                                                    </div>
                                                </th>
                                                <th>Phone Number
                                                    <div class="sort" style="float:right;" >
                                                        <a href="<?php echo SITEURL ?>/deletedleadlist.php?ord=ASC&fld=firstname&page=<?php echo $_GET['page']?>" class="up" title="up"></a>
                                                        <a href="<?php echo SITEURL ?>/deletedleadlist.php?ord=DESC&fld=firstname&page=<?php echo $_GET['page']?>" class="down" title="down"></a>
                                                    </div>
                                                </th>
                                                <th>Company
                                                    <div class="sort" style="float:right;" >
                                                        <a href="<?php echo SITEURL ?>/deletedleadlist.php?ord=ASC&fld=firstname&page=<?php echo $_GET['page']?>" class="up" title="up"></a>
                                                        <a href="<?php echo SITEURL ?>/deletedleadlist.php?ord=DESC&fld=firstname&page=<?php echo $_GET['page']?>" class="down" title="down"></a>
                                                    </div>
                                                </th>
                                                <th>Sheet Name
                                                    <div class="sort" style="float:right;" >
                                                        <a href="<?php echo SITEURL ?>/deletedleadlist.php?ord=ASC&fld=firstname&page=<?php echo $_GET['page']?>" class="up" title="up"></a>
                                                        <a href="<?php echo SITEURL ?>/deletedleadlist.php?ord=DESC&fld=firstname&page=<?php echo $_GET['page']?>" class="down" title="down"></a>
                                                    </div>
                                                </th>
                                                <th>Delete</th>
											</tr>
                                        </thead>
										<tbody>
											<?php $ii=0;
                                            if(!empty($allleads)){
                                            	foreach($allleads as $all_leads){
                                            		$userDetails=$userObj->getUserDetails($all_leads->user_id);
                                            		if($ii%2==0)
                                            		{
														$color="even";
													}
													else
													{
														$color="odd";
													}?>
                                                    <tr id="admindel<?php print $all_leads->id?>">
                                                        <td align='left' width="5%">
                                                        	<input type="checkbox" name="leadsid[]" value="<?php print $all_leads->id?>" id="leadsid" />
                                                      	</td>
                                                        <td style="width:20%;" onclick="window.location.href='<?php print SITEURL?>/leedslistview.php?id=<?php echo $all_leads->id; ?>&page=<?php echo $_GET['page'] ?>'"><?php echo "<p style='width:100%;word-wrap:break-word;'>". $all_leads->title." ".$all_leads->firstname." ".$all_leads->lastname; "</p>"?></td>
                                                        <td style="width:20%;" onclick="window.location.href='<?php print SITEURL?>/leedslistview.php?id=<?php echo $all_leads->id; ?>&page=<?php echo $_GET['page'] ?>'"><?php echo "<p style='width:100%;word-wrap:break-word;'>". $all_leads->email;"</p>"?></td>
                                                        <td style="width:15%;" onclick="window.location.href='<?php print SITEURL?>/leedslistview.php?id=<?php echo $all_leads->id; ?>&page=<?php echo $_GET['page'] ?>'"><?php echo "<p style='width:100%;word-wrap:break-word;'>+44". substr($all_leads->phone_number,1);"</p>" ?></td>
                                                        <td style="width:20%;" onclick="window.location.href='<?php print SITEURL?>/leedslistview.php?id=<?php echo $all_leads->id; ?>&page=<?php echo $_GET['page'] ?>'"><?php echo "<p style='width:100%;word-wrap:break-word;'>". $all_leads->company;"</p>"?></td>
                                                        <td style="width:15%;" onclick="window.location.href='<?php print SITEURL?>/leedslistview.php?id=<?php echo $all_leads->id; ?>&page=<?php echo $_GET['page'] ?>'"><?php echo "<p style='width:100%;word-wrap:break-word;'>". $all_leads->status;"</p>"?></td>
                                                        
                                                        <td align="center" ><a href="#" onclick="deleteadminleadid(<?php print $all_leads->id?>)"><img src="<?php print SITEURL?>/images/delete1.png"/> </a> </td>
                                                        
                                                    </tr>
                           							<?php $ii++;
					    						}
											}
											else
											{ ?>
												<tr>
													<td colspan="5"> No Leads</td>
												</tr>
									  <?php }?>
                                     	</tbody>
									</table>
                                    </form>
								  <?php
                                    echo '<div class="pagclass">';
                                    echo pagination($rec_count,$limit,$pagecount,$page,$start);
                                    echo '</div>'; 
                                    ?>
                                </div><!-- /.box-body -->
                            </div><!-- /.box -->
                        </div><!-- /.col -->
                    </div><!-- /.row -->
                </div>
            </div>
        </section><!-- /.content -->
    </div><!-- /.content-wrapper -->
</div><!-- ./wrapper -->
<!-- jQuery 2.1.3 -->
<!-- page script -->
<script type="text/javascript">
	$(function () {
		$("#example1").dataTable();
	});
</script>
<?php 
function pagination($no_of_rows,$limit,$pagecount,$page,$start)
{
	if($pagecount>1)
	{
		if($page!=1){
			$pre=$_GET['page']-1;?>
        	<a class="pagf" href="<?php print SITEURL ?>/DeleteLeads/<?php echo $pre ?>">Previous</a>        
       <?php }?>
    	<select onchange="gotoRequiredPage(this.value)">
    		<option value="">Select</option>
			<?php
                for($i=1;$i<=$pagecount;$i++)
                {
                    $cls = $page==$i?'class = "activepage"':'class = "pagn"';?>
                    <option value="<?php echo $i;?>" <?php if($_GET['page']==$i || ($_GET['page']=="" && $i==1)){ ?>  selected="selected" <?php }?>><?php echo $i;?></option>
          <?php }?>
        </select>
        <?php
		if($page<$i-1){
			$next=$_GET['page']!=""?$_GET['page']+1:2;?>
             <a class="pagf" href="<?php print SITEURL ?>/DeleteLeads/<?php echo $next ?>">Next</a>
		<?php }
	}
}

?>