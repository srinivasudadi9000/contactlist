<?php 
include("includes/header.php");

include("includes/leftnav.php"); 
$getAllDDRRequests = $userObj->getAllDDRRequests($_SESSION['id']);
if($_GET['action']=="delete")
{
	//print_r($_POST);	
	$userObj->deleteDDR_list($_GET['id']);
}
//var_dump($getAllDDRRequests);
?>
<script type="text/javascript" >
var click_count = 0;
function fn(ddr_id) {
	//alert(ddr_id)
	click_count = click_count+1;
	//alert(click_count)
	//$("#status"+ddr_id).remove();
    window.location = '<?php print SITEURL; ?>/ADD_DDR?data_drive_request_id='+ddr_id;
}
</script>
<div class="wrapper">
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
	<!-- Content Header (Page header) -->
        <!-- Main content -->
        <section class="content">
        	<div class="row">
        		<div class="col-xs-12">
        		<!-- /.box -->
        			
        <div class="drivelist_right">
        	<h1 style="float:left">Data Drive List</h1>
            <p class="flags_style">
                <a href="#" title="Red" class="anchor_style"><img src="<?php print SITEURL; ?>/images/red_03.png" alt=""></a>
                <a href="#" title="Yellow" class="anchor_style"><img src="<?php print SITEURL; ?>/images/yellow_08.png" alt=""></a>
                <a href="#" title="Green" class="anchor_style"><img src="<?php print SITEURL; ?>/images/green_06.png" alt=""></a>
                
            </p>
            <div class="clear_fix"></div>
            <div class="drivelisttable">
            	<table class="listtaable" id="table" cellpadding="0" cellspacing="0">
                	<tr>
                    	<th width="12%">Request Sent From</th>
                        <th width="12%">Company Name</th>
                        <th width="12%">Dealers Name</th>
                        <th width="10%">Client Name</th>
                        <th width="10%">Phone</th>
                        <th width="20%">Date and Time of Last Modified</th>
                        <th width="6%">Status</th>
                        <th width="6%">Log</th>
                        <th width="6%">Reminder</th>
                        <th width="6%">Delete</th>
                    </tr>
                    
                    <?php foreach($getAllDDRRequests as $get_allDDRDetails) { ?>
                    <?php $adduserid=$userObj->getUser_id($get_allDDRDetails->added_user_id)?>
	                    <tr style="cursor:pointer;">
	                    	<td width="12%" onclick="fn(<?php echo $get_allDDRDetails->data_drive_request_id;?>)"><span class="req_name"><?php echo $adduserid->firstname;?></span>
                            <div id="status<?php echo $get_allDDRDetails->data_drive_request_id ?>">
						<?php if($userObj->getclickedstatus($get_allDDRDetails->data_drive_request_id)=='0') {?><img src='<?php echo SITEURL ?>/images/dot.png' width="10px" height="10px" class="clicked_img"/><?php }	?></div></td></a>
	                        <td width="12%" onclick="fn(<?php echo $get_allDDRDetails->data_drive_request_id;?>)"><?php echo $get_allDDRDetails->company_name;?></td>
	                        <td width="12%" onclick="fn(<?php echo $get_allDDRDetails->data_drive_request_id;?>)"><?php echo $get_allDDRDetails->dealer_name;?></td>
	                        <td width="10%" onclick="fn(<?php echo $get_allDDRDetails->data_drive_request_id;?>)"><?php echo $get_allDDRDetails->client_name;?></td>
	                        <td width="10%" onclick="fn(<?php echo $get_allDDRDetails->data_drive_request_id;?>)"><?php echo $get_allDDRDetails->phone_number;?></td>
	                        <td width="20%" onclick="fn(<?php echo $get_allDDRDetails->data_drive_request_id;?>)"><?php echo $get_allDDRDetails->date_added;?></td>
	                        <td width="6%" onclick="fn(<?php echo $get_allDDRDetails->data_drive_request_id;?>)">
	                        <!-- <a href="#"> -->
	                        <?php if($get_allDDRDetails->status == 'Green') {?>
	                        <img src="images/green_06.png" alt="">
	                        <?php } else if ($get_allDDRDetails->status == 'Yellow') { ?>
	                        <img src="images/yellow_08.png" alt="">
	                        <?php } else if ($get_allDDRDetails->status == 'Red') { ?>
	                        <img src="images/red_03.png" alt="">
	                        <?php }?>
	                        
	                        <!-- </a> -->
	                        </td>
	                        <td width="6%">
	                        	<a href="#" onClick="window.location.href = 'ddr_history.php?ddr_id=<?php print $get_allDDRDetails->data_drive_request_id;?>';">
	                        		<img src="images/varietysymbol_10.png" alt="" >
	                        	</a>
	                        </td>
	                        <td width="6%" onclick="fn(<?php echo $get_allDDRDetails->data_drive_request_id;?>)"><a href="#"><img src="images/remind_03.png" alt=""></a></td>
	                        <td width="6%"><a href="#" onClick="var q = confirm('Are you sure you want to delete selected record?'); if (q) { window.location.href ='ddr_list.php?action=delete&id=<?php print $get_allDDRDetails->data_drive_request_id;?>'; return false;}"><img src="images/delete_09.png" alt=""></a></td>
	                    </tr>
                    <?php } ?>
                </table>
            </div><!--drivelisttable-->
        </div><!--drivelist_right-->
        <div class="clear_fix"></div>
        
               
            </div>
           </div>
        </section><!-- /.content -->
    </div><!-- /.content-wrapper -->
</div>