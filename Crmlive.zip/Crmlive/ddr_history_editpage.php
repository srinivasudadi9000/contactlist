<?php 
include("includes/header.php");

include("includes/leftnav.php"); 

$userObj->checkloggedin();

if($_GET['page']!=""){
	$page=$_GET['page'] ;
}else{
	$page=1;
}
$rec_count=$userObj->getAllemployeeleadscount($_SESSION['id']);
$limit = 200;
if($_GET['fld']!="")
{
$fld=$_GET['fld'];
}
else
{
$fld="id";
}
if($_GET['ord']!="")
{
$order=$_GET['ord'];
}
else
{
$order="DESC";
}
isset($_GET['page'])?$page=$_GET['page']:$page=1;
$start = (($page-1)*$limit);	
$pagecount = ceil($rec_count/$limit);

$getAllUsers = $userObj->getAllUsers();
 
$clicked_count = 0;
$data_drive_request_id = $_GET['data_drive_request_id'];
if($data_drive_request_id) {
	//echo 'if case';
	$clicked_count = 1;
	$updateResult = $userObj->updateClickedCount($clicked_count, $data_drive_request_id);
	//echo 'updateResult : '.$updateResult;
}
//echo 'data_drive_request_id : '.$data_drive_request_id;
$DDRDetails = $userObj->getdDDRDetails($data_drive_request_id);
//var_dump($DDRDetails);


 $DDRDetails = $userObj->getdDDRDetails($data_drive_request_id);
 
//$allleads=$userObj->getAllemployeeleads($_SESSION['id'],$start,$limit,$fld,$order);

//var_dump($DDRDetails);
?>
<link rel="stylesheet" type="text/css" media="all" href="<?php print SITEURL;?>/jsDatePick_ltr.min.css" />
<script type="text/javascript" src="<?php echo SITEURL;?>/js/jquery.1.4.2.js"></script>
<script type="text/javascript" src="<?php echo SITEURL;?>/js/jsDatePick.jquery.min.1.3.js"></script>
<script type="text/javascript">
	window.onload = function(){
		new JsDatePick({
			useMode:2,
			target:"date_dealts",
			dateFormat:"%Y-%m-%d"
		});
	};
</script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css" />
<link rel="stylesheet" href="https://rawgit.com/FezVrasta/bootstrap-material-design/master/dist/css/material.min.css" />
<link rel="stylesheet" href="<?php print SITEURL;?>/css/bootstrap-material-datetimepicker.css" />
<link href='http://fonts.googleapis.com/css?family=Roboto:400,500' rel='stylesheet' type='text/css'>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<script src="https://code.jquery.com/jquery-1.12.3.min.js" integrity="sha256-aaODHAgvwQW1bFOGXMeX+pC4PZIPsvn2h1sArYOhgXQ=" crossorigin="anonymous"></script>
<script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://rawgit.com/FezVrasta/bootstrap-material-design/master/dist/js/material.min.js"></script>
<script type="text/javascript" src="http://momentjs.com/downloads/moment-with-locales.min.js"></script>
<script type="text/javascript" src="<?php echo SITEURL;?>/js/bootstrap-material-datetimepicker.js"></script>
<script>
			(function(i, s, o, g, r, a, m) {
				i['GoogleAnalyticsObject'] = r;
				i[r] = i[r] || function() {
					(i[r].q = i[r].q || []).push(arguments)
				}, i[r].l = 1 * new Date();
				a = s.createElement(o),
					m = s.getElementsByTagName(o)[0];
				a.async = 1;
				a.src = g;
				m.parentNode.insertBefore(a, m)
			})(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');

			ga('create', 'UA-60343429-1', 'auto');
			ga('send', 'pageview');
		</script>

<script type="text/javascript">
	popup(function() {
		setTimeout(function() { $(".index_suc").fadeOut(1500); }, 5000)
		setTimeout(function() { $(".index_err").fadeOut(1500); }, 5000)
	});

	function status_verify(status_color)
	{
		if(status_color == 'Green') {
		   
		 var y = document.getElementById("return_to_sender");
		 y.type= "submit";

		 document.getElementById("return_back_sender").value='1';

		} else {
			var y = document.getElementById("return_to_sender");
		    y.type= "hidden";
		}
	}
</script>

<form method="post">
<div class="wrapper">
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
	<!-- Content Header (Page header) -->
        <!-- Main content -->
        <section class="content">
        	<div class="row">
        		<div class="col-xs-12">
        		<!-- /.box -->
        			
        <div class="drivelist_right">
        	<h1>Data Drive Request</h1>
            <div class="form_blg1">
            
            <?php if ($_GET['data_drive_request_id']) { 
            	 foreach($DDRDetails as $get_DDRDetails) {
            	 	 ?>
            	<div class="form_blg">
            	<ul>
            	
                	<li>
                    	<div class="frmlist_blg">
                        	<div class="frmlist_left">
                            	<p>Company Name: </p>
                            </div><!--frmlist_left-->
                            <div class="frmlist_right">
                            	<input type="text" placeholder="" name="company_name" value="<?php echo $get_DDRDetails->company_name; ?>" disabled="disabled">
                            	
                            	<input type="hidden" name="added_user_id" value="<?php echo $_SESSION['id'];?>">
                            </div><!--frmlist_right-->
                            <div class="clear_fix"></div>
                        </div><!--frmlist_blg-->
                    </li>
                    
                    <li>
                    	<div class="frmlist_blg">
                        	<div class="frmlist_left">
                            	<p>Dealer Name:  </p>
                            </div><!--frmlist_left-->
                            <div class="frmlist_right">
                            	<input type="text" placeholder="" name="dealer_name" value="<?php echo $get_DDRDetails->dealer_name; ?>" disabled="disabled">
                            </div><!--frmlist_right-->
                            <div class="clear_fix"></div>
                        </div><!--frmlist_blg-->
                    </li>
                    <li>
                    	<div class="frmlist_blg">
                        	<div class="frmlist_left">
                            	<p>Date Dealt:  </p>
                            </div><!--frmlist_left-->
                            <div class="frmlist_right">
                            	<input type="text"  placeholder="" name="date_dealt" id="date_dealt" class="alert_blg" 
                            	value="<?php echo $get_DDRDetails->date_dealt; ?>" disabled="disabled">
                            </div><!--frmlist_right-->
                            <div class="clear_fix"></div>
                        </div><!--frmlist_blg-->
                    </li>
                    <li>
                    	<div class="frmlist_blg">
                        	<div class="frmlist_left">
                            	<p>Client Name: </p>
                            </div><!--frmlist_left-->
                            <div class="frmlist_right">
                            	<input type="text" placeholder="" name="client_name" value="<?php echo $get_DDRDetails->client_name; ?>" disabled="disabled">
                            </div><!--frmlist_right-->
                            <div class="clear_fix"></div>
                        </div><!--frmlist_blg-->
                    </li>
                    
                    <li>
                    	<div class="frmlist_blg">
                        	<div class="frmlist_left">
                            	<p>Address Line1:  </p>
                            </div><!--frmlist_left-->
                            <div class="frmlist_right">
                            	<input type="text" placeholder="" name="address_line1" value="<?php echo $get_DDRDetails->address_line1; ?>" disabled="disabled">

                            </div><!--frmlist_right-->
                            <div class="clear_fix"></div>
                        </div><!--frmlist_blg-->
                    </li>
                    <li>
                    	<div class="frmlist_blg">
                        	<div class="frmlist_left">
                            	<p>Address Line2:  </p>
                            </div><!--frmlist_left-->
                            <div class="frmlist_right">
                            	<input type="text" placeholder="" name="address_line2" value="<?php echo $get_DDRDetails->address_line2; ?>" disabled="disabled">
                            </div><!--frmlist_right-->
                            <div class="clear_fix"></div>
                        </div><!--frmlist_blg-->
                    </li>
                    <li>
                    	<div class="frmlist_blg">
                        	<div class="frmlist_left">
                            	<p>Post Code:  </p>
                            </div><!--frmlist_left-->
                            <div class="frmlist_right">
                            	<input type="text" placeholder="" name="post_code" value="<?php echo $get_DDRDetails->post_code; ?>" disabled="disabled">
                            </div><!--frmlist_right-->
                            <div class="clear_fix"></div>
                        </div><!--frmlist_blg-->
                    </li>
                    <li>
                    	<div class="frmlist_blg">
                        	<div class="frmlist_left">
                            	<p>Phone Number:  </p>
                            </div><!--frmlist_left-->
                            <div class="frmlist_right">
                            	<input type="text" placeholder="" name="phone_number" value="<?php echo $get_DDRDetails->phone_number; ?>" disabled="disabled">
                            </div><!--frmlist_right-->
                            <div class="clear_fix"></div>
                        </div><!--frmlist_blg-->
                    </li>
                    <li>
                    	<div class="frmlist_blg">
                        	<div class="frmlist_left">
                            	<p>ID Number:  </p>
                            </div><!--frmlist_left-->
                            <div class="frmlist_right">
                            	<input type="text" placeholder="" name="id_number" value="<?php echo $get_DDRDetails->id_number; ?>" disabled="disabled">
                            </div><!--frmlist_right-->
                            <div class="clear_fix"></div>
                        </div><!--frmlist_blg-->
                    </li>
                    <li>
                    	<div class="frmlist_blg">
                        	<div class="frmlist_left">
                            	<p>Product:  </p>
                            </div><!--frmlist_left-->
                            <div class="frmlist_right">
                            	<input type="text" placeholder="" name="product" value="<?php echo $get_DDRDetails->product; ?>" disabled="disabled">
                            </div><!--frmlist_right-->
                            <div class="clear_fix"></div>
                        </div><!--frmlist_blg-->
                    </li>
                    
                    <li>
                    	<div class="frmlist_blg">
                        	<div class="frmlist_left">
                            	<p>Total Trade Value:  </p>
                            </div><!--frmlist_left-->
                            <div class="frmlist_right">
                            	<input type="text" placeholder="" name="total_trade_value" value="<?php echo $get_DDRDetails->total_trade_value; ?>" disabled="disabled">
                            </div><!--frmlist_right-->
                            <div class="clear_fix"></div>
                        </div><!--frmlist_blg-->
                    </li>
                    
                    <li>
                    	<div class="frmlist_blg">
                        	<div class="frmlist_left">
                            	<p>Alert me:  </p>
                                <span>(next – 1 hour or Time & date)</span>
                            </div><!--frmlist_left-->
                            <div class="frmlist_right">
                       <input type="text" placeholder="" class="alert_blg" name="alert_time" id="alert_time" value="<?php echo $get_DDRDetails->alert_time; ?>" disabled="disabled">
                            </div><!--frmlist_right-->
                            <div class="clear_fix"></div>
                        </div><!--frmlist_blg-->
                    </li>
                    
                    <li>
                    	<div class="frmlist_blg">
                        	<div class="frmlist_left">
                            	<p>Status:  </p>
                            </div><!--frmlist_left-->
                            <div class="frmlist_right">
                            	<img src="images/green_06.png" alt="">
                                <span><input type="radio" onclick="status_verify('Green')" name="status" value="Green"  <?php if($get_DDRDetails->status == 'Green') {?> checked="checked"  <?php } ?> disabled="disabled"></span>
                                <img src="images/yellow_08.png" alt="">
                                <span><input type="radio" onclick="status_verify('Yellow')" name="status" value="Yellow" <?php if($get_DDRDetails->status == 'Yellow') { ?> checked="checked"  <?php } ?> disabled="disabled"></span>
                                <img src="images/red_03.png" alt="">
                                <span><input type="radio" onclick="status_verify('Red')" name="status" value="Red" <?php if($get_DDRDetails->status == 'Red' ) { ?> checked="checked" <?php } ?> disabled="disabled"></span>
                                
                                 <input type="hidden" name="return_back_sender" id="return_back_sender" value="" >
                                <?php if($get_DDRDetails->status == 'Green') {?>
                                	<input type="submit" value="Return to sender" id="return_to_sender">
                                <?php } else { ?>
                                	<input type="hidden" value="Return to sender" id="return_to_sender" >
                                <?php }?>
                            </div><!--frmlist_right-->
                            <div class="clear_fix"></div>
                        </div><!--frmlist_blg-->
                    </li>
                    
                     <li>
                    	<div class="frmlist_blg">
                        	<div class="frmlist_left">
                            	<p>Client Situation: :  </p>
                               
                            </div><!--frmlist_left-->
                            <div class="frmlist_right">
                            	<textarea name="client_situation" disabled="disabled"><?php echo $get_DDRDetails->client_situation; ?></textarea>
                                
                            </div><!--frmlist_right-->
                            <div class="clear_fix"></div>
                        </div><!--frmlist_blg-->
                    </li>
                    
                    
                     <li>
                    	<div class="frmlist_blg">
                        	<div class="frmlist_left">
                            	<p>Users :  </p>
                            </div><!--frmlist_left-->
                            
                            <div class="frmlist_right">
                            <select name="receive_user_id" disabled="disabled">
                            	
							<?php
							    foreach($getAllUsers as $row) {
							    	$val = $row->id;
							    	echo '<option value="'.$row->id.'">'.$row->firstname.' '.$row->lastname.'</option>';
							    }
							?>
							</select>
							  <div class="clear_fix"></div><br/>
                                <?php /*?><input type="submit" value="Save" class="edit_btn">
                                <input type="hidden" name="submit" value="1">
                                <input type="submit" value="Send To User" class="edit_btn"><?php */?>
                            </div><!--frmlist_right-->
                            <div class="clear_fix"></div>
                        </div><!--frmlist_blg-->
                    </li>
                    
                </ul>
            </div><!--form_blg-->
            
            <?php } } ?>
            <!--form_blg-->
           
            </div><!--form_blg1-->
        </div><!--drivelist_right-->
        <div class="clear_fix"></div>
               
            </div>
           </div>
        </section><!-- /.content -->
    </div><!-- /.content-wrapper -->
</div><!-- ./wrapper -->
</form>
<!-- jQuery 2.1.3 -->
<!-- page script -->
<script type="text/javascript">
		$(document).ready(function()
		{
			$('#date_dealt').bootstrapMaterialDatePicker
			({
				time: false,
				clearButton: true
			});
			$('#alert_time').bootstrapMaterialDatePicker
			({
				format: 'YYYY-MM-DD HH:MM:SS'
				//format: 'YYYY-MM-DD HH:MM'
			});
			
			$.material.init()
		});	
</script>
