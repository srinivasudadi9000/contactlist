<?php 
include("includes/header.php");

include "includes/leftnav.php";
$userObj->checkloggedin();

$page = explode("/",$_GET['page']);
$_GET['page'] = $page[0];
$limit = 200;
if($_GET['status']=="" || $_GET['status']=="All")
{
$rec_count=$userObj->getSearchdataCount($_GET['result'],'');
}
else{
$rec_count=$userObj->getSearchdataCount($_GET['result'],$_GET['status']);	
}
isset($_GET['page'])?$page=$_GET['page']:$page=1;
$start = (($page-1)*$limit);
$pagecount = ceil($rec_count/$limit);	
if($_GET['fld']!="")
{
$fld=$_GET['fld'];
}
else
{
$fld="id";
}
if($_GET['ord']!="")
{
$order=$_GET['ord'];
}
else
{
$order="DESC";
}

if($_GET['status']=="All" || $_GET['status']=="" )
{
$getsearchdata=$userObj->getSearchdata($_GET['result'],$start,$limit,$fld,$order,'');
}
else
{
$getsearchdata=$userObj->getSearchdata($_GET['result'],$start,$limit,$fld,$order,$_GET['status']);	
}

?>
 <script>
function gotoRequiredPage(pageId){
	
		window.location.replace("<?php print SITEURL ?>/SearchResult/"+pageId+"/<?php echo $_GET['result'] ?>");
	
	}
	function getStatus(status)
{
	window.location.replace("<?php print SITEURL ?>/SearchResult/<?php echo $_GET['page']?>/<?php echo $_GET['result']?>&status="+status);
}
</script>
<div class="wrapper">
	<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Search Result
            </h1>
        </section>
         
                <table width='100%' style='border:1px solid #ccc;'>
                    <tr style='border-bottom:1px solid #ccc;height:50px; background-color:#ccc;'>
                     	<th align='center' style='padding-left:50px;color:#000;font-size:14px; width:20%; text-align:left;'>
                            Sno
                        </th>
                        <th align='left' style='color:#000;font-size:14px; width:50%; text-align:left;'>
                            Names
                        </th>
                        <th align='center' style='color:#000;font-size:14px; width:30%; text-align:left;'>
                            View Lead
						</br>
                      Filter By       <select name="status" onchange="getStatus(this.value)">
                      <option value="">Select</option>
                      <option value="All" <?php if($_GET['status']=="Cold_Lead") { ?>selected="selected"<?php } ?>>ALL</option>
                      <option value="Cold_Lead" <?php if($_GET['status']=="Cold_Lead") { ?>selected="selected"<?php } ?>>Cold Lead</option>
                       <option value="Open" <?php if($_GET['status']=="Open") { ?>selected="selected"<?php } ?>>Open</option>
                   
                    <option value="Dud" <?php if($_GET['status']=="Dud") { ?>selected="selected"<?php } ?>>Dud</option>
                     <option value="Teed" <?php if($_GET['status']=="Teed") { ?>selected="selected"<?php } ?>>Teed</option>
                    <option value="Dead" <?php if($_GET['status']=="Dead") { ?>selected="selected"<?php } ?>>Dead</option>
                    <option value="Closed" <?php if($_GET['status']=="Closed") { ?>selected="selected"<?php } ?>>Closed</option>
                    <option value="Drive" <?php if($_GET['status']=="Drive") { ?>selected="selected"<?php } ?>>Drive</option>
                    <option value="Evening_Call" <?php if($_GET['status']=="Evening_Call") { ?>selected="selected"<?php } ?>>Evening Call</option>
                     <option value="Client" <?php if($_GET['status']=="Client") { ?>selected="selected"<?php } ?>>Client</option>
                       <option value="Pulled_Client" <?php if($_GET['status']=="Pulled_Client") { ?>selected="selected"<?php } ?>>Pulled_Client</option></select>
						  </tr>
						 <?php 
		
		  if(count($getsearchdata)>0){?>
                    
                    <?php $i=1;foreach($getsearchdata as $get_searchdata){?>
                        <tr style='border-bottom:1px solid #ccc; height:40px;'>
                        	<td  align='center' style='width:20%;padding-left:50px;text-align:left;'>
                            	<p><?php echo $i+$start ;?></p>
                            </td>
                            <td align='left' style='width:50%;'>
                            	<p style='width:350px;;word-wrap:break-word;'><?php echo $get_searchdata->title." ".$get_searchdata->firstname.' '.$get_searchdata->lastname;?></p>
                            </td>
							<?php if($get_searchdata->status!="")
							{
							?>
                            <td  align='center' style='width:30%;text-align:left;'>
                            	<a href="<?php echo SITEURL?>/CustomerList/<?php echo $get_searchdata->status;?>?nextid=<?php echo $get_searchdata->id;?>"><?php echo $get_searchdata->status;?><img src="<?php echo SITEURL;?>/images/edit_03.png"/></a>
                            </td>
							<?php }
							else{
								?>
								   <td  align='center' style='width:30%;text-align:left;'>
                            	Not Assigned to anyone
                            </td>
						<?php 
						}
							?>
                        </tr>
                     <?php $i++;}?>
                </table>
                <?php }else{
					echo  "<table width='100%' style='border:1px solid #ccc;'>";
					echo "<h4 align='center'>No Result Found</h4>";
					echo "</table>";
				}?>
				 <?php
					echo '<div class="pagclass">';
					echo pagination($rec_count,$limit,$pagecount,$page,$start);
					echo '</div>'; 
					?>
	</div>
</div>
<?php 
function pagination($no_of_rows,$limit,$pagecount,$page,$start)
{
	if($pagecount>1)
	{
		if($page!=1){
			$pre=$_GET['page']-1;
	?>
        <a class="pagf" href="<?php print SITEURL ?>/SearchResult/<?php echo $pre ?>/<?php echo $_GET['result'] ?>">Previous</a>        
       <?php
		
		}
		?>
        <select onchange="gotoRequiredPage(this.value)">
        <option value="">Select</option>
        
      
        <?php
		for($i=1;$i<=$pagecount;$i++)
		{
			$cls = $page==$i?'class = "activepage"':'class = "pagn"';
			
			?>
            <option value="<?php echo $i;?>" <?php if($_GET['page']==$i){ ?>  selected="selected" <?php }?>><?php echo $i;?></option>
            <?php
		}
		?>
        </select>
        <?php
		if($page<$i-1){
			$next=$_GET['page']+1;
			?>
             <a class="pagf" href="<?php print SITEURL ?>/SearchResult/<?php echo $next ?>/<?php echo $_GET['result'] ?>">Next</a>
            <?php 
			}
		//echo '<a class="pagl" href="?page='.($i-1).'">Last</a>';

	}
}

?>