<?php
$conn = mysql_connect('localhost', 'root', '','crmnew') or die("Could not connect database");

?>