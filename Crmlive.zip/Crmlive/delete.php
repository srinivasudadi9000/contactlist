<?php 
include('db.php');
if($_POST['id'])
{
$id=$_POST['id'];
//echo "DELETE FROM `jqcalendar` WHERE Id='$id'";
$delete = "DELETE FROM `jqcalendar` WHERE Id='$id'";
mysql_query($delete);
}

?>