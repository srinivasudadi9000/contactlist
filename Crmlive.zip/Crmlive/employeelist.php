<?php include("includes/header.php");

include("includes/leftnav.php");

$userObj->checkloggedin();

$allemployee1=$userObj->getAllemployeeslist();

$allemployees=$userObj->getAllemployeeslist($start,$limit);

//print_r('allcustomers1');

//$allemployees=$userObj->getAllemployeeslist();

if($_GET['action']=="delete")

{

//print "Hii";die;

$userObj->deleteEmployee($_GET['id']);

}

?>



        <!--<section class="content-header">

          <h1>

           Employee Details

            

          </h1>

          

        </section>-->



        <!-- Main content -->

        <section class="content">

          <div class="row">

            <!-- left column -->

            <div class="col-md-6">

              <!-- general form elements -->

             

                <!-- /.box-header -->

                <!-- form start -->

              <div class="content-wrapper">

        <!-- Content Header (Page header) -->

        <section class="content-header">

          <h1>

            Employee List

          

          </h1>

          <!--<ol class="breadcrumb">

            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>

            <li><a href="#">Tables</a></li>

            <li class="active">Data tables</li>

          </ol>-->

        </section>



        <!-- Main content -->

        <section class="content">

          <div class="row">

            <div class="col-xs-12">

                          <div class="box">
                          
                           <div  style="float:right;margin-right: 12px;">
                            
                <input type="button" id="submit" value="Add" class="btn btn-primary" style="width:100px;margin-top:-5px;margin-top: 12px;" onclick="window.location.href='<?php print SITEURL; ?>/Register'">
                             
                              </div>

                <div class="box-header">

                  <h3 class="box-title"><span style="margin-left: 10px;"><b>Employee List</b></span>
                  
                                <?php 
                         if($_GET['err']!="")
                          {
						  	echo '<p class="index_suc">'.$_GET['err'].'</p>';
							//unset($_SESSION['err']);
						  
						  }
						  else if($_GET['ferr']!="")
						  {
							echo '<p class="index_err">'.$_GET['ferr'].'</p>';
							//unset($_SESSION['ferr']);
						  }
						  ?>
                  </h3>

                </div><!-- /.box-header -->

                <div class="box-body">

                  <table id="example1" class="table table-bordered table-striped">

                    <thead>

                      <tr>

                        <th>Name</th>

                        <th>Email</th>

                        <th>Phone Number</th>

                        <th>Mobile Number</th>

                        <th>Address</th>

                         <th>Leads</th>

                        <th>Status</th>

                           	<th>Delete</th>

                      </tr>

                    </thead>

                    <tbody>

                    <?php $ii=0;
						if(!empty($allemployees))
						{
					    foreach($allemployees as $all_employees) {
                       //$userDetails=$userObj->getUserDetails($all_leads->user_id);
					   if($ii%2==0)
					   {
						   $color="even";
						}
						else
						{
							$color="odd";
						}?>

                      <tr>

                 

                                        <td align="center" width="20%" onclick="window.location.href ='employeelistview.php?id=<?php print $all_employees->id?>'"><?php echo "<p style='width:100%;word-wrap:break-word;'>".  $all_employees->firstname."".$all_employees->lastname;"</p>"?></td>
                        <td align="center" width="30%" onclick="window.location.href ='employeelistview.php?id=<?php print $all_employees->id?>'"><?php echo "<p style='width:100%;word-wrap:break-word;'>".  $all_employees->email; "</p>"?></td>
                        <td align="center" width="20%" onclick="window.location.href ='employeelistview.php?id=<?php print $all_employees->id?>'"><?php echo "<p style='width:100%;word-wrap:break-word;'>".  $all_employees->phonenumber; "</p>"?></td>
                        <td align="center" width="20%" onclick="window.location.href ='employeelistview.php?id=<?php print $all_employees->id?>'"><?php echo "<p style='width:100%;word-wrap:break-word;'>".  $all_employees->mobilenumber; "</p>"?></td>
                        <td align="center" width="20%" onclick="window.location.href ='employeelistview.php?id=<?php print $all_employees->id?>'"><?php echo "<p style='width:100%;word-wrap:break-word;'>".  $all_employees->address;"</p>"?></td>
						<td align="center" width="20%" ><a href="<?php print SITEURL?>/AssignLeadsView/<?php print $all_employees->id?>"><img src="<?php print SITEURL?>/images/leeds_list new.png"/> </a></td>
						
                <td align="center" width="10%" class="delete" id="<?php echo $all_employees->id; ?>" style="cursor:pointer"><?php print $all_employees->status?></td>
          <td align="center" ><a href="employeelist.php?id=<?php print $all_employees->id;?>&action=delete"><img src="<?php print SITEURL?>/images/delete1.png"/> </a></td>
                      </tr>

                     

                    <?php
					   $ii++;
					    }
						}
						else
						{
							?>
                            <tr>
                            	<td colspan="6"> No Orders</td>
                            </tr>
                            <?php 
						}
						?>
                   

                        

                    </tfoot>

                  </table>

                </div><!-- /.box-body -->

              </div><!-- /.box -->

            </div><!-- /.col -->

          </div><!-- /.row -->

        </section><!-- /.content -->

      </div>

             



              <!-- Form Element sizes -->

              <!-- /.box -->



              <!-- /.box -->



              <!-- Input addon -->

              <!-- /.box -->



            </div><!--/.col (left) -->

            <!-- right column -->

            <!--/.col (right) -->

          </div>   <!-- /.row -->

        </section><!-- /.content -->


     


 <?php include("includes/footer.php");?>
<script type="text/javascript">

$(function() {

$(".delete").click(function(){ //alert("hi");

var element = $(this);

var del_id = element.attr("id");

var info = 'id=' + del_id;

if(confirm("Are you sure you want to change the status?"))

{

 $.ajax({

   type: "POST",

   url: "changestatus.php",

   data: info,

   success: function(response){ //alert(response);

   location.reload();

 }

}); 

 }

return false;

});

});

</script> 
