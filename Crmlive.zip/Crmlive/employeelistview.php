<?php include("includes/header.php");
include("includes/leftnav.php");
$userObj->checkloggedin();

//$allemployee1=$userObj->getAllemployeeslist();
$allemployeesview=$userObj->getemployeeview($_GET['id']);
//print_r($allemployee1);
//$allemployeesview=$userObj->getemployeeview($_GET['id']);
//print_r($allemployeesview);
?>
        <!-- Main content -->
        <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-6">
              <!-- general form elements -->
             
                <!-- /.box-header -->
                <!-- form start -->
              <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
             EMPLOYEE PROFILE
            
          </h1>
          <!--<ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Tables</a></li>
            <li class="active">Data tables</li>
          </ol>-->
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12" style="width:72%;">
                          <div class="box" style="min-height:846px;">
                <div class="box-header">
                  <h3 class="box-title">Employee Details</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table class="table table-bordered">
                    <tr>
                      <th>First Name</th><td><?php print $allemployeesview->firstname?></td>
                    </tr>
                    <tr>
                      <th>Last Name</th><td><?php print $allemployeesview->lastname?></td>
                    </tr>
					<tr>
                      <th>Display Name</th><td><?php print $allemployeesview->disname?></td>
                    </tr>
                    <tr><th>Email</th><td><?php print $allemployeesview->email?></td></tr>
                     	<tr><th>Phone Number</th><td><?php print $allemployeesview->phonenumber?></td></tr>
                        <tr><th>Mobile Number</th><td><?php print $allemployeesview->mobilenumber?></td></tr>
                     	<tr><th>Address</th><td><?php print $allemployeesview->address?></td></tr>
                     	<tr><th>Status</th><td><?php print $allemployeesview->status?></td></tr>
                         
                  </table>
                   <div class="box-footer" style=" margin-left: 80%;"><tr><td><input type="button" name="button"  onclick="window.location.href='<?php echo SITEURL?>/editprofile.php?id=<?php echo $allemployeesview->id; ?>'" value="Edit"   class="btn btn-primary"/></td>
                    <td class="float:right;"><input type="button" name="button"  onclick="window.location.href='<?php echo SITEURL?>/employeelist.php'" value="Back"  class="btn btn-primary"/></td></tr></div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
             <?php include("includes/rightnav.php"); ?>
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div>
             

              <!-- Form Element sizes -->
              <!-- /.box -->

              <!-- /.box -->

              <!-- Input addon -->
              <!-- /.box -->

            </div><!--/.col (left) -->
            
                      
            <!-- right column -->
            <!--/.col (right) -->
          </div>   <!-- /.row -->
        </section><!-- /.content -->
     
      
<?php  include("includes/footer.php");?>


