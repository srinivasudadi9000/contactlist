<?php include("includes/header.php");
include("includes/leftnav.php");
$userObj->checkloggedin();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	//print_r($_POST);
	$userObj->registerUser($_POST);
	}
?>
<script type="text/javascript" src="<?php print SITEURL?>js/fancy/lib/jquery-1.10.1.min.js"></script>

<script type="text/javascript">
        function checkemail(value)
		{
			
		var xmlhttp;
        if (window.XMLHttpRequest)
          {// code for IE7+, Firefox, Chrome, Opera, Safari
          xmlhttp=new XMLHttpRequest();
          }
        else
          {// code for IE6, IE5
          xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
          }
        xmlhttp.onreadystatechange=function()
        {
          if (xmlhttp.readyState==4 && xmlhttp.status==200)
          {
			  //alert(xmlhttp.responseText);

            var res=xmlhttp.responseText;
			if(res==1){
				document.getElementById("display").innerHTML="Email already exists";
				document.registration.email.value="";
			}
			else{
				document.getElementById("display").innerHTML="";
			}
			
			  }
          }
        xmlhttp.open("GET","checkemail.php?emailid="+value,true);
		//alert("first");
		
        xmlhttp.send();
		
		}
		
	
		
	
</script>



<script type="text/javascript">
        function checkuname(value)
		{
			//alert("hi");
		var xmlhttp;
        if (window.XMLHttpRequest)
          {// code for IE7+, Firefox, Chrome, Opera, Safari
          xmlhttp=new XMLHttpRequest();
          }
        else
          {// code for IE6, IE5
          xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
          }
        xmlhttp.onreadystatechange=function()
        {
          if (xmlhttp.readyState==4 && xmlhttp.status==200)
          {
			  //alert(xmlhttp.responseText);

            var res=xmlhttp.responseText;
			if(res==1){
				document.getElementById("displayuname").innerHTML="User Name already exists";
				document.registration.uname.value="";
			}
			else{
				document.getElementById("displayuname").innerHTML="";
			}
			
			  }
          }
        xmlhttp.open("GET","checkuname.php?uname="+value,true);
		//alert("first");
		
        xmlhttp.send();
		
		}
	
</script>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>AdminLTE 2 | Dashboard</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 3.3.2 -->
    <link href="../../bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- Font Awesome Icons -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons -->
    <link href="http://code.ionicframework.com/ionicons/2.0.0/css/ionicons.min.css" rel="stylesheet" type="text/css" />
    <!-- Theme style -->
    <link href="../../dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <!-- AdminLTE Skins. Choose a skin from the css/skins 
         folder instead of downloading all of them to reduce the load. -->
    <link href="../../dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="skin-blue">
    <div class="wrapper">
      
      
      <!-- Left side column. contains the logo and sidebar -->
     

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
           Employee Registration
            
          </h1>
           <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Employee Registration</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-6" style="width:72%">
              <!-- general form elements -->
              <div class="box box-primary">
                <!-- /.box-header -->
                <!-- form start -->
              <form id="registration" name="registration" method="post" action="">
                  <div class="box-body">
                  <div class="form">
                  <div class="form-group">
                      <label for="exampleInputEmail1" class="fieldname">User Name</label>
                      <input type="text" class="form-control fieldtype" name="uname" id="uname" onChange="return checkuname(this.value);" >
                        <label id="displayuname" style="color:#F00; font-size:16px;padding:0px 0px 0px 0px;"></label>
                      <label id="euname" style="visibility:hidden;color:red; margin-left: 136px;margin-top: 10px;"> Please Enter User Name</label>
                      <div style="width:100%; clear:both;"></div>
                    </div>
                     <div class="form-group">
                      <label for="exampleInputEmail1" class="fieldname">First Name</label>
                      <input type="text" class="form-control fieldtype" name="fname" id="fname" >
                      <label id="efname" style="visibility:hidden;color:red;margin-left: 136px;margin-top: 10px;">Please enter First Name</label>
                      <div style="width:100%; clear:both;"></div>
                    </div>
                       <div class="form-group">
                      <label for="exampleInputEmail1" class="fieldname">Last Name</label>
                      <input type="text" class="form-control fieldtype" name="lname" id="lname" >
                      <label id="elname" style="visibility:hidden;color:red;margin-left: 136px;margin-top: 10px;">Please enter Last Name</label>
                      <div style="width:100%; clear:both;"></div>
                    </div>
                    <div class="form-group">
                    <label for="exampleInputEmail1" class="fieldname">Display Name</label>
                    <input type="text" class="form-control fieldtype" name="dname" id="dname">
                    <label id="edname" style="visibility:hidden;color:red;margin-left: 136px;margin-top: 10px;">Please enter Display Name</label>
                      <div style="width:100%; clear:both;"></div>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1" class="fieldname">Email address</label>
                      <input type="email" class="form-control fieldtype" id="email" name="email"  onChange="return checkemail(this.value);" >
                        <label id="display" style="color:#F00; font-size:16px;padding:0px 0px 0px 0px; position:relative; left:159px; top:20px;"></label>
                      <label id="eemail" style="visibility:hidden;color:red;margin-left: 136px;margin-top: 10px;">Enter valid email id</label>
                      <div style="width:100%; clear:both;"></div>
                    </div>
                    
                       <div class="form-group">
                      <label for="exampleInputPassword1" class="fieldname">Password</label>
                      <input type="password" class="form-control fieldtype" id="pwd" name="pwd" >
                      <label id="epwd" style="visibility:hidden;color:red;margin-left: 136px;margin-top: 10px;">Please enter Password</label>
                      <div style="width:100%; clear:both;"></div>
                    </div>
                    
                    <div class="form-group">
                      <label for="exampleInputPassword1" class="fieldname">Confirm Password</label>
                      <input type="password" class="form-control fieldtype" id="pwd1" name="pwd1" >
                      <label id="epwd1" style="visibility:hidden;color:red;margin-left: 136px;margin-top: 10px;">Password missmatch</label>
                      <div style="width:100%; clear:both;"></div>
                      
                    </div>
                    
                       <div class="form-group">
                      <label for="exampleInputPassword1" style="width:15%; margin-right:5%;">Gender</label>
                      <input  type="radio" name="gender"   value="male" checked="checked" />  Male
                       <input   type="radio" name="gender" value="female" />     Female
                       <div style="width:100%; clear:both;"></div>
                
                    </div>
                      <div class="form-group">
                      <label for="exampleInputPassword1" class="fieldname">Mobile Number</label>
                      <input type="text" class="form-control fieldtype" id="mobile_number" name="mobile_number" >
                       <label id="emobile" style="visibility:hidden;color:red;margin-left: 136px;margin-top: 10px;">Please enter Mobile number</label>
                      <div style="width:100%; clear:both;"></div>
                    </div>

                     <div class="form-group">
                      <label for="exampleInputPassword1 fieldname">Phone</label>
                      <input type="text" class="form-control fieldtype" id="phone" name="phone" >
                       <label id="ephone" style="visibility:hidden;color:red;margin-left: 136px;margin-top: 10px;">Enter valid Phone number</label>
                      <div style="width:100%; clear:both;"></div>
                    </div>
                     <div class="form-group">
                      <label for="exampleInputPassword1" class="fieldname">Address</label>
                      <textarea rows="6" class="form-control fieldtype" cols="36" name="addr" id="addr" ></textarea>
                      <label id="eaddr" style="visibility:hidden;color:red;margin-left: 136px;margin-top: 10px;">Enter Address</label>
                      <div style="width:100%; clear:both;"></div>
                    </div>
                    
                    
                    </div>
                  </div><!-- /.box-body -->

                  <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </div>
                </form>
              </div><!-- /.box -->

              <!-- Form Element sizes -->
              <!-- /.box -->

              <!-- /.box -->

              <!-- Input addon -->
              <!-- /.box -->

            </div><!--/.col (left) -->
                 <?php include('includes/rightnav.php'); ?>
            <!-- right column -->
            <!--/.col (right) -->
          </div>   <!-- /.row -->
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
   <?php include('includes/footer.php')?>
<script>
$(document).ready(function(){
	//alert();
	 $("#email").blur(function(){
 var remail=new RegExp("^[a-z0-9.]+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$");
 var email = $("#email").val();
 // alert(email);
 if(remail.test(email)){
	//	$("#email").css("background-color","#FFFFFF");
		$("#eemail").css("visibility","hidden");
		
		}
	else
	  {
	  // $("#email").css("background-color","#F5DADB");
	  $("#eemail").css("visibility","visible");
	}
 });
 $("#email").keyup(function(){
 var remail=new RegExp("^[a-z0-9.]+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$");
 var email = $("#email").val();
 // alert(email);
 if(remail.test(email)){
		//$("#email").css("background-color","#FFFFFF");
		$("#eemail").css("visibility","hidden");
		}
	else
	  {
	   //$("#email").css("background-color","#F5DADB");
	  $("#eemail").css("visibility","visible");
	}
 });
 
 $("#uname").blur(function(){
	var runame=new RegExp("^[a-zA-Z]{1,}$");
	var uname=$("#uname").val();
	if(runame.test(uname)){
		
		//$("#uname").css("background-color","#FFFFFF");
		$("#euname").css("visibility","hidden");
		mailvalidate(uname);
		}
	else
	  {
	
	   // $("#uname").css("background-color","#F5DADB");
	  $("#euname").css("visibility","visible");
	}
  });
$("#uname").keyup(function(){
	var runame=new RegExp("^[a-zA-Z]{1,}$");
	var uname=$("#fname").val();
	if(runame.test(uname)){

	//	$("#uname").css("background-color","#FFFFFF");
		$("#euname").css("visibility","hidden");
		}
	else
	  {
	
	  // $("#uname").css("background-color","#F5DADB");
	  $("#euname").css("visibility","visible");
	}
  });
	
 
 	$("#fname").blur(function(){
	var rfname=new RegExp("^[a-zA-Z]{1,}$");
	var fname=$("#fname").val();
	if(rfname.test(fname)){
		
		//$("#fname").css("background-color","#FFFFFF");
		$("#efname").css("visibility","hidden");
		}
	else
	  {
	
	   //$("#fname").css("background-color","#F5DADB");
	  $("#efname").css("visibility","visible");
	}
  });
$("#fname").keyup(function(){
	var rfname=new RegExp("^[a-zA-Z]{1,}$");
	var fname=$("#fname").val();
	if(rfname.test(fname)){
		
		//$("#fname").css("background-color","#FFFFFF");
		$("#efname").css("visibility","hidden");
		}
	else
	  {
	
	   //$("#fname").css("background-color","#F5DADB");
	  $("#efname").css("visibility","visible");
	}
  });
	
 $("#lname").blur(function(){
	var rlname=new RegExp("^[a-zA-Z]{1,}$");
	var lname=$("#lname").val();
	if(rlname.test(lname)){
		
		//$("#lname").css("background-color","#FFFFFF");
		$("#elname").css("visibility","hidden");
		}
	else
	  {
	
	   //$("#lname").css("background-color","#F5DADB");
	  $("#elname").css("visibility","visible");
	}
  });
$("#lname").keyup(function(){
	var rlname=new RegExp("^[a-zA-Z]{1,}$");
	var lname=$("#lname").val();
	if(rlname.test(lname)){
		
	//	$("#lname").css("background-color","#FFFFFF");
		$("#elname").css("visibility","hidden");
		}
	else
	  {
	
	  // $("#lname").css("background-color","#F5DADB");
	  $("#elname").css("visibility","visible");
	}
  });
  
 $("#dname").blur(function(){
	var rdname=new RegExp("^[a-zA-Z]{1,}$");
	var dname=$("#dname").val();
	if(rdname.test(dname)){
		
		//$("#lname").css("background-color","#FFFFFF");
		$("#edname").css("visibility","hidden");
		}
	else
	  {
	
	   //$("#lname").css("background-color","#F5DADB");
	  $("#edname").css("visibility","visible");
	}
  });
$("#dname").keyup(function(){
	var rlname=new RegExp("^[a-zA-Z]{1,}$");
	var dname=$("#dname").val();
	if(rlname.test(dname)){
		
	//	$("#lname").css("background-color","#FFFFFF");
		$("#edname").css("visibility","hidden");
		}
	else
	  {
	
	  // $("#lname").css("background-color","#F5DADB");
	  $("#edname").css("visibility","visible");
	}
  });
 $("#pwd").blur(function(){
	var rpwd=new RegExp("^[a-zA-Z0-9@#*]{1,}$");
	var pwd=$("#pwd").val();
	if(rpwd.test(pwd)){
		//$("#pwd").css("background-color","#FFFFFF");
		$("#epwd").css("visibility","hidden");
		}
	else
	  {
	   //$("#pwd").css("background-color","#F5DADB");
	  $("#epwd").css("visibility","visible");
	}
  });
 $("#pwd").keyup(function(){
	var rpwd=new RegExp("^[a-zA-Z0-9@#*]{1,}$");
	var pwd=$("#pwd").val();
	if(rpwd.test(pwd)){
		//$("#pwd").css("background-color","#FFFFFF");
		$("#epwd").css("visibility","hidden");
		}
	else
	  {
	   //$("#pwd").css("background-color","#F5DADB");
	  $("#epwd").css("visibility","visible");
	}
  });
   $("#pwd1").blur(function(){
	var pwd1=$("#pwd1").val();
	var pwd=$("#pwd").val();
	if(pwd==pwd1){
		//$("#pwd1").css("background-color","#FFFFFF");
		$("#epwd1").css("visibility","hidden");
		}
	else
	  {
	   //$("#pwd1").css("background-color","#F5DADB");
	  $("#epwd1").css("visibility","visible");
	}
  });
   $("#pwd1").keyup(function(){
	var pwd1=$("#pwd1").val();
	var pwd=$("#pwd").val();
	if(pwd==pwd1){
		//$("#pwd1").css("background-color","#FFFFFF");
		$("#epwd1").css("visibility","hidden");
		}
	else
	  {
	   //$("#pwd1").css("background-color","#F5DADB");
	  $("#epwd1").css("visibility","visible");
	}
  });
 
 $("#phone").blur(function(){
 var rphone=new RegExp("^[0-9]{1,}$");
 var phone = $("#phone").val();
 if(rphone.test(phone)){
	//	$("#phone").css("background-color","#FFFFFF");
		$("#ephone").css("visibility","hidden");
		}
	else
	  {
	  // $("#phone").css("background-color","#F5DADB");
	  $("#ephone").css("visibility","visible");
	}
 });
 $("#phone").keyup(function(){
 var rphone=new RegExp("^[0-9]{1,}$");
 var phone = $("#phone").val();
 if(rphone.test(phone)){
		//$("#phone").css("background-color","#FFFFFF");
		$("#ephone").css("visibility","hidden");
		}
	else
	  {
	   //$("#phone").css("background-color","#F5DADB");
	  $("#ephone").css("visibility","visible");
	}
 });
 
 $("#mobile_number").blur(function(){
 var rmobile=new RegExp("^[0-9]{1,}$");
 var mobile = $("#mobile_number").val();
 if(rmobile.test(mobile)){
	//	$("#mobile_number").css("background-color","#FFFFFF");
		$("#emobile").css("visibility","hidden");
		}
	else
	  {
	  // $("#mobile_number").css("background-color","#F5DADB");
	  $("#emobile").css("visibility","visible");
	}
 });
 $("#mobile_number").keyup(function(){
 var rmobile=new RegExp("^[0-9]{1,}$");
 var mobile = $("#mobile_number").val();
 if(rmobile.test(mobile)){
		//$("#mobile_number").css("background-color","#FFFFFF");
		$("#emobile").css("visibility","hidden");
		}
	else
	  {
	   //$("#mobile_number").css("background-color","#F5DADB");
	  $("#emobile").css("visibility","visible");
	}
 });
 $("#addr").blur(function(){
 
 var addr = $("#addr").val();
 if(addr!=''){
		//$("#addr").css("background-color","#FFFFFF");
		$("#eaddr").css("visibility","hidden");
		}
	else
	  {
	   // $("#addr").css("background-color","#F5DADB");
	  $("#eaddr").css("visibility","visible");
	}
 });
 $("#addr").keyup(function(){
 
 var addr = $("#addr").val();
 if(addr!=''){
		//$("#addr").css("background-color","#FFFFFF");
		$("#eaddr").css("visibility","hidden");
		}
	else
	  {
	   //$("#addr").css("background-color","#F5DADB");
	  $("#eaddr").css("visibility","visible");
	}
 });
  $("#city").blur(function(){
  var rcity=new RegExp("^[a-zA-Z]{1,}$");
 var city = $("#city").val();
 if(rcity.test(city)){
		//$("#city").css("background-color","#FFFFFF");
		$("#ecity").css("visibility","hidden");
		}
	else
	  {
	   //$("#city").css("background-color","#F5DADB");
	  $("#ecity").css("visibility","visible");
	}

 });
  $("#city").keyup(function(){
  var rcity=new RegExp("^[a-zA-Z]{1,}$");
 var city = $("#city").val();
 if(rcity.test(city)){
	//	$("#city").css("background-color","#FFFFFF");
		$("#ecity").css("visibility","hidden");
		}
	else
	  {
	  // $("#city").css("background-color","#F5DADB");
	  $("#ecity").css("visibility","visible");
	}

 });
 $("#state").blur(function(){
  var rstate=new RegExp("^[a-zA-Z]{1,}$");
 var state = $("#state").val();
 if(rstate.test(state)){
		//$("#state").css("background-color","#FFFFFF");
		$("#estate").css("visibility","hidden");
		}
	else
	  {
	  // $("#state").css("background-color","#F5DADB");
	  $("#estate").css("visibility","visible");
	}

 });
 
  $("#state").keyup(function(){
  var rstate=new RegExp("^[a-zA-Z]{1,}$");
 var state = $("#state").val();
 if(rstate.test(state)){
		//$("#state").css("background-color","#FFFFFF");
		$("#estate").css("visibility","hidden");
		}
	else
	  {
	   //$("#state").css("background-color","#F5DADB");
	  $("#estate").css("visibility","visible");
	}

 });
 $("#country").change(function(){
 
 var country = $("#country").val();
 //alert(country);
 if(country!=''){
		//$("#country").css("background-color","#FFFFFF");
		$("#ecountry").css("visibility","hidden");
		}
	else
	  {
	   //$("#country").css("background-color","#F5DADB");
	  $("#ecountry").css("visibility","visible");
	}
 });
 
$("form").submit(function(event){
	var remail=new RegExp("^[a-z0-9.]+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$");
 var email = $("#email").val();
 var rpwd=new RegExp("^[a-z0-9@#*]{5,}$");
var pwd=$("#pwd").val();
var pwd1=$("#pwd1").val();
	var pwd=$("#pwd").val();
	var rfname=new RegExp("^[a-zA-Z]{1,}$");
	var fname=$("#fname").val();
	//var rdname=new RegExp("^[a-zA-Z]{1,}$)";
	//var dname=$("#dname").val();
	var rlname=new RegExp("^[a-zA-Z]{1,}$");
	var lname=$("#lname").val();
	var rphone=new RegExp("^[0-9]{1,}$");
 var phone = $("#phone").val();
  var mobile = $("#mobile_number").val();
  var rmobile=new RegExp("^[0-9]{1,}$");
  var addr = $("#addr").val();
  var rcity=new RegExp("^[a-zA-Z]{1,}$");
 var city = $("#city").val();
  var rstate=new RegExp("^[a-zA-Z]{1,}$");
 var state = $("#state").val();
 
	var runame=new RegExp("^[a-zA-Z]{1,}$");
	var uname=$("#uname").val();
	
var count=1;
if(runame.test(uname)){
		
		//$("#uname").css("background-color","#FFFFFF");
		$("#euname").css("visibility","hidden");

		}
	else
	  {
		  count=0;	
	   // $("#uname").css("background-color","#F5DADB");
	  $("#euname").css("visibility","visible");
	}
	

if(rstate.test(state)){
	//	$("#state").css("background-color","#FFFFFF");
		$("#estate").css("visibility","hidden");
		}
	else
	  {
		  count=0;
	  // $("#state").css("background-color","#F5DADB");
	  $("#estate").css("visibility","visible");
	}
 
if(rcity.test(city)){
		// $("#city").css("background-color","#FFFFFF");
		$("#ecity").css("visibility","hidden");
		}
	else
	  {
		  count=0;
	   // $("#city").css("background-color","#F5DADB");
	  $("#ecity").css("visibility","visible");
	}
if(addr!=''){
		// $("#addr").css("background-color","#FFFFFF");
		$("#eaddr").css("visibility","hidden");
		}
	else
	  {
		  count=0;
	   // $("#addr").css("background-color","#F5DADB");
	  $("#eaddr").css("visibility","visible");
	}

if(rphone.test(phone)){
		// $("#phone").css("background-color","#FFFFFF");
		$("#ephone").css("visibility","hidden");
		}
	else
	  {
		  count=0;
	   // $("#phone").css("background-color","#F5DADB");
	  $("#ephone").css("visibility","visible");
	}

if(rmobile.test(mobile)){
		// $("#mobile_number").css("background-color","#FFFFFF");
		$("#emobile").css("visibility","hidden");
		}
	else
	  {
		  count=0;
	   // $("#mobile_number").css("background-color","#F5DADB");
	  $("#emobile").css("visibility","visible");
	}
 	

 	
if(rlname.test(lname)){
		
		// $("#lname").css("background-color","#FFFFFF");
		$("#elname").css("visibility","hidden");
		}
	else
	  {
	count=0;
	   // $("#lname").css("background-color","#F5DADB");
	  $("#elname").css("visibility","visible");
	}
if(rdname.test(dname)){
		
		// $("#lname").css("background-color","#FFFFFF");
				$("#edname").css("visibility","hidden");
		}
	else
	  {
	count=0;
	   // $("#lname").css("background-color","#F5DADB");
	  $("#edname").css("visibility","visible");
	}
if(rfname.test(fname)){
		
		// $("#fname").css("background-color","#FFFFFF");
		$("#efname").css("visibility","hidden");
		}
	else
	  {
	count=0;
	   // $("#fname").css("background-color","#F5DADB");
	  $("#efname").css("visibility","visible");
	}
if(remail.test(email)){
		// $("#email").css("background-color","#FFFFFF");
		$("#eemail").css("visibility","hidden");
		}
	else
	  {
	  count=0;
	   // $("#email").css("background-color","#F5DADB");
	  $("#eemail").css("visibility","visible");
	}
	if(rpwd.test(pwd)){
		// $("#pwd").css("background-color","#FFFFFF");
		$("#epwd").css("visibility","hidden");
		}
	else
	  {
	  count=0;
	   // $("#pwd").css("background-color","#F5DADB");
	  $("#epwd").css("visibility","visible");
	  }
 	
	if(pwd==pwd1){
		// $("#pwd1").css("background-color","#FFFFFF");
		$("#epwd1").css("visibility","hidden");
		}
	else
	  {
	  count=0;
	 
	   // $("#pwd1").css("background-color","#F5DADB");
	  $("#epwd1").css("visibility","visible");
	}

	if(count==0)
	{
		event.preventDefault();
	
	}
 });

 
});

</script>