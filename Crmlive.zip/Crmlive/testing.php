<?php 

include('dbconfig.php');

include('includes/dbconnection.php');

include("model/user.class.php");

$userObj=new userClass();     

	



?>

	<link href="<?php print SITEURL?>/style.css" type="text/css" rel="stylesheet" />

	<?php  

	$qq=mysql_query("select * from crm_customer_list where id='".$_GET['id']."'");

				           $profile=mysql_fetch_object($qq); 

						   //print_r($res);

		?>





                      <div class="dashboard_inner_wrapper_popup">

                          <h4> Edit Lead Profile</h4>

                        <!--   <h4><img src="images/icons1_24.png"> DASHBOARD</h4>

                           <div class="graph_img"><img src="images/home_banner_11.png" class="res_images"></div>-->

                       <div class="fullform">

                       

                       



<form method="post"  name="customer" id="customer" action="" >

<div style="border:0px solid #d3d3d3;margin:auto;" >

  <table style="position:relative;margin:15px auto;color:#2f4f4f;font-family:calibri;padding-top:15px;width: 100%;">

   

    <tr>

      <td>Title:</td>

      <td>

	  <select name="title" style="height:30px;width:200px; margin-top:12px;">

		<option value="">--Title--</option>

		<option value="Mr" <?php if($profile->title=="Mr") {?> selected<?php } ?>>Mr</option>

		<option value="Mrs" <?php if($profile->title=="Mrs") {?> selected<?php } ?>>Mrs</option>

		<option value="Miss" <?php if($profile->title=="Miss") {?> selected<?php } ?>>Miss</option>

	</select>

	  </td>

        

    </tr>

       <tr>

      <td>First Name:</td>

      <td><input type="text" name="firstname" id="firstname" class="form-control"  value="<?php echo $profile->firstname;?>" style="margin-top:12px;">

        

    </tr>

       

        <tr>

            <td><label>Last Name:</label></td>

            <td><input type="text" name="lastname" id="lastname"class="form-control" value="<?php echo $profile->lastname;?>" style="margin-top:12px;">

             </td>

        </tr>

        <tr>

            <td><label >Email:</label></td>

            <td><input type="text" class="form-control"  name="email" id="email" value="<?php echo $profile->email;?>" onChange="return checkemail(this.value);" style="margin-top:12px;">

            <label id="display" style="color:#F00; font-size:16px;padding:0px 0px 0px 0px;" style="margin-top:12px;"></label>

            </td> 

            

        </tr>

        <tr>

            <td><label>Mobile Number:</label></td>

            <td><input type="text" name="mobilenumber" id="mobilenumber" class="form-control"   value="<?php echo $profile->mobile_number;?>" style="margin-top:12px;"/>

             </td>

        </tr>

         <tr>

            <td><label>Phone Number:</label></td>

            <td><input type="text" name="phonenumber" id="phonenumber" class="form-control"  value="<?php echo substr($profile->phone_number,1);?>" style="margin-top:12px;"/>

			

             </td>

        </tr>

		 <tr>

            <td><label>Company:</label></td>

            <td><input type="text" name="company" id="company" class="form-control"  value="<?php echo $profile->company;?>" style="margin-top:12px;"/>

			

             </td>

        </tr>

         <tr>

            <td><label>Address:</label></td>

            <td>

            <textarea name="address" id="address" class="form-control"  rows="6" cols="36" style="margin-top:12px;"><?php echo $profile->address;?></textarea>

					</td>

		 </tr>

		 <tr>

            <td><label>Country</label></td>

            <td><input type="text" name="country" class="form-control"  id="country" value="<?php echo $profile->country;?>" style="margin-top:12px;">

             </td>

        </tr>

		<tr>

            <td><label>Town</label></td>

            <td><input type="text" name="town" id="town"  class="form-control" value="<?php echo $profile->town;?>" style="margin-top:12px;">

             </td>

        </tr>

		<tr>

            <td><label>Post Code</label></td>

            <td><input type="text" name="postcode" id="postcode" class="form-control" value="<?php echo $profile->postcode;?>"style="margin-top:12px;">

             </td>

        </tr>

				 

        

        <tr>

        	<td></td>

			<input type="hidden" name="hdn_id" id="hdn_id" value="<?php echo $profile->id;?>">

			<input type="hidden" name="hdn_status" id="hdn_status" value="<?php echo $profile->status;?>">

			<td>

           <div class="reg_btn" style="margin-top:12px;"><input type="submit" name="submit" value="Update" class="btn btn-primary" style="width:100px;margin-top:20px;"></div>

            </td>

            

                              

                                <div class="clear_fix"></div>

                              

            </td>

        </tr>

    </table>

    </div>

</form>

</div>

</div>

                      

                    

                 



                <div class="clear_fix"></div>



           

          

      <script type="text/javascript">

        function checkemail(value)

		{

			

		var xmlhttp;

        if (window.XMLHttpRequest)

          {// code for IE7+, Firefox, Chrome, Opera, Safari

          xmlhttp=new XMLHttpRequest();

          }

        else

          {// code for IE6, IE5

          xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");

          }

        xmlhttp.onreadystatechange=function()

        {

          if (xmlhttp.readyState==4 && xmlhttp.status==200)

          {

			  //alert(xmlhttp.responseText);



            var res=xmlhttp.responseText;

			if(res==1){

				document.getElementById("display").innerHTML="Email already exists";

				document.customer.email.value="";

				document.customer.email.focus();

			}

			else{

				document.getElementById("display").innerHTML="";

			}

			

			  }

          }

        xmlhttp.open("GET","checkcusemail.php?emailid="+value,true);

		//alert("first");

		

        xmlhttp.send();

		

		}


</script>
<script type="text/javascript">
function validate()
{
	 
 if(document.customer.firstname.value=="")
	{
		alert("Please enter firstname");
		document.customer.firstname.value='';
		document.customer.firstname.focus();
		return false;
		
	}
	
 	 if(document.customer.lastname.value=="")
	{
		alert("Please enter lastname");
		document.customer.lastname.value='';
		document.customer.lastname.focus();
		return false;
		
	} 
	if(document.customer.email.value=="")
	{
		alert("Please enter email");
		document.customer.email.value='';
		document.customer.email.focus();
		return false;
		
	}
	
	 var phoneno1 = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/; 	
 	 if(document.customer.mobilenumber.value.match(phoneno1)==null)
	{
		alert("Please enter mobilenumber");
		document.customer.mobilenumber.value='';
		document.customer.mobilenumber.focus();
		return false;
		
	}
	
	
	 var phoneno = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/; 	
 	 if(document.customer.phonenumber.value.match(phoneno)==null)
	{
		alert("Please enter phonenumber");
		document.customer.phonenumber.value='';
		document.customer.phonenumber.focus();
		return false;
		
	}
		
 	 if(document.customer.address.value=="")
	{
		alert("Please enter address");
		document.customer.address.value='';
		document.customer.address.focus();
		return false;
		
	}
	 	 if(document.customer.country.value=="")
	{
		alert("Please enter country");
		document.customer.country.value='';
		document.customer.country.focus();
		return false;
		
	} 	 if(document.customer.town.value=="")
	{
		alert("Please enter town");
		document.customer.town.value='';
		document.customer.town.focus();
		return false;
		
	}
	
	return true;
	
}
</script>






   

          
