<?php 
include('dbconfig.php');
include('includes/dbconnection.php');
include("model/user.class.php");
include("model/customer.class.php");
include("model/employee.class.php");
$userObj=new userClass();
$empObj=new employeeClass();
$customerObj=new customerClass();
echo $_GET['id'];
$res=$callConfig->deleteRecord(TPREFIX.TBL_COMMENTS_LIST,'id',$_GET['id']);
return true;	
?>