<?php include("includes/header.php");
include("includes/leftnav.php");
$allmessages=$userObj->getBoardMessages();
//print_r($allmessages);
if($_POST['submit']=="submit")
{
	//print_r($_POST);
	$userObj->insertBoard($_POST);
}
if($_GET['action']=="delete")
{
	//print_r($_POST);	
	$userObj->deleteMessage($_GET['id']);
}
if($_POST['editform']=="Save")
{
	//print_r($_POST);	exit;
	$userObj->UpdateAdminBoardMessage($_POST);
}?>

    <div class="wrapper">
      
      
      <!-- Left side column. contains the logo and sidebar -->
     

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
           Board
            
          </h1>
          
        </section>
        <?php if($_GET['action']=="edit")
{
$message=$userObj->getAdminMessage($_GET['eid']);
	//print_r($message); 
?>
                      <div class="dashboard_inner_wrapper">
                          <!---<h4> <img src="images/leeds_list _02.png"> Board  <?php 
                         if($_GET['err']!="")
                          {
						  	echo '<p class="index2_suc">'.$_GET['err'].'</p>';
							//unset($_SESSION['err']);
						  
						  }
						  else if($_GET['ferr']!="")
						  {
							echo '<p class="index2_err">'.$_GET['ferr'].'</p>';
							//unset($_SESSION['ferr']);
						  }
						  ?></h4>-->
                          <section class="content">
          <div class="row">
        <div class="col-md-6" style="width:70%; min-height:750px;">
              <!-- general form elements -->
              <div class="box box-primary">
        <form id="boardform" name="editboardform" method="post" action="">
                  <div class="box-body">
                  
                     <div class="form-group">
                      <label>Description:</label>
                       <textarea name="description" class="form-control" style="height:200px; padding:10px;" ><?php echo $message->description;?></textarea>
                      
                    </div>
                  </div><!-- /.box-body -->

                  <div class="box-footer">
                  <input type="hidden" name="hidden_id" value="<?php echo $message->id?>" />
                    <button type="submit" class="btn btn-primary"  name="editform" value="Save">Save</button>
                    <div style="width:100%; clear:both;"></div>
                  </div>
                </form>
                </div>
                </div>
                          <?php include('includes/rightnav.php'); ?>

                </div>
                </section>
                </div>
                <?php }
				else {?>
<section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-6" style="width:70%;min-height:750px;">
              <!-- general form elements -->
              <div class="box box-primary">
                <!-- /.box-header -->
                <!-- form start -->
              <form id="boardform" name="boardform" method="post" action="">
                  <div class="box-body">
                  
                     <div class="form-group">
                      <label>Description:</label>
                       <textarea name="description" class="form-control" style="height:200px;padding:10px;" ></textarea>
                      
                    </div>
                  </div><!-- /.box-body -->

                  <div class="box-footer">
                    <button type="submit"  style="float:right;" class="btn btn-primary"  name="submit" value="submit">Submit</button>
                    <div style="width:100%; clear:both;"></div>
                  </div>
                </form>
                <h4 style="margin-left:50px;">Messages </h4>
                <div id="testDiv3"> 
 <?php 
 
 
 echo "<table width='100%' style='border:1px solid #ccc;'>
 <tr style='border-bottom:1px solid #ccc;height:50px; background-color:#ccc;'>
		<th align='left' style='padding-left:50px;color:#000;font-size:14px; width:60%; text-align:left;'>
		Message
		</th>
		<th align='center' style='padding-left:5px;color:#000;font-size:14px; width:10%; text-align:center;'>
		Edit
		</th>
		<th align='center' style='padding-left:5px;color:#000;font-size:14px; width:10%; text-align:center;'>
		Delete
		</th>
		<th align='center' style='padding-left:5px;color:#000;font-size:14px; width:20%; text-align:center;'>
		
		Date
		</th>
		</tr>";
		
		
 	foreach($allmessages as $all_messages)
	{
		echo "<tr style='border-bottom:1px solid #ccc; height:40px;'>
		
		<td align='left' style='width:60%;padding-left:50px;'><p style='width:350px;;word-wrap:break-word;'>".$all_messages->description."</p></td>
		<td  align='center' style='width:10%;'><a href=".SITEURL."/board.php?eid=".$all_messages->id."&action=edit><img src='".SITEURL."/images/edit_03.png'/></a></td>
		<td  align='center' style='width:10%;'><a href=".SITEURL."/board.php?id=".$all_messages->id."&action=delete><img src='".SITEURL."/images/trash-icon_01.png'/></a></td>
		<td  align='center' style='width:20%;'>".$all_messages->createdon."</td></tr>";
	}
	
	echo "</table>";	
	
	
	
 ?>
 <?php  } ?>
 

    </div>
                
              </div><!-- /.box -->
  

            </div><!--/.col (left) -->
           <?php include('includes/rightnav.php'); ?>
          </div>   <!-- /.row -->
         
        </section>
        </div>
        </div>
        </body>
        </html>
        
        <?php include("includes/footer.php");?>