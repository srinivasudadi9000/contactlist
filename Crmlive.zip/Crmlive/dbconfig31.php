<?php
ob_start();
session_start();
ini_set("display_errors",0);  
//error_reporting(E_ERROR);
define("HOSTNAME","localhost");
define("USERNAME","ky1ecrmn_user");
define("PASSWORD","migratecrm@123");
define("DBNAME",  "ky1ecrmn_migratedatabase");
###################################################################

######### TABLE CONSTANTS 

###################################################################

/********* Table Prefix *********/

define('TPREFIX', 'crm_');

/********* Table Names *********/
define('TBL_SITESETTINGS','sitesettings');

define('TBL_USER_LOGIN','user_login');

define('TBL_CUSTOMER_LIST','customer_list');

define('TBL_SALES_EMPLOYEES','sales_employees');

define('TBL_BOARD','board');

define('TBL_JCAL','jqcalendar');

define('TBL_COMMENTS_LIST','comments');

define('TBL_USER_PAID','user_paid');

define('TBL_QUESTIONS','questions');

define('TBL_NOTES','notes');

define('TBL_ACTIVE_USERS','active_users');

define('TBL_LEADS_NOTES','leads_notes');

define('TBL_IPADDRESS_LIST','iplist');
//date_default_timezone_set("Asia/Kolkata");



define('STR_TO_TIME',strtotime(date("Y-m-d H:i:s")));

define('ONLY_DATE',date("m-d-Y"));

define('DATE_TIME',date("m-d-Y H:i:s"));

define('DATE_TIME_FORMAT',date("l dS F Y, H:i:s A", STR_TO_TIME));

define('DATETIMEFORMAT',date("l-dS-F-Y-H-i-s-A", STR_TO_TIME));

define('DBIN','INSERT INTO ');

define('DBUP','UPDATE ');

define('DBWHR',' WHERE ');

define('DBDEL','DELETE ');

define('DBFROM',' FROM ');

define('DBSELECT',' SELECT ');

define('DBSET',' SET ');

define('HEAD_LTN','location:');

define('DB_LMT',' LIMIT ');

define('DB_ORDER',' ORDER BY ');

define('DB_LIKE',' LIKE ');


define('ADMINROOT','administrator');

define('ACCESSIP','83.40.183.9');
###################################################################

######### Physical Path Constants 

###################################################################

//define(SITEROOT, 				$_SERVER['DOCUMENT_ROOT']."/beta");

define("SITEROOT", 				$_SERVER['DOCUMENT_ROOT']);

/*define(LISTINGIMAGESROOT, 		SITEROOT."/images/listings");
*/
define("UPLOADSROOT", 			SITEROOT."/uploads/");

define("USER_IMAGE_ROOT",	        SITEROOT."/images/");



###################################################################

######### Url Constants 

###################################################################

//define(SITEURL, 				"http://".$_SERVER['HTTP_HOST']);

define("SITEURL", 				"http://".$_SERVER['HTTP_HOST']);


define("IMGURL", 				SITEURL."/images");
define("UPLOADIMGURL", 			SITEURL."/uploads");


//define(SITEPATH_URL,'http://'.$_SERVER['HTTP_HOST']);

?>