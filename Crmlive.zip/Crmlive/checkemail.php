<?php
include('dbconfig.php');
include('includes/dbconnection.php');
if(isset($_GET['emailid']))
{   //echo "hi" ; exit;  
		 $query="SELECT * FROM crm_user_login WHERE email='".$_GET['emailid']."'";
		
		$res=mysql_query($query) or die(mysql_error());
		$result=mysql_num_rows($res);
		//echo $result;exit;
		if($result>0)
		{
			echo 1;
		}
		else
		{
		    echo 2;
			return true;
		}
		
		
}
    
	
?>
