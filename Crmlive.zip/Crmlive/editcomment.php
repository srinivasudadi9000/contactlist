<?php 
include('dbconfig.php');
include('includes/dbconnection.php');
include("model/user.class.php");
$userObj=new userClass();     
	

?>
	
	<?php  
	//echo "select * from crm_comments where id='".$_GET['commentid']."'";
	$qq=mysql_query("select * from crm_comments where id='".$_GET['commentid']."'");
				           $comments=mysql_fetch_object($qq); 
						   //print_r($comments);
		?>


                      <div class="dashboard_inner_wrapper_popup">
                          <h4> Edit Comment</h4>
                        <!--   <h4><img src="images/icons1_24.png"> DASHBOARD</h4>
                           <div class="graph_img"><img src="images/home_banner_11.png" class="res_images"></div>-->
                       <div class="fullform">
                       
                       

<form method="post"  name="customer" action="">
<div style="border:0px solid #d3d3d3;margin:auto;" >
  <table style="position:relative;margin:15px auto;color:#2f4f4f;font-family:calibri;padding-top:15px;">
   
    
     
       
        
       
        
         <tr>
            <td><label>Description:</label></td>
            <td>
            <textarea name="description" id="address" rows="6" cols="36" ><?php echo $comments->comments;?></textarea>
					</td>
		 </tr>
		
		
		
				 
        
        <tr>
        	<td></td>
			<input type="hidden" name="hdn_id" id="hdn_id" value="<?php echo $comments->id;?>"/>
			<input type="hidden" name="hdn_status" id="hdn_status" value="<?php echo $_GET['status'];?>">
			<input type="hidden" name="lead_id" id="lead_id" value="<?php echo $comments->emp_id;?>">
			
			<td>
           <div class="reg_btn"><input type="submit" name="editcomment" value="Update"  class="btn btn-primary" style="width:100px;margin-top:20px;"></div>
            </td>
            
                              
                                <div class="clear_fix"></div>
                              
            </td>
        </tr>
    </table>
    </div>
</form>
</div>
</div>
                      
                    
                 

                <div class="clear_fix"></div>

           
          
      <script type="text/javascript">
        function checkemail(value)
		{
			
		var xmlhttp;
        if (window.XMLHttpRequest)
          {// code for IE7+, Firefox, Chrome, Opera, Safari
          xmlhttp=new XMLHttpRequest();
          }
        else
          {// code for IE6, IE5
          xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
          }
        xmlhttp.onreadystatechange=function()
        {
          if (xmlhttp.readyState==4 && xmlhttp.status==200)
          {
			  //alert(xmlhttp.responseText);

            var res=xmlhttp.responseText;
			if(res==1){
				document.getElementById("display").innerHTML="Email already exists";
				document.customer.email.value="";
				document.customer.email.focus();
			}
			else{
				document.getElementById("display").innerHTML="";
			}
			
			  }
          }
        xmlhttp.open("GET","checkcusemail.php?emailid="+value,true);
		//alert("first");
		
        xmlhttp.send();
		
		}
		
	
		
	
</script>


   
          
