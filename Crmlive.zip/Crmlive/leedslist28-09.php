<?php 
include("includes/header.php");
include("includes/leftnav.php"); 

$userObj->checkloggedin();
$page = explode("/",$_GET['page']);
$_GET['page'] = $page[0];
$_GET['searchword'] = $page[1]; 

$rec_count=$userObj->getAllleedslistCount();
$limit = 200;
isset($_GET['page'])?$page=$_GET['page']:$page=1;
$start = (($page-1)*$limit);	

//echo $rec_count;
$pagecount = ceil($rec_count/$limit);
//echo $pagecount;
//$data =$frontObj->getallnewsdata($start,$limit); 
//echo $limit;
if($_GET['fld']!="")
{
$fld=$_GET['fld'];
}
else
{
$fld="id";
}
if($_GET['ord']!="")
{
$order=$_GET['ord'];
}
else
{
$order="DESC";
}
$allleads=$userObj->getAllleedslist($start,$limit,$fld,$order);
//print_r($allleads);exit;
$allemployees=$userObj->getAllemployeeslist();
if($_GET['action']=="delete")
{
	$userObj->deleteLeed($_GET['id']);
}
if ($_POST['submit']=='Submit') {
	//print_r($_POST); exit; 
	$userObj->asignToEmployee($_POST);
	}
	if ($_POST['search']=='Search') {
	//print_r($_POST); exit; 
	//$allleads->getSearchResults($start,$limit,$serachword);
	header("location:".SITEURL."/Leads/".$_GET['page']."/".$_POST['searchlead']);
	}	
	
	
	if($_GET['searchword']!="")
	{
	//print $_GET['searchword']; exit;
	$serachword=$_GET['searchword'];
	$allleads=$userObj->getSearchResults($start,$limit,$serachword);
	}?>
    <script>
function gotoRequiredPage(pageId){

	window.location.replace("<?php print SITEURL ?>/Leads/"+pageId);
	}
</script>
<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>
 
    <script>
  var popup=jQuery.noConflict();
 </script>
  <script type="text/javascript" src="<?php print SITEURL?>/js/checkuncheckall.js"></script>
<script type="text/javascript">
popup(function() {
setTimeout(function() { $(".index_suc").fadeOut(1500); }, 5000)
setTimeout(function() { $(".index_err").fadeOut(1500); }, 5000)
});
</script>
<script>
function checkEmp(){
	
	if(document.getElementById("employeename").value=='')
  {
     alert("Please Select Employee");
	 document.leedlist.employeename.focus;
	 return false;
  }
	
	if( popup('input[name="leadsid[]"]:checked').length == 0 )
    {
        alert("You must check atleast one Leed to assign");
        return false;
    }

	}
</script>
    <div class="wrapper">
      
      


      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->

              <div class="box">
               <h4><span style="margin-left: 10px;"><img src="<?php print SITEURL?>/images/leeds_list _new.png"><b style="margin-left:10px;">LEADS LIST</b></span>
                         
                        <div  style="float:right;margin-right: 12px;">
                            
                <input type="button" id="submit" value="Add" class="btn btn-primary" style="width:100px;margin-top:-5px;" onclick="window.location.href='<?php print SITEURL; ?>/CustomerRegistration'">
                             
                              </div>
                                <?php 
                         if($_GET['err']!="")
                          {
						  	echo '<p class="index_suc">'.$_GET['err'].'</p>';
							//unset($_SESSION['err']);
						  
						  }
						  else if($_GET['ferr']!="")
						  {
							echo '<p class="index_err">'.$_GET['ferr'].'</p>';
							//unset($_SESSION['ferr']);
						  }
						  ?>
                         </h4>
                <div class="box-body">
                 <div class="innerdivtable">
                          
                           <div style="float:unset;">
                           <div style="width:100%;">
                           <div style="width:50%;float:left;">
                           <?php include("importorderentry.php");?>
                            </div>
                            <div style="width:280px; float:right;">
                            <form name="searchform" id="searchform" method="post">
                             <input type="text" name="searchlead" id="searchlead" placeholder="Search Lead"  style="height:35px; width:200px; margin-right:10px;"/>
                            <input type="submit" name="search" value="Search" class="btn btn-primary" />
                             </form>
                            </div>
                            <div style="width:100%; clear:both;"></div>
                            </div>
                <form name="leedlist" method="post" action="" onsubmit="return checkEmp()" >
                          <div style="margin-left:74%;padding-bottom: 20px;">
                            <select name="employeename" id="employeename"  style="height:35px; width:200px;margin-right: 4px; margin-top:10px;">
                           <option value="">--Select Employee--</option>
                           <?php foreach($allemployees as $all_employees)
						   {
						   ?>
                           <option value="<?php echo $all_employees->id?>" ><?php echo $all_employees->username?></option>
                           <?php } ?>
                           </select>
                          
                             <input type="submit" name="submit" value="Submit" class="btn btn-primary" />
                            </div>
                       
                  <table id="example111" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                      <th><input type="checkbox" name="check" id="check" value="" onclick="checkAlluncheckAll('leedlist', 'leadsid')"/><label for="check" onclick="test();">&nbsp;</label></th>
                        <th>Lead Name
                        <div class="sort" style="float:right;" >

					<a href="<?php echo SITEURL ?>/leedslist.php?ord=ASC&fld=firstname&page=<?php echo $_GET['page']?>" class="up" title="up"></a>

					<a href="<?php echo SITEURL ?>/leedslist.php?ord=DESC&fld=firstname&page=<?php echo $_GET['page']?>" class="down" title="down"></a>

						</div></th>
                        <th>Email
                        <div class="sort" style="float:right;" >

					<a href="<?php echo SITEURL ?>/leedslist.php?ord=ASC&fld=firstname&page=<?php echo $_GET['page']?>" class="up" title="up"></a>

					<a href="<?php echo SITEURL ?>/leedslist.php?ord=DESC&fld=firstname&page=<?php echo $_GET['page']?>" class="down" title="down"></a>

						</div></th>
                        <th>Phone Number
                        <div class="sort" style="float:right;" >

					<a href="<?php echo SITEURL ?>/leedslist.php?ord=ASC&fld=firstname&page=<?php echo $_GET['page']?>" class="up" title="up"></a>

					<a href="<?php echo SITEURL ?>/leedslist.php?ord=DESC&fld=firstname&page=<?php echo $_GET['page']?>" class="down" title="down"></a>

						</div></th>
                        <th>Company
                        <div class="sort" style="float:right;" >

					<a href="<?php echo SITEURL ?>/leedslist.php?ord=ASC&fld=firstname&page=<?php echo $_GET['page']?>" class="up" title="up"></a>

					<a href="<?php echo SITEURL ?>/leedslist.php?ord=DESC&fld=firstname&page=<?php echo $_GET['page']?>" class="down" title="down"></a>

						</div></th>
                        <th>Sheet Name
                        <div class="sort" style="float:right;" >

					<a href="<?php echo SITEURL ?>/leedslist.php?ord=ASC&fld=firstname&page=<?php echo $_GET['page']?>" class="up" title="up"></a>

					<a href="<?php echo SITEURL ?>/leedslist.php?ord=DESC&fld=firstname&page=<?php echo $_GET['page']?>" class="down" title="down"></a>

						</div></th>
                        <th>Delete</th>
                      </tr>
                    </thead>
                  <tbody>
                      <?php 
					   $ii=0;
						if(!empty($allleads))
						{
					  foreach($allleads as $all_leads){
						   $userDetails=$userObj->getUserDetails($all_leads->user_id);
						   if($ii%2==0)
					   {
						   $color="even";
					   }
						else
						{
							$color="odd";
						}
						  //print_r($all_leads);exit;?>
                          
                      <tr>
                      	<td align='left' width="5%">
                        <input type="checkbox" name="leadsid[]" value="<?php print $all_leads->id?>" id="leadsid" /></td>
                      <td style="width:20%;" onclick="window.location.href='<?php print SITEURL?>/leedslistview.php?id=<?php echo $all_leads->id; ?>&page=<?php echo $_GET['page'] ?>'"><?php echo "<p style='width:100%;word-wrap:break-word;'>". $all_leads->title." ".$all_leads->firstname." ".$all_leads->lastname; "</p>"?></td>
                       <td style="width:20%;" onclick="window.location.href='<?php print SITEURL?>/leedslistview.php?id=<?php echo $all_leads->id; ?>&page=<?php echo $_GET['page'] ?>'"><?php echo "<p style='width:100%;word-wrap:break-word;'>". $all_leads->email;"</p>"?></td>
                        <td  style="width:15%;" onclick="window.location.href='<?php print SITEURL?>/leedslistview.php?id=<?php echo $all_leads->id; ?>&page=<?php echo $_GET['page'] ?>'"><?php echo "<p style='width:100%;word-wrap:break-word;'>+44". substr($all_leads->phone_number,1);"</p>" ?></td>
                      	<td  style="width:20%;" onclick="window.location.href='<?php print SITEURL?>/leedslistview.php?id=<?php echo $all_leads->id; ?>&page=<?php echo $_GET['page'] ?>'"><?php echo "<p style='width:100%;word-wrap:break-word;'>". $all_leads->company;"</p>"?></td>
                      	<td style="width:15%;" onclick="window.location.href='<?php print SITEURL?>/leedslistview.php?id=<?php echo $all_leads->id; ?>&page=<?php echo $_GET['page'] ?>'"><?php echo "<p style='width:100%;word-wrap:break-word;'>". $all_leads->sheetname;"</p>"?></td>
                          
						<td align="center" ><a href="<?php print SITEURL?>/leedslist.php?id=<?php print $all_leads->id;?>&action=delete"><img src="<?php print SITEURL?>/images/delete1.png"/> </a> </td>
                      </tr>
                      
                    </tbody>
                   
                           <?php
					   $ii++;
					    }
						}
						else
						{
							?>
                            <tr>
                            	<td colspan="5"> No Leads</td>
                            </tr>
                            <?php 
						}
						?>
                       </tbody>
                        </table>
                          </form>
                        <?php
					echo '<div class="pagclass">';
					echo pagination($rec_count,$limit,$pagecount,$page,$start);
					echo '</div>'; 
					?>
                    </tfoot>
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
          </div>
          </div>
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
     
    </div><!-- ./wrapper -->

    <!-- jQuery 2.1.3 -->
  
  
    <!-- page script -->
    <script type="text/javascript">
      $(function () {
		  alert();
       $("#example1").dataTable();
       
      });
    </script>


<?php 
function pagination($no_of_rows,$limit,$pagecount,$page,$start)
{
	if($pagecount>1)
	{
		if($page!=1){
			$pre=$_GET['page']-1;
		?>
        <a class="pagf" href="?page=<?php echo $pre;?>">Previous</a>
        <?php
		}
		?>
        <select onchange="gotoRequiredPage(this.value)">
        <option value="">Select</option>
        
        
        <?php
		for($i=1;$i<=$pagecount;$i++)
		{
			$cls = $page==$i?'class = "activepage"':'class = "pagn"';
			
			?>
            <option value="<?php echo $i;?>" <?php if($_GET['page']==$i){ ?>  selected="selected" <?php }?>><?php echo $i;?></option>
            <?php
		}
		?>
        </select>
        <?php
		if($page<$i-1){
			$next=$_GET['page']+1;
			?>
             <a class="pagf" href="?page=<?php echo $next;?>">Next</a>
            <?php
			}
		//echo '<a class="pagl" href="?page='.($i-1).'">Last</a>';

	}
}

?>