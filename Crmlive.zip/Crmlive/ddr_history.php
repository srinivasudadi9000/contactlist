<?php 
include("includes/header.php");

include("includes/leftnav.php"); 
$ddr_id = $_GET['ddr_id'];
$getAllDDRRequests = $userObj->getdDDRDetails($ddr_id);
//var_dump($getAllDDRRequests);

$getDDRHistory = $userObj->getDDRHistory($ddr_id);
//var_dump($getDDRHistory);

?>
<?php /*?><script type="text/javascript" >
var click_count = 0;
function fn(ddr_id) {
	//alert(ddr_id)
	click_count = click_count+1;
	//alert(click_count)
    window.location = '<?php print SITEURL; ?>/ADD_DDR?data_drive_request_id='+ddr_id;
}
</script><?php */?>
<div class="wrapper">
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
	<!-- Content Header (Page header) -->
        <!-- Main content -->
        <section class="content">
        	<div class="row">
        		<div class="col-xs-12">
        		<!-- /.box -->
        			
        <div class="drivelist_right">
         <p class="flags_style">
                <a href="#" title="Red" class="anchor_style"><img src="<?php print SITEURL; ?>/images/red_03.png" alt=""></a>
                <a href="#" title="Yellow" class="anchor_style"><img src="<?php print SITEURL; ?>/images/yellow_08.png" alt=""></a>
                <a href="#" title="Green" class="anchor_style"><img src="<?php print SITEURL; ?>/images/green_06.png" alt=""></a>
                
            </p>
        	<h1>Data Drive List</h1>
           
            <div class="drivelisttable">
            	<table class="listtaable" id="table" cellpadding="0" cellspacing="0">
                	<tr>
                    	<th width="10%">Request Sent From</th>
                    	<th width="10%">Company Name</th>
                        <th width="10%">Dealers Name</th>
                        <th width="10%">Client Name</th>
                        <th width="10%">Phone Number</th>
                        <th width="10%">Modified User</th>
                        <th width="10%">Assigned User</th>
                        <th width="20%">Date and Time of Last Modified</th>
                    </tr>
                    
                    <?php foreach($getDDRHistory as $get_History) { ?>
                    <?php foreach($getAllDDRRequests as $get_allddrres) {?>
                    <?php $modified_user_id=$userObj->getUser_id($get_History->modified_user_id)?>
                    <?php $assigned_user_id=$userObj->getUser_id($get_History->assigned_user_id)?>
                    <?php $adduserid=$userObj->getUser_id($get_allddrres->added_user_id)?>
	                 <tr style="cursor:pointer;">
                     	<td width="12%" onclick="window.location.href = 'ddr_history_editpage.php?data_drive_request_id=<?php print $get_allddrres->data_drive_request_id;?>';"><?php echo $adduserid->firstname;?></td> 
                        <td width="12%" onclick="window.location.href = 'ddr_history_editpage.php?data_drive_request_id=<?php print $get_allddrres->data_drive_request_id;?>';"><?php echo $get_History->company_name;?></td>
                        <td width="12%" onclick="window.location.href = 'ddr_history_editpage.php?data_drive_request_id=<?php print $get_allddrres->data_drive_request_id;?>';"><?php echo $get_History->dealer_name;?></td>
                        <td width="12%" onclick="window.location.href = 'ddr_history_editpage.php?data_drive_request_id=<?php print $get_allddrres->data_drive_request_id;?>';"><?php echo $get_History->client_name;?></td>
                        <td width="12%" onclick="window.location.href = 'ddr_history_editpage.php?data_drive_request_id=<?php print $get_allddrres->data_drive_request_id;?>';"><?php echo $get_History->phone_number;?></td>
                        
                        <td width="12%" onclick="window.location.href = 'ddr_history_editpage.php?data_drive_request_id=<?php print $get_allddrres->data_drive_request_id;?>';"><?php echo $modified_user_id->firstname;?></td>
                        <td width="12%" onclick="window.location.href = 'ddr_history_editpage.php?data_drive_request_id=<?php print $get_allddrres->data_drive_request_id;?>';"><?php echo $assigned_user_id->firstname;?></td>
                        <td width="20%" onclick="window.location.href = 'ddr_history_editpage.php?data_drive_request_id=<?php print $get_allddrres->data_drive_request_id;?>';"><?php echo $get_History->date_added;?></td>
	                 </tr>
                    <?php } } ?><?php if($get_History==0 || $get_allddrres==0){?>
                    <tr><td> No data Found...!</td></tr>
                    <?php }?>
                </table>
            </div><!--drivelisttable-->
        </div><!--drivelist_right-->
        <div class="clear_fix"></div>
        
               
            </div>
           </div>
        </section><!-- /.content -->
    </div><!-- /.content-wrapper -->
</div>