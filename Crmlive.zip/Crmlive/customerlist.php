<?php include("includes/header.php");
include("includes/leftnav.php");

$userObj->checkloggedin();
if($_POST['editcomment']=="Update")
{
$customerObj->updateLeadComments($_POST);	
//print_r($_POST);

}
if($_POST['submit']=='Submit')
{
	//print_r($_POST); exit;
	
	if($_POST['status']==$_GET['status'])
	{
	//print "status"; exit;
	$customerObj->updateLeadQuestions($_POST);	
	}
	else
	{
	//print "No status"; exit;
	$customerObj->updateCustomerDetails($_POST);	
	}
}
/*  if($_GET['status']!='')
{
	//$allcustomerlist=$customerObj->getCustomerList($_GET['status']);
	//var_dump($allcustomerlist);
} */
if ($_POST['search']=='Search') {
//print_r($_POST); exit; 
//$allleads->getSearchResults($start,$limit,$serachword);
//header("location:".SITEURL."/CustomerList/".$_GET['status']."?searchword=".$_POST['searchlead']);
header("location:".SITEURL."/searchlist.php?status=".$_GET['status']."&searchword=".$_POST['searchlead']);
}	

if($_GET['searchword']!="")
{
//print $_GET['searchword']; exit;
//$serachword=$_GET['searchword'];
//$allleads=$userObj->getSearchResults($start,$limit,$serachword);
}
if($_POST['comment']=='Submit')
{
	//print_r($_POST); exit;
	$customerObj->insertcomments($_POST);	
}
/*if($_POST['comment']=='Change')
{
	//print_r($_POST); exit;
	$customerObj->insertcomments($_POST);	
}*/
if($_POST['submit']=="Update")
{
	//print_r($_POST); exit;
	$update=$userObj->updateLeadProfilebyUser($_POST);
}

if ($_POST['change_status_submit']=='Submit') {
//print_r($_POST); exit; 
$customerObj->statusAsignToEmployee($_POST);
}
?>

 <script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>
 
  <script type="text/javascript" src="<?php print SITEURL?>js/fancy/lib/jquery-1.10.1.min.js"></script>
     <script>
  var popup=jQuery.noConflict();
 </script>

     <script type="text/javascript" src="<?php print SITEURL?>/js/fancy/lib/jquery.mousewheel-3.0.6.pack.js"></script>

 <!-- Add fancyBox main JS and CSS files -->
    
 <script type="text/javascript" src="<?php print SITEURL?>/js/fancy/source/jquery.fancybox.js?v=2.1.5"></script>
 <link rel="stylesheet" type="text/css" href="<?php print SITEURL?>/js/fancy/source/jquery.fancybox.css?v=2.1.5" media="screen" />
<script>
 function deleteComment(id)
 {
   if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
	//alert(xmlhttp.status);
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
		//alert(xmlhttp.responseText);
		if(confirm("Are you sure you want to delete this?"))
{
		popup( "#comment"+id ).remove();
}
		//auto_refresh();
		//var as=JSON.parse(xmlhttp.responseText);
		//document.getElementById("testDiv4").innerHTML=xmlhttp.responseText;
		   // $("#list_disp li").removeClass( "active" )
		//$("#"+id).addClass( "active" )
	
	  
    }
  }
  xmlhttp.open("GET","<?php print SITEURL?>/deleteComment.php?id="+id,true);
  xmlhttp.send();
 }

 </script>
  
  <script type="text/javascript">
 popup(document).ready(function() {
 
   popup('.fancybox').fancybox();
   });
   </script>
   

<script type="text/javascript">
    popup(document).ready(function(){
        popup("#status").change(function(){
		popup(".drivebox").hide();
           popup( "select option:selected").each(function(){
                if($(this).attr("value")=="Drive"){ 
                    //$(".box").hide();
                    popup(".drivebox").show();
                }
                
            });
        }).change();
    });
</script>
<script>
 function getLeadDetails(id,status)
 {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
	//alert(xmlhttp.status);
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
        console.log("id :"+id);
		//alert(xmlhttp.responseText);
		//var as=JSON.parse(xmlhttp.responseText);
		document.getElementById("testDiv4").innerHTML=xmlhttp.responseText;
		var nextid = "<?php echo $_GET['nextid']?>";
		//alert(nextid);
		if(nextid) {
			 $("#list_disp li").removeClass( "active" );
			 $("#"+nextid).addClass( "active" );
		} else {
			 $("#list_disp li").removeClass( "active" );
			 
			 $("#"+id).addClass( "active" );
		}
		//$("#list_disp li").removeClass( "active" );
		//$("#"+id).addClass( "active" );
		$("#status"+id).remove();
		
	  
    }
  }
  xmlhttp.open("GET","<?php print SITEURL?>/getleaddata.php?cid="+id+"&status="+status,true);
  xmlhttp.send();
 }
 
 function getallonclickDetails(id,status)
 {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
	//alert(xmlhttp.status);
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
        console.log("id :"+id);
		//alert(xmlhttp.responseText);
		//var as=JSON.parse(xmlhttp.responseText);
		document.getElementById("testDiv4").innerHTML=xmlhttp.responseText;
		$("#list_disp li").removeClass( "active" );
		$("#"+id).addClass( "active" );
		$("#status"+id).remove();
		
	  
    }
  }
  xmlhttp.open("GET","<?php print SITEURL?>/getleaddata.php?cid="+id+"&status="+status,true);
  xmlhttp.send();
 }
 </script>
 <script type="text/javascript">
popup(function() {
setTimeout(function() { $(".index_suc").fadeOut(1500); }, 5000)
setTimeout(function() { $(".index_err").fadeOut(1500); }, 5000)
});
</script>
   
<?php 

//start of pagination logic

$per_page = 20;         // number of results to show per page
//$result = mysql_query("SELECT * FROM crm_customer_list");
//$total_results = mysql_num_rows($result);
//$result =$allcustomerlist;
//$total_results = count($result);
//$result = array();
//$result = $customerObj->getCountOfCustomerList($_GET['status']);
//$total_results = $result;
if($_GET['status'] == 'Cold_Lead')
{
	$total_results = $_SESSION['coldleadscount'];
} else if ($_GET['status'] == 'Teed') {
	$total_results = $_SESSION['teedleadscount'];
} else if ($_GET['status'] == 'Closed') {
	$total_results = $_SESSION['closedeadscount'];
} else if ($_GET['status'] == 'Open') {
	$total_results = $_SESSION['openleadscount'];
} /* else if ($_GET['status'] == 'Dead') {
	$total_results = $_SESSION['deadcount'];
}  else if ($_GET['status'] == 'Dud') {
	$total_results = $_SESSION['dudscount'];
}  else if ($_GET['status'] == 'Client') {
	$total_results = $_SESSION['clientcount'];
}  else if ($_GET['status'] == 'Drive') {
	$total_results = $_SESSION['drivecount'];
} else if ($_GET['status'] == 'Evening_Call') {
	$total_results = $_SESSION['evening_callcount'];
}  else if ($_GET['status'] == 'Pulled_Client') {
	$total_results = $_SESSION['pulled_clientcount'];
}   */else {
	$total_results = $customerObj->getCountOfCustomerList($_GET['status']);
}

$total_pages = ceil($total_results / $per_page);//total pages we going to have

//-------------if page is setcheck------------------//
if (isset($_GET['page'])) {
	$show_page = $_GET['page'];             //it will telles the current page
	if ($show_page > 0 && $show_page <= $total_pages) {
		$start = ($show_page - 1) * $per_page;
		$end = $start + $per_page;
	} else {
		// error - show first set of results
		$start = 0;
		$end = $per_page;
	}
} else {
	// if page isn't set, show first set of results
	$start = 0;
	$end = $per_page;
}
// display pagination
$page = intval($_GET['page']);

$tpages=$total_pages;
if ($page <= 0)
	$page = 1;
//end of pagination logic
if($_POST['status_search']=="Search")
{ 

$allcustomerlist=$customerObj->getSerachByCompanyList($_GET['status'], $start,$end);
}else{

$allcustomerlist=$customerObj->getCustomerList($_GET['status'], $start,$end);
}
?>
 <form name="customerdeatails" method="post" >

    <div class="wrapper">


      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper" style="padding-top: 0px">
       

        <!-- Main content -->
        <section class="content" style="padding-top: 0px">
        <?php 
        		if($total_results) {
        		include ('paginate.php');
        		?>
        		
        		<?php 
	             $reload = $_SERVER['PHP_SELF'] . "?status=".$_GET['status']."&tpages=" . $tpages;
        		//$reload = $_SERVER['REQUEST_URI'] . "?status=".$_GET['status']."&tpages=" . $tpages;
        		echo '<div class="pagination" style="margin-left:0px;padding-left:0px"><ul style="margin-left:0px;margin-top:0px;padding-left:0px">';
	              if ($total_pages > 1) {
	              	echo paginate($reload, $show_page, $total_pages);
	              }
	              echo "</ul></div>";
        	    }
        	    ?>
        	    
        	    
                <input id="status_searchlead" name="status_searchlead" placeholder="Search.." style="height:41px; width:250px; margin-right:5px; margin-top:8px;" type="text">
                <input class="btn btn-primary" name="status_search" value="Search" type="submit" style=" height:39px; margin-top:0px;margin-right:15px;" />
                
             
                            <select name="change_status" id="change_status"  style="height:40px; width:200px;margin-right: 4px; margin-top:12px;">
                           <option value="">--Select Status--</option>
                           <option value="Cold_Lead">Cold Lead</option>
                           <option value="Open">Open</option>
                           <option value="Teed">Teed</option>
                           <option value="Dud">Dud</option>
                           <option value="Dead">Dead</option>
                           <option value="Closed">Closed</option>
                           <option value="Drive">Drive</option>
                           <option value="Evening_Call">Evening Call</option>
                           <option value="Client">Client</option>
                           <option value="Pulled_Client">Pulled Client</option>
                           </select>
                          
                           <input type="submit" name="change_status_submit" value="Submit" class="btn btn-primary" style=" height:39px; margin-top:0px;" />
                        
              
        	    <select onchange="gotoCustmerPage(this.value)" style=" float:right;margin-right:20px; margin-top:30px; width:10%;">
        	     <option value="http://<?php echo $_SERVER['HTTP_HOST']?>/customerlist.php?status=Cold_Lead&tpages=876&page=1" <?php if($_GET['page']=='1'){ ?>  selected="selected" <?php }?>>1</option>
                  <option value="http://<?php echo $_SERVER['HTTP_HOST']?>/customerlist.php?status=Cold_Lead&tpages=876&page=2" <?php if($_GET['page']=='2'){ ?>  selected="selected" <?php }?>>2</option>
                  <option value="http://<?php echo $_SERVER['HTTP_HOST']?>/customerlist.php?status=Cold_Lead&tpages=876&page=3" <?php if($_GET['page']=='3'){ ?>  selected="selected" <?php }?>>3</option>
                  <option value="http://<?php echo $_SERVER['HTTP_HOST']?>/customerlist.php?status=Cold_Lead&tpages=876&page=4" <?php if($_GET['page']=='4'){ ?>  selected="selected" <?php }?>>4</option>
                  <option value="http://<?php echo $_SERVER['HTTP_HOST']?>/customerlist.php?status=Cold_Lead&tpages=876&page=5" <?php if($_GET['page']=='5'){ ?>  selected="selected" <?php }?>>5</option>
                  <option value="http://<?php echo $_SERVER['HTTP_HOST']?>/customerlist.php?status=Cold_Lead&tpages=876&page=6" <?php if($_GET['page']=='6'){ ?>  selected="selected" <?php }?>>6</option>
                  <option value="http://<?php echo $_SERVER['HTTP_HOST']?>/customerlist.php?status=Cold_Lead&tpages=876&page=7" <?php if($_GET['page']=='7'){ ?>  selected="selected" <?php }?>>7</option>
                  <option value="http://<?php echo $_SERVER['HTTP_HOST']?>/customerlist.php?status=Cold_Lead&tpages=876&page=8" <?php if($_GET['page']=='8'){ ?>  selected="selected" <?php }?>>8</option>
                  <option value="http://<?php echo $_SERVER['HTTP_HOST']?>/customerlist.php?status=Cold_Lead&tpages=876&page=9" <?php if($_GET['page']=='9'){ ?>  selected="selected" <?php }?>>9</option>
                  <option value="http://<?php echo $_SERVER['HTTP_HOST']?>/customerlist.php?status=Cold_Lead&tpages=876&page=10" <?php if($_GET['page']=='10'){ ?>  selected="selected" <?php }?>>10</option>
                  
                 </select>
        	     <link rel="stylesheet" type="text/css" href="<?php print SITEURL?>/css/pagination_style.css" />
        	     <?php 
             /*  echo 'start : '.$start;
              echo 'end : '.$end;
              echo 'total_results : '.$total_results; */
            /*   for ($i = $start; $i < $end; $i++) {
              	// make sure that PHP doesn't try to show results that don't exist
              	if ($i == $total_results) {
              		break;
              	} */
              	// echo out the contents of each row into a table
             /*  	echo "<tr " . $cls . ">";
              	echo '<td>' . mysql_result($result, $i, 'firstname') .' '. mysql_result($result, $i, 'lastname'). '</td>';
              	echo '<td>' . mysql_result($result, $i, 'address') . '</td>';
              	echo '<td>' . mysql_result($result, $i, 'status') . '</td>';
              	echo "</tr>";
              }
              echo "</table>"; */
              
              ?>
          <div class="row">
           <?php 
			   $status=$_GET['status'];
			   ?>
            <div class="col-md-3">
          		<?php 
          		/* $reload = $_SERVER['PHP_SELF'] . "?tpages=" . $tpages;
          		echo '<div class="pagination"><ul>';
          		if ($total_pages > 1) {
          			echo paginate($reload, $show_page, $total_pages);
          		}
          		echo "</ul></div>";
          		// display data in table
          		echo "<table class='table table-bordered'>";
          		echo "<thead><tr><th>Name</th>  <th>Address</th><th>Status</th></tr></thead>";
          		// loop through results of database query, displaying them in the table
          		for ($i = $start; $i < $end; $i++) {
          			// make sure that PHP doesn't try to show results that don't exist
          			if ($i == $total_results) {
          				break;
          			}
          		
          			// echo out the contents of each row into a table
          			echo "<tr " . $cls . ">";
          			echo '<td>' . mysql_result($result, $i, 'firstname') .' '. mysql_result($result, $i, 'lastname'). '</td>';
          			echo '<td>' . mysql_result($result, $i, 'address') . '</td>';
          			echo '<td>' . mysql_result($result, $i, 'status') . '</td>';
          			echo "</tr>";
          		}
          		// close table>
          		echo "</table>"; */
          		?>
              <div class="box box-solid">
                <div class="box-body no-padding">
               <ul class="nav_list" id="list_disp">


                          <div id="testDiv3">
                        <li><a href="#" class="coldlead_imgs"><i class="fa fa-cog" style="margin-right:6px;"></i><span><?php print strtoupper($_GET['status'])?></span></a>
						
						</li>
                      <?php // echo count($allcustomerlist);?>
                        <?php if($total_results)
						  {
						  $i=0;
							foreach($allcustomerlist as $all_customerlist)
							{
								$customer[$i] =	$all_customerlist->id;
								$i++;
							}  
				 		 ?>  
				 		 
                        <?php foreach($allcustomerlist as $all_customerlist)
						{
							$dbdate=strtotime($all_customerlist->drive_date);
                          	$todaydate =strtotime(date("d M Y"));
							$twodays=strtotime("-2 days",$dbdate);
							//$todaydate=strtotime($date);
							//echo $all_customerlist->id;
							
					?>  
                        <li id="<?php echo $all_customerlist->id?>" <?php if($customer[0]==$all_customerlist->id) {?> class="active"<?php }?>
                        
						<?php
						if($todaydate==$twodays)
						{
							echo 'style="background-color:yellow;';
						}
						else if($todaydate==$dbdate)
						{
							echo 'style="background-color:red;';
						}
						
					 ?>
                        >
                       <a href="#" onclick="getallonclickDetails(<?php echo $all_customerlist->id?>,'<?php echo  $status?>')">
                       <input type="checkbox" name="staus_leads_list[]" value="<?php echo $all_customerlist->id?>" />
                        <?php 
                        echo  $all_customerlist->title." ".$all_customerlist->firstname." ".$all_customerlist->lastname?>
						<div id="status<?php echo $all_customerlist->id ?>" style="float: right;margin:0px 2px 0px 0px;">
						<?php if($userObj->getactivestatus($all_customerlist->id)=="active") {?><img src='<?php echo SITEURL ?>/images/dot.png' width="10px" height="10px" />
						<?php }	?>
						</div>
						</a>
						
						</li>
                       <?php 
					   } 	// echo out the contents of each row into a table
				 		// }
 }
					   else 
					   {
						   echo "<li>No Records</li>";
						}
					   ?> 
			
                      </div> 
                      </ul>
                </div><!-- /.box-body -->
              </div><!-- /. box -->
              <!-- /.box -->
            </div><!-- /.col -->
            <div class="col-md-9">
            <div class="box box-primary">
                            
								<div>
                                 <?php 
                         if($_GET['err']!="")
                          {
						  	echo '<p class="index1_suc" >'.$_GET['err'].'</p>';
							//unset($_SESSION['err']);
						  
						  }
						  else if($_GET['ferr']!="")
						  {
							echo '<p class="index_err">'.$_GET['ferr'].'</p>';
							//unset($_SESSION['ferr']);
						  }
						  ?>
                            
              <div class="box-body">
                  <div class="mid_content"  id="mid_content">
					   <?php 
                         if($_GET['err']!="" )
                          {
						  	echo '<p style="margin-left:-10px;" class="index_suc">'.$_GET['err'].'</p>';
							//unset($_SESSION['err']);
						  
						  }
						  else if($_GET['ferr']!="")
						  {
							echo '<p class="index_err">'.$_GET['ferr'].'</p>';
							//unset($_SESSION['ferr']);
						  }
						  ?>
						 <!-- <a href="#">Next</a>
							<a href="#">Previous</a>	-->	
								
                    <div id="testDiv4" style="padding-left: 10px;" >
					
					
                      <?php if($_GET['status']!="" && $_GET['cid']!="" )
					{
					  $previous_id=$userObj->getPreviousRecord($_GET['cid'],$_GET['status']);
					  $next_id=$userObj->getNextRecord($_GET['cid'],$_GET['status']);
					if($_SESSION['role']=="sales")
					{
					if($previous_id=="")
					{
					echo "";
					}
					else
					{
					?>
					<a href="#" onclick="getLeadDetails(<?php echo $previous_id?>,'<?php echo  $_GET['status']?>')"><span style="margin-left:-10px;"><img src="<?php print SITEURL?>/images/next-back_06.png"/></span></a>
					
					<?php 
					}
					if($next_id=="")
					{
					echo "";
					}
					else
					{
					
					?>
			
					<a href="#" onclick="getLeadDetails(<?php echo $next_id?>,'<?php echo  $_GET['status']?>')"><span style="float:right;margin-right: 14px;"><img src="<?php print SITEURL?>/images/next-back_03.png"/></span></a>
					<?php
					}
					}
					$customerdetails=$customerObj->getCustomerData($_GET['cid']);
					$getcommentid = $customerObj->getComment($_GET['cid']);
					$customerAnswer=$customerObj->getCustomerAnswer($_GET['cid']); 			//to get customer Question answers
					
						//print_r($customerAnswer);
					//print_r($getcomments);

						?>
                        <div style="width:100%; clear:both;"></div>
					

                       <ul class="navinner_list" >
                       <li style="margin-left:-8px;margin-top:6px; font-weight:bold;">Last updated on <?php echo $customerdetails->createdon ?></li>
                            <li><a href="#"><img src="<?php print SITEURL?>/images/contact_imgs_31.png"> <?php echo $customerdetails->title." ".$customerdetails->firstname." ".$customerdetails->lastname; ?></a></li>
                            <li><a href="#"><img src="<?php print SITEURL?>/images/contact_imgs_36.png"> <?php echo $customerdetails->email; ?></a></li>
                            <li><img src="<?php print SITEURL?>/images/contact_imgs_43.png"> <span class="big_font">+44<?php echo substr($customerdetails->phone_number,1); ?></span></li>
                             <li><img src="<?php print SITEURL?>/images/phone_icon.png"> <span class="big_font">+44<?php echo substr($customerdetails->mobile_number,1); ?></span></li>
                              <li><img src="<?php print SITEURL?>/images/phone_icon.png"> <?php echo $customerdetails->company; ?></li>
                            <li><a href="#"><img src="<?php print SITEURL?>/images/address_icon.png"> <?php echo $customerdetails->address."</br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$customerdetails->town."</br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$customerdetails->postcode; ?></a></li>
                              
                       	<input type="hidden" name="hidden_id" value="<?php print $customerdetails->id?>"/>
                       	

                       </ul>
                        <div class="questions" >
					<ul class="innerques" style="padding:0px; margin:0px;">
                    <input type="hidden" name="action" value="<?php echo $customerAnswer->customer_id?>" />
                        <li><span>Interested in reco:&nbsp;&nbsp;&nbsp;</span><textarea cols="30" rows="2" class="form-control" name="q1_reco"><?php echo $customerAnswer->q1_reco;?></textarea></li>
                  <li><span>Occupation? Retired?:&nbsp;&nbsp;&nbsp;</span>
                  <textarea cols="30" rows="2" class="form-control" name="q2_retired"><?php echo $customerAnswer->q2_retired;?></textarea></li>
                        <li><span>Portfolio?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q19_portfolio"><?php echo $customerAnswer->q19_portfolio;?></textarea></li>
                   <li><span>Do they have a broker?:&nbsp;&nbsp;&nbsp;</span>
                   <textarea cols="30" rows="2" class="form-control" name="q3_broker"><?php echo $customerAnswer->q3_broker;?></textarea></li>
                        <li><span>Tell them about AtoZ service:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="form-control" name="q4_service"><?php echo $customerAnswer->q4_service;?></textarea></li>
                        <li><span>Level of investment?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="form-control" name="q5_investment"><?php echo $customerAnswer->q5_investment;?></textarea></li>
                        <li><span>Interested in Growth,Income?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="form-control" name="q6_income"><?php echo $customerAnswer->q6_income;?></textarea></li>
                        <li><span>Can they make a decision?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="form-control" name="q7_decision"><?php echo $customerAnswer->q7_decision;?></textarea></li>
                        <li><span>Mobile?E-mail?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="form-control" name="q8_email"><?php echo $customerAnswer->q8_email;?></textarea></li>
                        <li><span>Best time to call?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="form-control" name="q9_call"><?php echo $customerAnswer->q9_call;?></textarea> </li>
                        <li><span>Mentioned commodities?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="form-control" name="q10_commodities"><?php echo $customerAnswer->q10_commodities;?></textarea></li>
                        <li><span>Tell them we make people Money?Again and again:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="form-control" name="q11_money"><?php echo $customerAnswer->q11_money;?></textarea></li>
                        <li><span>What sectors do they like?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="form-control" name="q12_sectors"><?php echo $customerAnswer->q12_sectors;?></textarea></li>
                        <li><span>Give Company Details?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="form-control" name="q13_company"><?php echo $customerAnswer->q13_company;?></textarea></li>
                        <li><span>I.D:&nbsp;&nbsp;&nbsp;</span><textarea cols="30" rows="2" class="textarea" name="q14_id"><?php echo $customerAnswer->q14_id;?></textarea></li>
                        <li><span>Hobbies?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="form-control" name="q15_hobbies"><?php echo $customerAnswer->q15_hobbies;?></textarea></li>
                        <li><span>Family?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="form-control" name="q16_family"><?php echo $customerAnswer->q16_family;?></textarea></li>
                        <li><span>Do they have internet?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="form-control" name="q17_internet"><?php echo $customerAnswer->q17_internet;?></textarea></li>
                        <li><span>Are they an active investor?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="form-control" name="q18_investor"><?php echo $customerAnswer->q18_investor;?></textarea></li>
                    
					  
                       
                        <!--comment_wrapper-->                       
					  <li><span>Status</span>    
                     <select name="status" id="status" class="form-control" style="width: 230px;float:right;height:30px;">
                    <option value="" >--Select--</option>
                    <option value="Cold_Lead" <?php if($customerdetails->status=="Cold_Lead") { ?>selected="selected"<?php } ?>>Cold Lead</option>
                    <option value="Open" <?php if($customerdetails->status=="Open") { ?>selected="selected"<?php } ?>>Open</option>
                    <option value="Dud" <?php if($customerdetails->status=="Dud") { ?>selected="selected"<?php } ?>>Dud</option>
                     <option value="Teed" <?php if($customerdetails->status=="Teed") { ?>selected="selected"<?php } ?>>Teed</option>
                    <option value="Dead" <?php if($customerdetails->status=="Dead") { ?>selected="selected"<?php } ?>>Dead</option>
                    <option value="Closed" <?php if($customerdetails->status=="Closed") { ?>selected="selected"<?php } ?>>Closed</option>
                    <option value="Drive" <?php if($customerdetails->status=="Drive") { ?>selected="selected"<?php } ?>>Drive</option>
                    <option value="Evening_Call" <?php if($customerdetails->status=="Evening_Call") { ?>selected="selected"<?php } ?>>Evening Call</option>
                     <option value="Client" <?php if($customerdetails->status=="Client") { ?>selected="selected"<?php } ?>>Client</option>
                     <option value="Pulled_Client" <?php if($customerdetails->status=="Pulled_Client") { ?>selected="selected"<?php } ?>>Pulled_Client</option>
					</select></li>
                        <li><span>Are they an active investor?:&nbsp;&nbsp;&nbsp;</span>
                        <input type="submit" name="submit" value="Submit" class="btn btn-primary"  /> </li>
                    </ul>
                    
                     <div class="drivebox" ><input type="text" name="drive_date" placeholder="Drive Date" class="text_large required"  id="onboarddate2" value="<?php print $customerdetails->drive_date; ?>"></div>                   
                    <div class="clear_fix"></div>
                    <div class="reg_btn" > 
                      <input type="submit" name="submit" value="Submit" class="btn btn-primary"  />              
                    </div> 
                    </div>
                       <div  class="comment_wrapper" >
                         <h3 style="color:1fb5ac;">Messages <strong>: </strong></h3>
                    
                    <div style="border:1px solid #cdcfcf;height:200px;margin-top:20px;overflow:auto;font-size:12px;/*width:470px;*/">
                     <div class="messagesdate" style="border:1px solid #cdcfcf;height:30px;border-top:none;border-left:none;border-right:none;">
                    <p class="sender">Sender</P>
                    <P class="bmessage">Messages</P>
                    <p class="datetime">Date|Time</p>
                     <p class="edit">Actions</p>
				
					<div style="clear:both;"></div>
					</div>
                  
                    <?php 
                    
                    //print_r($getcomments);
                    foreach($getcomments as $getcomment){ ?>
					<div id="comment<?php echo $getcomment->id?>">
                    <p style="float:left;width:20%;margin-left:5px;"><?php echo $getcomment->name;?></P>
                    <P style="float:left;width:28%;"><?php echo wordwrap($getcomment->comments,18,"<br>\n",TRUE);?>
                    <p style="float:left;width:30%;"><?php echo $getcomment->inserted_on;?></p>
                    
                    <p style="float:left;"><a href="<?php print SITEURL?>/editcomment.php?commentid=<?php echo $getcomment->id;?>" class='fancybox fancybox.ajax'><img src="<?php echo SITEURL;?>/images/edit_03.png" /></a>/<a href="#" onclick="deleteComment(<?php echo $getcomment->id;?>)" ><img src="<?php echo SITEURL;?>/images/delete1.png" /></a> </p>
                    <div style="clear:both;"></div>
                   
					 </div> 
					<?php } ?>
                   
                    </div>
                    </div>
                     <div class="comment_wrapper">
                     <h3>Comments</h3>       
                      <textarea name="comments" style="height:80px;"><?php //echo $customerdetails->comments?></textarea>
                    </div>
                      
                        <div  style="margin-top:20px;">
                          <input type="hidden" name="hidden_name" value="<?php echo $_SESSION['name']; ?>" />
                      <input type="submit" name="comment" value="Submit" class="btn btn-primary" />              
                    </div>
             
            </form>
            <?php } 
			else if($_GET['status']!="" && $_GET['cid']=="")
			{
				 if(!empty($allcustomerlist))
				 {
				$customerdetails=$customerObj->getCustomerData($customer[0]);
				$getcomments = $customerObj->getComment($customer[0]);
				$customerAnswer=$customerObj->getCustomerAnswer($customer[0]); 		
				//print_r($customerAnswer);
				 $previous_id=$userObj->getPreviousRecord($customer[0],$_GET['status']);
					  $next_id=$userObj->getNextRecord($customer[0],$_GET['status']);
					?>
					<!-- <div class="editprofile" >
					 <span style="float:right;"><a href="<?php print SITEURL?>/testing.php?id=<?php echo $customer[0];?>" class='fancybox fancybox.ajax'>Edit Lead</a></span>
                     </div> -->
					 
					<?php 
					if($_SESSION['role']=="sales")
					{
					if($previous_id=="")
					{
					echo "";
					}
					else
					{
					?>
					
					<div class="previousrecord"><a href="#" onclick="getLeadDetails(<?php echo $previous_id?>,'<?php echo  $_GET['status']?>')"><span style="margin-left:-10px;"><img src="<?php print SITEURL?>/images/next-back_06.png"/></span></a></div>
					
					<?php }
					
					if($next_id=="")
					{
					echo "";
					}
					else
					{
					?>
					
					
					<div class="nextrecord" ><a href="javascript:void(0)" onclick="getLeadDetails(<?php echo $next_id?>,'<?php echo  $_GET['status']?>')"><span style="float:right;margin-right: 14px;"><img src="<?php print SITEURL?>/images/next-back_03.png"/></span></a></div>
					<?php }
					}?>
                    <div style="width:100%; clear:both;"></div>
				<form name="customerdeatails" method="post" >
				

                       <ul class="navinner_list">
                        <li style="margin-left:-8px;margin-top:6px; font-weight:bold;">Last updated on <?php echo $customerdetails->createdon ?></li>
                        <div class="editprofile" style="position:relative; bottom:24px;">
					 <span style="float:right; margin-right: 22px;"><a href="<?php print SITEURL?>/testing.php?id=<?php echo $customer[0];?>" class='fancybox fancybox.ajax'>Edit Lead</a></span>
                     </div>
                            <li><a href="#"><img src="<?php print SITEURL?>/images/contact_imgs_31.png"> <?php echo $customerdetails->title." ".$customerdetails->firstname." ".$customerdetails->lastname; ?></a></li>
                            <li><a href="#"><img src="<?php print SITEURL?>/images/contact_imgs_36.png"> <?php echo $customerdetails->email; ?></a></li>
                            <li><img src="<?php print SITEURL?>/images/contact_imgs_43.png"> <span class="big_font">+44<?php echo substr($customerdetails->phone_number,1); ?></span></li>
                              <li><img src="<?php print SITEURL?>/images/phone_icon.png"> <span class="big_font">+44<?php echo substr($customerdetails->mobile_number,1); ?></span></li>
                                <li><img src="<?php print SITEURL?>/images/phone_icon.png"> <?php echo $customerdetails->company; ?></li>
                            <li><a href="#"><img src="<?php print SITEURL?>/images/address_icon.png"> <?php echo $customerdetails->address."</br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$customerdetails->town."</br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$customerdetails->postcode; ?></a></li>
                       	<input type="hidden" name="hidden_id" value="<?php print $customerdetails->id?>"/>

                       </ul>
					  <div class="questions">
					<ul class="innerques" style="padding:0px;">

                    <input type="hidden" name="action" value="<?php echo $customerAnswer->customer_id?>" />
                        <li><span>Interested in reco:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q1_reco"><?php echo $customerAnswer->q1_reco;?>
                        </textarea></li>
                  <li><span>Occupation? Retired?:&nbsp;&nbsp;&nbsp;</span>
                  <textarea cols="30" rows="2" class="textarea" name="q2_retired"><?php echo $customerAnswer->q2_retired;?>
                   </textarea></li>
                        <li><span>Portfolio?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q19_portfolio"><?php echo $customerAnswer->q19_portfolio;?></textarea></li>
                   <li><span>Do they have a broker?:&nbsp;&nbsp;&nbsp;</span>
                   <textarea cols="30" rows="2" class="textarea" name="q3_broker"><?php echo $customerAnswer->q3_broker;?></textarea></li>
                        <li><span>Tell them about AtoZ service:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q4_service"><?php echo $customerAnswer->q4_service;?></textarea></li>
                        <li><span>Level of investment?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q5_investment"><?php echo $customerAnswer->q5_investment;?></textarea></li>
                        <li><span>Interested in Growth,Income?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q6_income"><?php echo $customerAnswer->q6_income;?></textarea></li>
                        <li><span>Can they make a decision?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q7_decision"><?php echo $customerAnswer->q7_decision;?></textarea></li>
                        <li><span>Mobile?E-mail?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q8_email"><?php echo $customerAnswer->q8_email;?></textarea></li>
                        <li><span>Best time to call?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q9_call"><?php echo $customerAnswer->q9_call;?></textarea> </li>
                        <li><span>Mentioned commodities?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q10_commodities"><?php echo $customerAnswer->q10_commodities;?></textarea></li>
                        <li><span>Tell them we make people Money?Again and again:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q11_money"><?php echo $customerAnswer->q11_money;?></textarea></li>
                        <li><span>What sectors do they like?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q12_sectors"><?php echo $customerAnswer->q12_sectors;?></textarea></li>
                        <li><span>Give Company Details?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q13_company"><?php echo $customerAnswer->q13_company;?></textarea></li>
                        <li><span>I.D:&nbsp;&nbsp;&nbsp;</span><textarea cols="30" rows="2" class="textarea" name="q14_id"><?php echo $customerAnswer->q14_id;?></textarea></li>
                        <li><span>Hobbies?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q15_hobbies"><?php echo $customerAnswer->q15_hobbies;?></textarea></li>
                        <li><span>Family?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q16_family"><?php echo $customerAnswer->q16_family;?></textarea></li>
                        <li><span>Do they have internet ?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q17_internet"><?php echo $customerAnswer->q17_internet;?></textarea></li>
                        <li><span>Are they an active investor?:&nbsp;&nbsp;&nbsp;</span>
                        <textarea cols="30" rows="2" class="textarea" name="q18_investor"><?php echo $customerAnswer->q18_investor;?></textarea></li>
                    <li><span>Status</span>    
                     <select name="status" id="status" style="width: 230px;float:right;height:30px;">
                    <option value="" >--Select--</option>
                    <option value="Cold_Lead" <?php if($customerdetails->status=="Cold_Lead") { ?>selected="selected"<?php } ?>>Cold Lead</option>
                    <option value="Open" <?php if($customerdetails->status=="Open") { ?>selected="selected"<?php } ?>>Open</option>
                    <option value="Teed" <?php if($customerdetails->status=="Teed") { ?>selected="selected"<?php } ?>>Teed</option>
                    <option value="Dud" <?php if($customerdetails->status=="Dud") { ?>selected="selected"<?php } ?>>Dud</option>
                    <option value="Dead" <?php if($customerdetails->status=="Dead") { ?>selected="selected"<?php } ?>>Dead</option>
                    <option value="Closed" <?php if($customerdetails->status=="Closed") { ?>selected="selected"<?php } ?>>Closed</option>
                     <option value="Drive" <?php if($customerdetails->status=="Drive") { ?>selected="selected"<?php } ?>>Drive</option>
                    <option value="Evening_Call" <?php if($customerdetails->status=="Evening_Call") { ?>selected="selected"<?php } ?>>Evening Call</option>
                     <option value="Client" <?php if($customerdetails->status=="Client") { ?>selected="selected"<?php } ?>>Client</option>
					 <option value="Pulled_Client" <?php if($customerdetails->status=="Pulled_Client") { ?>selected="selected"<?php } ?>>Pulled_Client</option>
					</select></li>
                    <div class="drivebox" ><input type="text" name="drive_date" placeholder="Drive Date" class="text_large required"  id="cutoffdate1" value="<?php print $customerdetails->drive_date; ?>"></div>
                    <li><input type="hidden" name="hidden_id" value="<?php print $customerdetails->id?>"/>
                      <input type="submit" name="submit" value="Submit" class="btn btn-primary" /></li>
                    </ul></div>
                    <!--<div class="drivebox" ><input type="text" name="drive_date" placeholder="Drive Date" class="text_large required"  id="cutoffdate1" value="<?php print $customerdetails->drive_date; ?>"></div>-->
                    <!--<div class="reg_btn">
                      	<input type="hidden" name="hidden_id" value="<?php print $customerdetails->id?>"/>
                      <input type="submit" name="submit" value="Submit" class="btn btn-primary" />              
                    </div>-->
                    
                    <div class="comment_wrapper">
                    <h3>Messages </h3>
                    
                    <div style="border:1px solid #cdcfcf;height:200px;margin-top:20px;overflow:auto;/*width:470px;*/font-size:12px;">
                
                     <div class="messagesdate" style="border:1px solid #cdcfcf;height:30px;border-top:none;border-left:none;border-right:none;">
                    <p class="sender">Sender</P>
                    <P class="bmessage">Messages</P>
                    <p class="datetime">Date|Time</p>
                     <p class="edit">Actions</p>
				
				<div style="clear:both;"></div>	
					</div>
                    <?php foreach($getcomments as $getcomment){ ?>
					<div id="comment<?php echo $getcomment->id?>">
                    <p style="float:left;width:20%;margin-left:5px;"><?php echo $getcomment->name;?></P>
                    <P style="float:left;width:28%;"><?php echo wordwrap($getcomment->comments,18,"<br>\n",TRUE);?></P>
                    <p style="float:left;width:30%;"><?php echo $getcomment->inserted_on;?></p>
                    <p style="float:left;"><a href="<?php print SITEURL?>/editcomment.php?commentid=<?php echo $getcomment->id;?>" class='fancybox fancybox.ajax'><img src="<?php echo SITEURL;?>/images/edit_03.png" /></a>/<a href="#" onclick="deleteComment(<?php echo $getcomment->id;?>)" ><img src="<?php echo SITEURL;?>/images/delete1.png" /></a> </p>
                      <div style="clear:both;"></div>
					 </div> 
					<?php } ?>
                    </div>
                      </div>
                        <div class="comment_wrapper">
                     <h3>Comments</h3>       
                      <textarea name="comments" style="height:80px;width:435px;"><?php echo $customerdetails->comments;?></textarea>
                    </div>
                      <div  style="margin-top:20px;">
                      <input type="hidden" name="hidden_name" value="<?php echo $_SESSION['name']; ?>" />
                      <input type="submit" name="comment" value="Submit" class="btn btn-primary" />              
                    </div>
                    
                
         
  
                <?php 
			} }
			?>
                  </div>
                   </div>
                  
                </div><!-- /. box -->
            </div><!-- /.col -->
                 
            </div>
          </div><!-- /.row -->
         <?php include('includes/rightnav.php'); ?>
          </div>
          
        
        </section><!-- /.content -->
        
        
      </div><!-- /.content-wrapper -->
</form>
        
     <?php include('includes/footer.php');?>
     
      <script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>        
            <link href="<?php print SITEURL?>/libs/prettify/prettify.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="<?php print SITEURL?>/libs/prettify/prettify.js"></script>
<script type="text/javascript" src="<?php print SITEURL?>/js/jquery.slimscroll.js"></script>
	 <?php 
 if($_GET['nextid']!="")
{
 ?>

<script type="text/javascript">
jQuery.noConflict()(function ($) {

       $('#testDiv3').slimScroll({
      
          color: '#3c8dbc',
		  wheelStep : 1,
		  start: $('#<?php echo $_GET['nextid']?>'),		
		  height:846
      });
	    $('#testDiv4').slimScroll({
          color: '#3c8dbc',
		  wheelStep : 1,
		  height:846
      });
	  
	

    });
	
</script>
<?php }
else
{
	
?>
<script type="text/javascript">

jQuery.noConflict()(function ($) {

     
      $('#testDiv3').slimScroll({
          color: '#3c8dbc',
		  wheelStep : 1,	
		  height:846
      });
	    $('#testDiv4').slimScroll({
          color: '#3c8dbc',
		  wheelStep : 1,
		  height:846
      });
	  
	

    });
	
</script>
<?php }?>
<script>
function gotoCustmerPage(pageId){
	//alert(pageId);
	
		window.location.replace(pageId);
	
	}
</script>
<script>
$( document ).ready(function() {
//alert("welcome");
getLeadDetails(<?php echo $_GET['nextid']?>,'Evening_Call');
 //$('#<?php //echo $_GET['nextid']?>').get(0).scrollIntoView();
 
  //$('#testDiv3').scrollTo('#<?php //echo $_GET['nextid']?>');
 
});
</script>