<?php
class employeeClass
{
	function deleteEmployeePaidRecord($id,$empId){
		
		global $callConfig;
	
		$res=$callConfig->deleteRecord(TPREFIX.TBL_USER_PAID,'id',$empId);
		// print_r($res); exit;
 	
	if($res==1)
			{
		  
				//$_SESSION['err']="Delete Successfully";
				$callConfig->headerRedirect(SITEURL."/PaidBusiness/$id?err=Delete Successfully");
				
			}
			else
			{
			    //$_SESSION['ferr']="Deletion Failed";
				$callConfig->headerRedirect(SITEURL."/PaidBusiness/$id?ferr=Deletion Failed");
				
			}
	
	
		}
	function getPaidBusinessList($id){
		global $callConfig;
		$whr="employee_id=$id";
		$query	= $callConfig->selectQuery(TPREFIX.TBL_USER_PAID,'*',$whr,'','',''); 
		return  $callConfig->getAllRows($query);
		}
	function getEmployeeData($id){
		global $callConfig;
		$whr="id=".$id;
		$query	= $callConfig->selectQuery(TPREFIX.TBL_USER_LOGIN,'*',$whr,'','',''); 
		return  $callConfig->getRow($query);
		}
	function getAllEmployeesList()
	{
		global $callConfig;
		$whr="role='sales'";
		$query	= $callConfig->selectQuery(TPREFIX.TBL_USER_LOGIN,'*',$whr,'','',''); 
		return  $callConfig->getAllRows($query);
	}
	function getEmployeeWrittenPayment($id)
	{
		global $callConfig;
		$whr='employee_id='.$id;
		$query="select SUM(written) as written from crm_user_paid where employee_id=".$id;
		//$query	= $callConfig->selectQuery(TPREFIX.TBL_USER_PAID,'*',$whr,'','',''); 
		//echo $query; die; 
		$row=$callConfig->getRow($query);
 		return  $row->written;;
	}
	function getEmployeeClearedPayment($id)
	{
		global $callConfig;
		$whr='employee_id='.$id;
		$query="select SUM(cleared) as cleared from crm_user_paid where employee_id=".$id;
		//$query	= $callConfig->selectQuery(TPREFIX.TBL_USER_PAID,'*',$whr,'','',''); 
		$row=$callConfig->getRow($query); 
		return  $row->cleared;
	}
	function getFullYearPayment($id,$year)
	{
		//echo $id;
		//echo $year; exit;
		global $callConfig;
		$whr='employee_id='.$id;
		$querymonth1="select written,cleared from crm_user_paid where employee_id=".$id." and month='1' and year=".$year;
		$querymonth2="select written,cleared from crm_user_paid where employee_id=".$id." and month='2' and year=".$year;
		$querymonth3="select written,cleared from crm_user_paid where employee_id=".$id." and month='3' and year=".$year;
		$querymonth4="select written,cleared from crm_user_paid where employee_id=".$id." and month='4' and year=".$year;
		$querymonth5="select written,cleared from crm_user_paid where employee_id=".$id." and month='5' and year=".$year;
		$querymonth6="select written,cleared from crm_user_paid where employee_id=".$id." and month='6' and year=".$year;
		$querymonth7="select written,cleared from crm_user_paid where employee_id=".$id." and month='7' and year=".$year;
		$querymonth8="select written,cleared from crm_user_paid where employee_id=".$id." and month='8' and year=".$year;
		$querymonth9="select written,cleared from crm_user_paid where employee_id=".$id." and month='9' and year=".$year;
		$querymonth10="select written,cleared from crm_user_paid where employee_id=".$id." and month='10' and year=".$year;
		$querymonth11="select written,cleared from crm_user_paid where employee_id=".$id." and month='11' and year=".$year;
		$querymonth12="select written,cleared from crm_user_paid where employee_id=".$id." and month='12' and year=".$year;
		//$query	= $callConfig->selectQuery(TPREFIX.TBL_USER_PAID,'*',$whr,'','',''); 
		
		$month1=$callConfig->getRow($querymonth1); 
		$month2=$callConfig->getRow($querymonth2); 
		$month3=$callConfig->getRow($querymonth3); 
		$month4=$callConfig->getRow($querymonth4); 
		$month5=$callConfig->getRow($querymonth5); 
		$month6=$callConfig->getRow($querymonth6); 
		$month7=$callConfig->getRow($querymonth7); 
		$month8=$callConfig->getRow($querymonth8); 
		$month9=$callConfig->getRow($querymonth9); 
		$month10=$callConfig->getRow($querymonth10); 
		$month11=$callConfig->getRow($querymonth11); 
		$month12=$callConfig->getRow($querymonth12); 
		
		$toatlwrittenyear=array($month1->written,$month2->written,$month3->written,$month4->written,$month5->written,$month6->written,$month7->written,$month8->written,$month9->written,$month10->written,$month11->written,$month12->written); 
		
		$toatlclearedyear=array($month1->cleared,$month2->cleared,$month3->cleared,$month4->cleared,$month5->cleared,$month6->cleared,$month7->cleared,$month8->cleared,$month9->cleared,$month10->cleared,$month11->cleared,$month12->cleared); 
		//print_r($toatlwrittenyear);
//		print_r($toatlclearedyear);exit;
	$result = array_merge($toatlwrittenyear, $toatlclearedyear);
	return $result;
//print_r($result);
		
	
	}
	function getPaidDetails($eid,$year)
	{
	global $callConfig;
	$writtenquery="select SUM(written) as written,SUM(cleared) as cleared from crm_user_paid where employee_id=".$eid." and year=".$year;
	//echo $writtenquery; exit; 
	$written=$callConfig->getRow($writtenquery);
	//print_r($written); exit;
	$percentage=($written->cleared/$written->written)*100;
	$result=array("written"=>$written->written."$","cleared"=>$written->cleared."$","percentage"=>$percentage."%");
	return $result; 
	}
	
}

?>