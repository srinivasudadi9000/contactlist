<?php 

class userClass
{
		function getAllPaidBusinessList(){

		

		
global $callConfig;

		$query="SELECT crm_user_login.username, crm_user_paid.employee_id, crm_user_paid.amount, crm_user_paid.month, crm_user_paid.year, crm_user_paid.written, crm_user_paid.cleared

FROM crm_user_paid, `crm_user_login`

WHERE crm_user_paid.employee_id = crm_user_login.id

";

//echo $query; exit;

		//$query1	= $callConfig->executeQuery($query); 

		

		return  $callConfig->getAllRows($query);
		}

	function registerPaid($post){

		global $callConfig;

		

		$employee_id = userClass::test_input($post["employee_id"]);

		$amount = userClass::test_input($post["amount"]);

		$month = userClass::test_input($post["month"]);

		$year = userClass::test_input($post["year"]);

		$written = userClass::test_input($post["written"]);

		$cleared = userClass::test_input($post["cleared"]);

		$fieldnames=array('employee_id'=>$employee_id,'amount'=>$amount,'month'=>$month,'year'=>$year,'written'=>$written,'cleared'=>$cleared);

		//print_r($fieldnames); die;

	$res=$callConfig->insertRecord(TPREFIX.TBL_USER_PAID,$fieldnames);



	if($res!=""){

	        //$_SESSION['err']="Amount Added successfully";

			$callConfig->headerRedirect(SITEURL."/PaidBusiness/$employee_id?err=Amount Added successfully");



	}else{

	    //$_SESSION['ferr']="Amount Adding fail Try again";

		$callConfig->headerRedirect(SITEURL."/PaidBusiness/$employee_id?ferr=Amount Adding fail Try again");

		}

		

		}

	function test_input($data) {

	   $data = trim($data);

	   $data = stripslashes($data);

	   $data = htmlspecialchars($data);

	   return $data;

	}

	function checkLogin($post)

	{ 

		//print_r($post);exit;

		global $callConfig;

		$pass= $post['password'];

		//echo $callConfig->passwordEncrypt($pass);exit;

		$whr="email='".$post['email']."' and password='".$callConfig->passwordEncrypt($pass)."' and status='Active'";

		$query	= $callConfig->selectQuery(TPREFIX.TBL_USER_LOGIN,'*',$whr,'','',''); 

		  //echo $query; exit;

		$row	= $callConfig->getRow($query);

		//print_r($row); die;

		if($row!="")

		{
			//if (!empty($_SERVER["HTTP_CLIENT_IP"]))
			//{
			//check for ip from share internet
			//$ip = $_SERVER["HTTP_CLIENT_IP"];
			//}
			//elseif (!empty($_SERVER["HTTP_X_FORWARDED_FOR"]))
			//{
			// Check for the Proxy User
			//$ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
			//}
			//else
			//{
			//$ip = $_SERVER["REMOTE_ADDR"];
			//}

			// This will print user's real IP Address
			// does't matter if user using proxy or not.
			//echo $ip;
	//$iplist=$this->getIpaddressList();

		//$iparray=explode(",",$iplist->iplist);
	//print_r($iparray); 
		//echo $ip; exit;
	//if(in_array($ip,$iparray))
			//{
 		$_SESSION['id']=$row->id;

			$_SESSION['role']=$row->role;

			$_SESSION['email']=$row->email;

			$_SESSION['name']=$row->firstname;

		

			$callConfig->headerRedirect("Dashboard");
			//}
			//else
			//{
			//$callConfig->headerRedirect(SITEURL."/Home?ferr=Invalid Access");	
			//}
			

	}

		else

		{

			

		sitesettingsClass::recentActivities('admin >> Login Failed  ','e');

				$callConfig->headerRedirect(SITEURL."/Home?ferr=Invalid login");

			

		}
 
	}

	function registerUser($post){

			global $callConfig;

		$email = userClass::test_input($post["email"]);

		$uname = userClass::test_input($post["uname"]);

		$pword = userClass::test_input($post["pwd"]);

		$fname = userClass::test_input($post["fname"]);

		$lname = userClass::test_input($post["lname"]);
		
		$dname = userClass::test_input($post["dname"]);

		$gender = userClass::test_input($post["gender"]);

		$address = userClass::test_input($post["addr"]);

		$cellnum = userClass::test_input($post["phone"]);

		$mobilenum = userClass::test_input($post["mobile_number"]);

		$password=$callConfig->passwordEncrypt($pword);

		

		$fieldnames=array('email'=>$email,'username'=>$uname,'firstname'=>$fname,'lastname'=>$lname,'disname'=>$dname,'gender'=>$gender,'address'=>$address,'phonenumber'=>$cellnum,'mobilenumber'=>$mobilenum,'password'=>$password,'role'=>'sales');

		//print_r($fieldnames); die;

	$res=$callConfig->insertRecord(TPREFIX.TBL_USER_LOGIN,$fieldnames);



	if($res!=""){

	    //    $_SESSION['err']="Adding New Employ  successfully";
		$to=$post["email"];

		$from='info@kylecrm.com';

		$subject='Credintials for Login';

		

		$headers  = 'From:  KYLE CRM  <info@kylecrm.com>' . "\r\n";	

		$headers .='Reply-To: '. $from . "\r\n" ;

		$headers .='X-Mailer: PHP/' . phpversion();

		$headers .= "MIME-Version: 1.0\r\n";

		$headers .= "Content-type: text/html; charset=iso-8859-1\r\n"; 

		$msg="<html>

<body style='font-family:'Conv_GOTHIC',Sans-Serif; font-size:12px; color:#000; '>

<table cellspacing='0' cellpadding='5'  align='center' width='100%' border='0' style='border:1px solid #CCCCCC; border-collapse:collapse; font-family:Verdana, Arial, Helvetica, sans-serif; font-size:11px;'>

		  <tr>

		 

			<td  colspan='2' align='left' valign='top' bgcolor='#32323a'><a href='".SITEURL."/'>

			<img src='".SITEURL."/images/login_logo_03.png' border='0' ></a></td>

		  </tr>

		  <tr>

			<td valign='top' colspan='2' align='left'><strong></strong> </td>

		  </tr>

		   <tr>

			<td valign='top' colspan='2' align='left'><strong>Login email-id: </strong> ".$post["email"]." </td>

		  </tr>

		  <tr>

			<td valign='top' colspan='2' align='left'><strong> Password:</strong> ".$password." </td>

		  </tr>

		  <tr>

			<td valign='top' colspan='2' align='left'>&nbsp;</td>

		  </tr>

		  <tr>

			<td valign='top' colspan='2' align='left'>Thank You,<br />

			  Support Team, Kyle-CRM</td>

		  </tr>

		  

		</table></body>

</html>";

		

		//echo $msg; exit;

		mail($to,$subject,$msg,$headers);

			$callConfig->headerRedirect(SITEURL."/EmployeeList?err=Adding New Employee  successfully");



	}else{

	  //  $_SESSION['ferr']="Adding New  Employ fail Try again";

		$callConfig->headerRedirect(SITEURL."/EmployeeList?ferr=Adding New  Employee fail Try again");

		}

		

		}

		

		

		function forgotPassword($post)

	{

		//print_r($post); die;

	global $callConfig;

	$whr='email="'.$post['email'].'" ';

	$query=$callConfig->selectQuery(TPREFIX.TBL_USER_LOGIN,'*',$whr,'','','');

	//echo $query; exit;

	$result=$callConfig->getRow($query);

	//print_r($result); die;

	if($result!="")

	{

	global $callConfig;

		$to=$result->email;

		$from='info@kylecrm.com';

		$subject='Forgot Password';

		

		$headers  = 'From:  KYLE CRM  <info@kylecrm.com>' . "\r\n";	

		$headers .='Reply-To: '. $from . "\r\n" ;

		$headers .='X-Mailer: PHP/' . phpversion();

		$headers .= "MIME-Version: 1.0\r\n";

		$headers .= "Content-type: text/html; charset=iso-8859-1\r\n"; 

		$msg="<html>

<body style='font-family:'Conv_GOTHIC',Sans-Serif; font-size:12px; color:#000; '>

<table cellspacing='0' cellpadding='5'  align='center' width='100%' border='0' style='border:1px solid #CCCCCC; border-collapse:collapse; font-family:Verdana, Arial, Helvetica, sans-serif; font-size:11px;'>

		  <tr>

		 

			<td  colspan='2' align='left' valign='top' bgcolor='#32323a'><a href='".SITEURL."/'>

			<img src='".SITEURL."/images/login_logo_03.png' border='0' ></a></td>

		  </tr>

		  <tr>

			<td valign='top' colspan='2' align='left'><strong></strong> </td>

		  </tr>

		   <tr>

			<td valign='top' colspan='2' align='left'><strong>Login email-id: </strong> ".$result->email." </td>

		  </tr>

		  <tr>

			<td valign='top' colspan='2' align='left'><strong> Password:</strong> ".$callConfig->passwordDecrypt($result->password)." </td>

		  </tr>

		  <tr>

			<td valign='top' colspan='2' align='left'>&nbsp;</td>

		  </tr>

		  <tr>

			<td valign='top' colspan='2' align='left'>Thank You,<br />

			  Support Team, Kyle-CRM</td>

		  </tr>

		  

		</table></body>

</html>";

		

		//echo $msg; exit;

		mail($to,$subject,$msg,$headers);

		$_SESSION['err']="Password Sent Successfully";

		$callConfig->headerRedirect("forgotpassword.php?err=Password Sent Successfully");

	}

	else

	{

		$_SESSION['ferr']="Record Not Found in Database";

		$callConfig->headerRedirect("forgotpassword.php?ferr=Record Not Found in Database");

		

	}

	

	}

	

	

	function updatePassword($email,$role)

	{

			global $callConfig;

			$whr='email="'.$email.'"';

			$query=$callConfig->selectQuery(TPREFIX.TBL_USER_LOGIN,'*',$whr,'','','');

			//echo $query; die;

			$result=$callConfig->getRow($query);

			$callConfig->headerRedirect(SITEURL."changepassword.php?url=".$result->key);

			

	}

	

	

	

	function updateMsg()

	{

		global $callConfig;

		$whr="id=".$_SESSION['id'];

		$query	= $callConfig->selectQuery(TPREFIX.TBL_USER_LOGIN,'*',$whr,'','','');

		        $q="UPDATE crm_user_login SET messageCount = 0 where id='".$_SESSION['id']."'";

				$callConfig->executeQuery($q);

		//	echo $query;exit;   

		$callConfig->headerRedirect(SITEURL."/SalesBoard");

		

	}

	

	function changePassword($post,$key)

	{

		global $callConfig;

			$fieldnames=array('`password`'=>$callConfig->passwordEncrypt($post['password']));	

			

	$res=$callConfig->updateRecord(TPREFIX.TBL_USER_LOGIN,$fieldnames,'`key`',$key);

	

		//echo $res; exit;

			if($res>0)

			{

			

			  

				$_SESSION['err']="Password Changed Successfully";

				$callConfig->headerRedirect(SITEURL."Home");

				

			}

			else

			{

			    sitesettingsClass::recentActivities('Upadted Infomartion Failed','e');

				$_SESSION['ferr']="Password Changed Failed";

				$callConfig->headerRedirect(SITEURL."Home");

				

			}

	}

	function checkloggedin()

	{

		global $callConfig;

		if($_SESSION['id']=="")

		{

		$callConfig->headerRedirect(SITEURL."/Home?ferr=Your session expired! Please Login");

		}

		

	}

	function getAllleedslist($start,$end,$sortfield,$order)

	{

		global $callConfig;
		
		//echo "Start : ".$start."End : ".$end;

		if($sortfield!="" && $order!="") 

		$order=$sortfield.' '.$order;

		$whr='user_id=0 and listname=""';

		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,$order,$start,$end);

		//echo "All Leads : ".$query;//exit;  

		return  $callConfig->getAllRows($query);

	}

	function getAllleedslistCount($listname)
	{
		
		global $callConfig;

		if($listname!="")
		{
		$whr='user_id=0 and listname="'.$listname.'"';

		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,'',$start,$end);
		//echo "If".$query;
		}
		else
		{
		$whr='user_id=0 and listname=""';

		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,'',$start,$end);
		//echo "Esle".$query;
		}
		//echo $query;  

		return  $callConfig->getCount($query);

	}

	function getAllemployeeslist($start,$end,$sortfield,$order)

	{

		global $callConfig;
		if($sortfield!="" && $order!="") 

		$order=$sortfield.' '.$order;

		$whr='role="sales"';

		$query	= $callConfig->selectQuery(TPREFIX.TBL_USER_LOGIN,'*',$whr,$order,$start,$end); 

		return  $callConfig->getAllRows($query);

	}

	function asignToEmployee($post)

	{

		global $callConfig;

		$fieldnames=array('`user_id`'=>$post['employeename'],'status'=>'Cold_Lead');

		//print_r($post['leadsid']);	

		//$res=" UPDATE crm_customer_list SET `user_id`=".$post['employeename']." WHERE id IN('4,8')";

		$leadsid=$post['leadsid'];

		$i=0;

		foreach($leadsid as $leads_id)

		{

		$fieldnames2=array('lead_id'=>$leads_id,'status'=>'active');

		$res[$i]=$callConfig->updateRecord(TPREFIX.TBL_CUSTOMER_LIST,$fieldnames,'id',$leads_id);

		//echo $res2[$i]=$callConfig->insertRecord(TPREFIX.TBL_ACTIVE_USERS,$fieldnames2);

		$i++;

		}
//exit;
			$_SESSION['err']="Updated Successfully";

		$callConfig->headerRedirect(SITEURL."/Leads/1?err=Updated Successfully");

	}

	function statusAsignToEmployee($post)

	{

		global $callConfig;

		$leadsid=$post['staus_leads_list'];

		$i=0;

		foreach($leadsid as $leads_id)

		{

		$fieldnames=array('status'=>$post['change_status']);

		$res[$i]=$callConfig->updateRecord(TPREFIX.TBL_CUSTOMER_LIST,$fieldnames,'id',$leads_id);

		//echo $res2[$i]=$callConfig->insertRecord(TPREFIX.TBL_ACTIVE_USERS,$fieldnames2);

		$i++;

		}
//exit;
			$_SESSION['err']="Updated Successfully";

		//$callConfig->headerRedirect(SITEURL."/Leads/1?err=Updated Successfully");
		$callConfig->headerRedirect(SITEURL."/CustomerList/".$_GET['status']."&err=updated successfully");

	}

	function getUserDetails($id)

	{

		global $callConfig;

		$whr='id='.$id;

		$query	= $callConfig->selectQuery(TPREFIX.TBL_USER_LOGIN,'*',$whr,'','',''); 

		return  $callConfig->getRow($query);

	}

	

	function getcalendar()

	{

		global $callConfig;

		//$whr='id='.$id;

		$query	= $callConfig->selectQuery(TPREFIX.TBL_JCAL,'*','','','',''); 

		//echo $jquery; exit;

		return  $callConfig->getAllRows($query);

	}

	function insertNotes($post)

	{

	

		global $callConfig;

		$fieldnames=array('description'=>$post['description'],'userid'=>$_SESSION['id'],'status'=>'Active');

		//print_r($fieldnames); die;

		$res=$callConfig->insertRecord(TPREFIX.TBL_NOTES,$fieldnames);

		//print_r($res); exit;

		if($res>0)

			{	//$_SESSION['err']="Message Send Successfully";

				//$q="UPDATE crm_user_login SET messageCount = messageCount + 1";

				//$callConfig->executeQuery($q);

				//$callConfig->headerRedirect(SITEURL."/notes?err=Notes Created Successfully");

				$callConfig->headerRedirect(SITEURL."/notes.php?err=Notes Created Successfully");

				

			}

			else

			{

			    //$_SESSION['ferr']="Message Send Failed";

				$callConfig->headerRedirect(SITEURL."/notes.php?ferr=Notes Creation Failed");

				

			}

				

		



	}

			function deleteleadMessage($id)

	{

	//echo $id exit;

	global $callConfig;



	$res=$callConfig->deleteRecord(TPREFIX.TBL_NOTES,'id',$id);

	if($res>0)

			{		  

				//$_SESSION['err']="Delete Successfully";

				$callConfig->headerRedirect(SITEURL."/notes.php?err=Delete Successfully");

				

			}

			else

			{

			    //$_SESSION['ferr']="Deletion Failed";

				$callConfig->headerRedirect(SITEURL."/notes.php?ferr=Deletion Failed");

				

		}

	

	}

	function insertBoard($post)

	{

		global $callConfig;

		$fieldnames=array('description'=>mysql_real_escape_string($post['description']),'createdon'=>date('d M Y'),'status'=>'Active');

		//print_r($fieldnames); die;

		$res=$callConfig->insertRecord(TPREFIX.TBL_BOARD,$fieldnames);

		//print_r($res); exit;

		if($res>0)

			{	//$_SESSION['err']="Message Send Successfully";

				$q="UPDATE crm_user_login SET messageCount = messageCount + 1";

				$callConfig->executeQuery($q);

				$callConfig->headerRedirect(SITEURL."/AdminBoard?err=Message Send Successfully");

				

			}

			else

			{

			    //$_SESSION['ferr']="Message Send Failed";

				$callConfig->headerRedirect(SITEURL."/AdminBoard?ferr=Message Send Failed");

				

			}

				

		



	}	

	function getBoardMessages()

	{

		global $callConfig;

		$whr='status="Active"';

		$order="id DESC";

		$query	= $callConfig->selectQuery(TPREFIX.TBL_BOARD,'*',$whr,$order,$start,$end);

		//echo $query;  

		return  $callConfig->getAllRows($query);

	}

	

	function getNotes()

	{

		global $callConfig;

		$whr="status='Active' and userid='".$_SESSION['id']."'";

		$order="id DESC";

		$query	= $callConfig->selectQuery(TPREFIX.TBL_NOTES,'*',$whr,$order,$start,$end);

		//echo $query;exit;  

		return  $callConfig->getAllRows($query);

	}

	



	function getOpenCount()

	{

		global $callConfig;

		$whr="YEAR(open_date)='2014'" ;

		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,'','','');

		//echo $query;  

		return  $callConfig->getCount($query);

	}

	

	

	

	function getTeedCount()

	{

		global $callConfig;

		$whr="and YEAR(teed_date)='2014'" ;

		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,'','','');

		//echo $query;  

		return  $callConfig->getCount($query);

	}

	

	function getcount()

	{

		global $callConfig;

		$whr="StartTime LIKE '%".date('Y-m-d')."%' and name_id='".$_SESSION['name']."'" ;

		$query	= $callConfig->selectQuery('jqcalendar','*',$whr,'','','');

		//echo $query;   exit;

		return  $callConfig->getCount($query);

	}

	

	function getadmincount()

	{

		global $callConfig;

		$whr="id=".$_SESSION['id'];

		$query	= $callConfig->selectQuery(TPREFIX.TBL_USER_LOGIN,'*',$whr,'','','');

		//	echo $query;exit;   

		return  $callConfig->getRow($query);

	}

	

	function getClosedCount()

	{

		global $callConfig;

		$whr="YEAR(closed_date)='2014'" ;

		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,'','','');

		//echo $query;  

		return  $callConfig->getCount($query);

	}

	function getOpenCountMonth($month)

	{

		global $callConfig;

		$whr="MONTH(open_date)='".$month."'" ;

		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,'','','');

		//echo $query;  

		return  $callConfig->getCount($query);

	}

	function getTeedCountMonth($month)

	{

		global $callConfig;

		$whr="MONTH(teed_date)='".$month."'" ;

		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,'','','');

		//echo $query;  

		return  $callConfig->getCount($query);

	}

	function getClosedCountMonth($month)

	{

		global $callConfig;

		$whr="MONTH(closed_date)='".$month."'" ;

		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,'','','');

		//echo $query;  

		return  $callConfig->getCount($query);

	}

	function getOpenCountThree($m1)

	{

		global $callConfig;

		$whr="MONTH(open_date)='".$m1."'" ;

		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,'','','');

		echo $query;  

		return  $callConfig->getCount($query);

	}

	function getTeedCountThree($m1)

	{

		global $callConfig;

		$whr="MONTH(teed_date)='".$m1."'" ;

		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,'','','');

		//echo $query;  

		return  $callConfig->getCount($query);

	}

	function getClosedCountThree($m1)

	{

		global $callConfig;

		$whr="MONTH(closed_date)='".$m1."'" ;

		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,'','','');

		//echo $query;  

		return  $callConfig->getCount($query);

	}

	function getOpenCountYear($year)

	{

		global $callConfig;

		$whr="YEAR(open_date)='".$year."'" ;

		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,'','','');

		//echo $query;  

		return  $callConfig->getCount($query);

	}

	function getTeedCountYear($year)

	{

		global $callConfig;

		$whr="YEAR(teed_date)='".$year."'" ;

		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,'','','');

		//echo $query;  

		return  $callConfig->getCount($query);

	}

	function getClosedCountYear($year)

	{

		global $callConfig;

		$whr="YEAR(closed_date)='".$year."'" ;

		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,'','','');

		//echo $query;  

		return  $callConfig->getCount($query);

	}

	function getOpenCountLastYear($year)

	{

		global $callConfig;

		$whr="YEAR(open_date)='".$year."'" ;

		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,'','','');

		//echo $query;  

		return  $callConfig->getCount($query);

	}

	function getTeedCountLastYear($year)

	{

		global $callConfig;

		$whr="status='Teed' and  YEAR(teed_date)='".$year."'" ;

		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,'','','');

		//echo $query;  

		return  $callConfig->getCount($query);

	}

	function getClosedCountLastYear($year)

	{

		global $callConfig;

		$whr="status='Closed' and  YEAR(closed_date)='".$year."'" ;

		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,'','','');

		//echo $query;  

		return  $callConfig->getCount($query);

	}

	function getleedview($id)

	{

		global $callConfig;

		$whr="id=".$id;

		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,'','','');

		//echo $query;  

		return  $callConfig->getRow($query);

	}

	function getemployeeview($id)

	{

		global $callConfig;

		$whr="id=".$id;

		$query	= $callConfig->selectQuery(TPREFIX.TBL_USER_LOGIN,'*',$whr,'','','');

		//echo $query;  

		return  $callConfig->getRow($query);

	}

	

	function eventDelete($id)



	{//echo "hi"; exit;



	global $callConfig;



	$res=$callConfig->deleteRecord('jqcalendar','Id',$id);



	

      return true;

		



	}

	function deleteLeed($id)

	{

	global $callConfig;



	$res=$callConfig->deleteRecord(TPREFIX.TBL_CUSTOMER_LIST,'id',$id);

	if($res>0)

			{		  

				//$_SESSION['err']="Delete Successfully";

				$callConfig->headerRedirect(SITEURL."/Leads/1?err=Delete Successfully");

				

			}

			else

			{

			    //$_SESSION['ferr']="Deletion Failed";

				$callConfig->headerRedirect(SITEURL."/Leads/1?ferr=Deletion Failed");

				

		}

	

	}

	function deleteEmployee($id)

	{

	global $callConfig;



	$res=$callConfig->deleteRecord(TPREFIX.TBL_USER_LOGIN,'id',$id);

	if($res>0)

			{

		  

				// $_SESSION['err']="Delete Successfully";

				$callConfig->headerRedirect(SITEURL."/EmployeeList?err=Delete Successfully");

				

			}

			else

			{

			    // $_SESSION['ferr']="Deletion Failed";

				$callConfig->headerRedirect(SITEURL."/EmployeeList?ferr=Deletion Failed");

				

		}

	

	}

	function getAllYearOpenData($year)

	{

		global $callConfig;

		for($i=1;$i<=12;$i++)

		{

		$whr="YEAR(open_date)='".$year."' and MONTH(open_date)='".$i."'" ;

		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,'','','');

		$open[$i]=  $callConfig->getCount($query);

		}

		return $open;

	}

	function getAllYearClosedData($year)

	{

		global $callConfig;

		for($i=1;$i<=12;$i++)

		{

		$whr="YEAR(closed_date)='".$year."' and MONTH(closed_date)='".$i."'" ;

		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,'','','');

		$closed[$i]=  $callConfig->getCount($query);

		}

		return $closed;

	}

	function getAllYearTeedData($year)

	{

		global $callConfig;

		for($i=1;$i<=12;$i++)

		{

		$whr="YEAR(teed_date)='".$year."' and MONTH(teed_date)='".$i."'" ;

		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,'','','');

		$teed[$i]=  $callConfig->getCount($query);

		}

		return  $teed;

	}

	function getEmployeeBasedRecords($eid,$date)

	{

		//print_r($post);

		global $callConfig;

		//$eid=$post['empid'];

		//$date=$post['date'];

	

		$whr="";

		if($eid!="")

		{

		$whr.="user_id=".$eid." and ";

		}

		if($date!="")

		{

			

			if($date=="Today")

			{

			$whr.="closed_date >= DATE_SUB(CURDATE(), INTERVAL 0 DAY) and ";

			}

			else if($date=="Yesterday")

			{

			$whr.="DATE(closed_date)= DATE_SUB(CURDATE(), INTERVAL 1 DAY) and ";

			}

			else if($date=="Remaining")

			{

			$whr.="Date( closed_date ) NOT IN (CURDATE( ) , DATE_SUB( CURDATE( ) , INTERVAL 1 DAY )) and ";

			}

		}

		$order="id DESC";

		$whr=substr($whr,0,(strLen($query)-4));

		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,$order,'','');

		//echo $query; exit; 

		return  $callConfig->getAllRows($query);

	}

	function getAllAssignleedslistCount($id)

	{

		global $callConfig;

		$whr='user_id='.$id;

		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,'','','');

		//echo $query;  

		return  $callConfig->getCount($query);

	}

	function getAllAssignleedslist($start,$end,$id,$sortfield,$order)

	{

		global $callConfig;
		if($sortfield!="" && $order!="") 

		$order=$sortfield.' '.$order;


		$whr='user_id='.$id;

		//$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,$order,$start,$end);
		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,$order,0,30);
		//echo $query;  exit;

		return  $callConfig->getAllRows($query);

	}

	 function getprofilelist($id)

	{

	global $callConfig;

	$whr="id='".$id."'";

    $query=$callConfig->selectQuery(TPREFIX.TBL_USER_LOGIN,'*',$whr,'','','') ; 

	//print_r($query);die; 

	return $callConfig->getRow($query);

	}

	function getprofile1list($id)

	{

	global $callConfig;

	$whr="id='".$id."'";

    $query=$callConfig->selectQuery(TPREFIX.TBL_USER_LOGIN,'*',$whr,'','','') ;  

	return $callConfig->getRow($query);

	}

	function UpdateuserProfile($post)

	{ //print_r($_POST); exit;

		global $callConfig;

		$_SESSION['err']='';

		$_SESSION['ferr']='';

		//print $post['hdn_image'];exit

		$fieldnames=array('firstname'=>$post['firstname'],'lastname'=>$post['lname'],'username'=>$post['uname'],'disname'=>$post['dname'],'email'=>$post['email'],

		'password'=>md5(md5($post['password'])),'phoneno'=>$post['phone'],'gender'=>$post['gender'],'address'=>$post['address'],

		);

		$res=$callConfig->updateRecord(TPREFIX.TBL_USER_LOGIN,$fieldnames,'id',$post['hdn_id']);

		if($res>0)

		{

			$_SESSION['message']='updatesucc';

			$callConfig->headerRedirect(SITEURL."/employeelistview.php?id=".$post['hdn_id']);					

			exit;

		}

		else

		{

			$_SESSION['errormessage']='updatefailed';

			$callConfig->headerRedirect(SITEURL."/employeelistview.php?id=".$post['hdn_id']);	

			exit;

		}

		

	}

	function getSearchResults($start,$limit,$searchword)

	{

	

		global $callConfig;
	
		$whr='user_id=0';

		if($searchword!="")

		{

		$whr.=" and MATCH (title, firstname, lastname) AGAINST ('%".$searchword."%'  IN BOOLEAN MODE) or (firstname like '%$searchword%' or lastname like '%$searchword%'  or company like '%$searchword%' or phone_number like '%$searchword%')";

		}

		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,'',$start,$limit);

		//echo "Serach : ".$query; //exit;  

		return  $callConfig->getAllRows($query);
		

	

	}
	
	function getAllSearchResultsCount($start,$limit,$searchword)

	{

	

		global $callConfig;
	
		$whr='user_id=0';

		if($searchword!="")

		{

		$whr.=" and MATCH (title, firstname, lastname) AGAINST ('%".$searchword."%'  IN BOOLEAN MODE) or (firstname like '%$searchword%' or lastname like '%$searchword%'  or company like '%$searchword%' or phone_number like '%$searchword%')";

		}

		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,'',$start,$end);

		//echo "Serach : ".$query; //exit;  

		return  $callConfig->getCount($query);
		

	

	}

	function getSearchResultsUsers($start,$limit,$searchword)

	{



		global $callConfig;

		$whr='user_id='.$_SESSION['id'];

		if($searchword!="")

		{

		$whr.=" and (firstname like '%$searchword%' or lastname like '%$searchword%' or phone_number like '%$searchword%')";

		}

		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,'',$start,$end);

		//echo $query; exit;  

		return  $callConfig->getAllRows($query);

	

	}

	function getTotalLeadsCount($id)

	{

	global $callConfig;

	$whr="user_id='".$id."'";

    $query=$callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'count(*) as count',$whr,'','','') ;  

	$res = $callConfig->getRow($query);

	return $res->count;

	//return $callConfig->getCount($query);

	}

	function getTotalLeadsCountBySataus($id,$status)

	{

	global $callConfig;

	$whr="user_id='".$id."' and status='".$status."'";

    $query=$callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'count(*) as count',$whr,'','','') ;  

	$res = $callConfig->getRow($query);

	return $res->count;

	//return $callConfig->getCount($query);

	}

	function deleteLeedFromUser($post)

	{

	

		global $callConfig;

		$fieldnames=array('`user_id`'=>0);

		print_r($post['leadsid']);	

		//$res=" UPDATE crm_customer_list SET `user_id`=".$post['employeename']." WHERE id IN('4,8')";

		$leadsid=$post['leadsid'];

		$i=0;

		foreach($leadsid as $leads_id)

		{

		$res[$i]=$callConfig->updateRecord(TPREFIX.TBL_CUSTOMER_LIST,$fieldnames,'id',$leads_id);

		

		$i++;

		}

		$callConfig->headerRedirect(SITEURL."/AssignLeadsView/".$_GET['eid']."?err=Lead Deleted Successfully");

	

	}

	function getPreviousRecord($id,$status)

	{

		global $callConfig;

		/* $whr="id='".$id."'";

		$query=$callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'id',$whr,'','',''); 

		//echo $query; 

		$getid=$callConfig->getRow($query);	

		$presentid=$getid->id; */

		

		//previous

		$whr="id<".$id." and user_id=".$_SESSION['id']." and status='".$_GET['status']."'";

		$order='id DESC';

		$query=$callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,$order,'',''); 

		//echo $query; exit;

		$previousid=$callConfig->getRow($query);

		$previous_ordernumber=$previousid->id;

		//echo $previous_ordernumber; exit;

		return $previous_ordernumber; 	

		

	}

	function getNextRecord($id,$status)

	{
		/* echo "id : ".$id;
		echo "status : ".$status; */
		global $callConfig;

		/* $whr="order_number='".$id."'" ;

		$query=$callConfig->selectQuery(TPREFIX.TBL_ORDER,'id',$whr,'','',''); 

		//echo $query; 

		$getid=$callConfig->getRow($query);	

		$presentid=$getid->id; */

		

		//previous
		if($_SESSION['role'] == 'admin') {
			$whr="id>".$id." and status='".$_GET['status']."'";
		} else {
			$whr="id>".$id." and user_id=".$_SESSION['id']." and status='".$_GET['status']."'";
		}
		$order='id ASC';

		$query=$callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,$order,'',''); 
		$next_ordernumber = 0;
		$nextid=$callConfig->getRow($query);
		if ($nextid)
			$next_ordernumber=$nextid->id;

		return $next_ordernumber; 	
	}

	function getEmployeePaidDetails($id)

	{

		global $callConfig;

		$whr="id=".$id;

		$query	= $callConfig->selectQuery(TPREFIX.TBL_USER_PAID,'*',$whr,'','','');

		//echo $query;  

		return  $callConfig->getRow($query);

	}

	function editPaidUser($post)

	{

		global $callConfig;

			

		$employee_id = userClass::test_input($post["employee_id"]);

		$amount = userClass::test_input($post["amount"]);

		$month = userClass::test_input($post["month"]);

		$year = userClass::test_input($post["year"]);

		$written = userClass::test_input($post["written"]);

		$cleared = userClass::test_input($post["cleared"]);

		$fieldnames=array('employee_id'=>$employee_id,'amount'=>$amount,'month'=>$month,'year'=>$year,'written'=>$written,'cleared'=>$cleared);	

		$res=$callConfig->updateRecord(TPREFIX.TBL_USER_PAID,$fieldnames,'id',$post['hidden_id']);

	

		//echo $res; exit;

			if($res>0)

			{

		

				$callConfig->headerRedirect(SITEURL."/PaidBusiness/".$post['employee_id']."?err=changed successfully");

				

			}

			else

			{

			    $callConfig->headerRedirect(SITEURL."/PaidBusiness/".$post['employee_id']."?ferr=changed failed");

				

			}

	}

	function updateLeadProfile($post)

	{

		global $callConfig;

		

		$number="0".$post['phonenumber'];

		$query="UPDATE crm_customer_list SET firstname='".$post['firstname']."', lastname='".$post['lastname']."', disname='".$post['disname']."' email='".$post[email]."',phone_number='".$number."',mobile_number='".$post['mobilenumber']."',address='".$post['address']."',country='".$post['country']."',town='".$post['town']."',postcode='".$post['postcode']."',title='".$post['title']."',company='".$post['company']."'  WHERE id=".$post['hdn_id'];

		//echo $query; exit; 

		//$res=$callConfig->updateRecord(TPREFIX.TBL_CUSTOMER_LIST,$fieldnames,'id',$post['hdn_id']);

		$res=mysql_query($query);

		if($res>0)

		{

			$_SESSION['message']='updatesucc';

			$callConfig->headerRedirect(SITEURL."/leedslistview.php?id=".$post['hdn_id']."&page=".$_GET['page']);					

			exit;

		}

		else

		{

			$_SESSION['errormessage']='updatefailed';

			$callConfig->headerRedirect(SITEURL."/leedslistview.php?id=".$post['hdn_id']."&page=".$_GET['page']);	

			exit;

		}

		

	}

	function updateLeadProfilebyUser($post)

	{

	global $callConfig;

		

		$number="0".$post['phonenumber'];

		$query="UPDATE crm_customer_list SET firstname='".$post['firstname']."', lastname='".$post['lastname']."', email='".$post[email]."',phone_number='".$number."',mobile_number='".$post['mobilenumber']."',address='".$post['address']."',country='".$post['country']."',town='".$post['town']."',postcode='".$post['postcode']."',title='".$post['title']."',company='".$post['company']."'  WHERE id=".$post['hdn_id'];

		//echo $query; exit; 

		//$res=$callConfig->updateRecord(TPREFIX.TBL_CUSTOMER_LIST,$fieldnames,'id',$post['hdn_id']);

		$res=mysql_query($query);

		if($res>0)

		{

			$_SESSION['message']='updatesucc';

			$callConfig->headerRedirect(SITEURL."/CustomerList/".$post['hdn_status']."?nextid=".$post['hdn_id']);					

			exit;

		}

		else

		{

			$_SESSION['errormessage']='updatefailed';

			$callConfig->headerRedirect(SITEURL."/CustomerList/".$post['hdn_status']."?nextid=".$post['hdn_id']);	

			exit;

		}

		

	}

	function deleteMessage($id)

	{

	//echo $id exit;

	global $callConfig;



	$res=$callConfig->deleteRecord(TPREFIX.TBL_BOARD,'id',$id);

	if($res>0)

			{		  

				//$_SESSION['err']="Delete Successfully";

				$callConfig->headerRedirect(SITEURL."/AdminBoard?err=Delete Successfully");

				

			}

			else

			{

			    //$_SESSION['ferr']="Deletion Failed";

				$callConfig->headerRedirect(SITEURL."/AdminBoard?ferr=Deletion Failed");

				

		}

	

	}



	function getAdminMessage($id)

	{

		global $callConfig;

		$whr="id=".$id;

		$query	= $callConfig->selectQuery(TPREFIX.TBL_BOARD,'*',$whr,'','','');

		//echo $query;  

		return  $callConfig->getRow($query);

	}

	function UpdateAdminBoardMessage($post)

	{

		global $callConfig;

		$fieldnames=array('description'=>mysql_real_escape_string($post['description']),'createdon'=>date('d M Y'),'status'=>'Active');

		//print_r($fieldnames); die;

		$res=$callConfig->updateRecord(TPREFIX.TBL_BOARD,$fieldnames,'id',$post['hidden_id']);

		//print_r($res); exit;

		if($res>0)

			{	//$_SESSION['err']="Message Send Successfully";

				$q="UPDATE crm_user_login SET messageCount = messageCount + 1";

				$callConfig->executeQuery($q);

				$callConfig->headerRedirect(SITEURL."/AdminBoard?err=Edit Successfully");

				

			}

			else

			{

			    //$_SESSION['ferr']="Message Send Failed";

				$callConfig->headerRedirect(SITEURL."/AdminBoard?ferr=Edit Failed");

				

			}

	

	}

	function getLeadNotes($id)

	{

		global $callConfig;

		$whr="id=".$id;

		$query	= $callConfig->selectQuery(TPREFIX.TBL_NOTES,'*',$whr,'','','');

		//echo $query;  

		return  $callConfig->getRow($query);

	}

	function UpdateLeadsMessage($post)

	{

		global $callConfig;

		$fieldnames=array('description'=>mysql_real_escape_string($post['description']),'status'=>'Active');

		//print_r($fieldnames); die;

		$res=$callConfig->updateRecord(TPREFIX.TBL_NOTES,$fieldnames,'id',$post['hidden_id']);

		//print_r($res); exit;

		if($res>0)

			{	//$_SESSION['err']="Message Send Successfully";

				$q="UPDATE crm_user_login SET messageCount = messageCount + 1";

				$callConfig->executeQuery($q);

				$callConfig->headerRedirect(SITEURL."/notes.php?err=Edit Successfully");

				

			}

			else

			{

			    //$_SESSION['ferr']="Message Send Failed";

				$callConfig->headerRedirect(SITEURL."/notes.php?ferr=Edit Failed");

				

			}

	

	}

	function getactivestatus($id)

	{

	global $callConfig;

	$whr='lead_id="'.$id.'" ';

	$query=$callConfig->selectQuery(TPREFIX.TBL_ACTIVE_USERS,'*',$whr,'','','');

	//echo $query; exit;

	$result=$callConfig->getRow($query);

	return $result->status; 

	}

	function updateLeadStatus($id)

	{

	

		global $callConfig;

		$fieldnames=array('status'=>'inactive');

		//print_r($fieldnames); die;

		$res=$callConfig->updateRecord(TPREFIX.TBL_ACTIVE_USERS,$fieldnames,'lead_id',$id);

		//print_r($res); exit;

	

	}

	

	function getCountFirstquater($year,$status)

	{

		global $callConfig;

		$whr="MONTH(".$status.")='01' or MONTH(".$status.")='02' or MONTH(".$status.")='03' and YEAR(".$status.")='".$year."'" ;

		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'count(*) as count',$whr,'','','');

		$res = $callConfig->getRow($query);

		return $res->count;

		//return  $callConfig->getCount($query);

	}

	function getCountSecondquater($year,$status)

	{

		global $callConfig;

		$whr="MONTH(".$status.")='04' or MONTH(".$status.")='05' or MONTH(".$status.")='06' and YEAR(".$status.")='".$year."'" ;

		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'count(*) as count',$whr,'','','');

		$res = $callConfig->getRow($query);

		return $res->count;

		//return  $callConfig->getCount($query);

	}

	function getCountThirdquater($year,$status)

	{

		global $callConfig;

		$whr="MONTH(".$status.")='07' or MONTH(".$status.")='08' or MONTH(".$status.")='09' and YEAR(".$status.")='".$year."'" ;

		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'count(*) as count',$whr,'','','');

		$res = $callConfig->getRow($query);

		return $res->count;

		//return  $callConfig->getCount($query);

	}

	function getCountFourthquater($year,$status)

	{

		global $callConfig;

		$whr="MONTH(".$status.")='10' or MONTH(".$status.")='11' or MONTH(".$status.")='12' and YEAR(".$status.")='".$year."'" ;

		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'count(*) as count',$whr,'','','');

		return  $callConfig->getCount($query);

	}

	function getAllEmployeeList()

	{

		global $callConfig;

		$whr="role='sales'" ;

		$query	= $callConfig->selectQuery(TPREFIX.TBL_USER_LOGIN,'id,firstname,lastname',$whr,'','','');

		return  $callConfig->getAllRows($query);

	

	}

	function getAllEmployeeListWithPaid()

	{

		

	}

	function getAllEmployeeAmmount()

	{

	    global $callConfig;

		//$whr="role='sales'" ;

		$whr="";

		$query	= $callConfig->selectQuery(TPREFIX.TBL_USER_PAID,'*',$whr,'','','');

		return  $callConfig->getAllRows($query);	

	}

	function getAllEmployeeStatusCount($status,$id)

	{

		 global $callConfig;

		//$whr="role='sales'" ;

		//echo "welcome";

		$whr="user_id=".$id." and  $status!='00-00-000 00:00:00'";

		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'count(*) as count',$whr,'','','');

		$res = $callConfig->getRow($query);

		return $res->count;

		//echo $query; exit;

		//return  $callConfig->getAllRows($query);

		//return  $callConfig->getCount($query);

	}

	

	function getStatusCount($status)

	{

		 global $callConfig;

		$whr="status='".$status."'";

		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'count(*) as count',$whr,'','','');

		$res = $callConfig->getRow($query);

		return $res->count;

		//echo $query;

		//return  $callConfig->getAllRows($query);

		//return  $callConfig->getCount($query);



	}

	
	function changePasswordNew($post)
	{
	//print_r($post); exit;
		global $callConfig;
	
	
	$fieldnames=array('`password`'=>$callConfig->passwordEncrypt($post['newpassword']));	
			
	
			
	$res=$callConfig->updateRecord(TPREFIX.TBL_USER_LOGIN,$fieldnames,'id',$_SESSION['id']);
	
		//echo $res; exit;
			if($res>0)
			{
			
			  	$callConfig->headerRedirect(SITEURL."/ChangePassword?err='Password changed sucessfully'");
				
			}
			else
			{
			    $callConfig->headerRedirect(SITEURL."/ChangePassword?ferr='Password changing failed'");
				
			}
	}
	function checkoldpassword($oldpassword)
	{
		
	//print_r($post); exit;
	//echo $oldpassword; exit;
		global $callConfig;

		$whr='id='.$_SESSION['id'];
		
		$query	= $callConfig->selectQuery(TPREFIX.TBL_USER_LOGIN,'*',$whr,'','','');	
		
		$res = $callConfig->getRow($query);
		
		if($callConfig->passwordDecrypt(($res->password))==$oldpassword)
		{
			//echo "welcome"; exit;
			return 1; 
		}
		else
		{
			return 0;
		}
			
	
	
	}
	
	
function changeemployeePasswordNew($post)
	{
	//print_r($post); exit;
		global $callConfig;
	
	
	$fieldnames=array('`password`'=>$callConfig->passwordEncrypt($post['newpassword']));	
	//print_r($fieldnames);exit;
			
	
			
	$res=$callConfig->updateRecord(TPREFIX.TBL_USER_LOGIN,$fieldnames,'id',$post['employeelist']);
	$whr='id='.$post['employeelist'];
	$query= $callConfig->selectQuery(TPREFIX.TBL_USER_LOGIN,'*',$whr,'','','');
	$result=$callConfig->getRow($query);
	
		//echo $result; exit;
			if($res>0)
			{
	
		$to=$result->email;

		$from='info@kylecrm.com';

		$subject='Change Password';

		

		$headers  = 'From:  KYLE CRM  <info@kylecrm.com>' . "\r\n";	

		$headers .='Reply-To: '. $from . "\r\n" ;

		$headers .='X-Mailer: PHP/' . phpversion();

		$headers .= "MIME-Version: 1.0\r\n";

		$headers .= "Content-type: text/html; charset=iso-8859-1\r\n"; 

		$msg="<html>

<body style='font-family:'Conv_GOTHIC',Sans-Serif; font-size:12px; color:#000; '>

<table cellspacing='0' cellpadding='5'  align='center' width='100%' border='0' style='border:1px solid #CCCCCC; border-collapse:collapse; font-family:Verdana, Arial, Helvetica, sans-serif; font-size:11px;'>

		  <tr>

		 

			<td  colspan='2' align='left' valign='top' bgcolor='#32323a'><a href='".SITEURL."/'>

			<img src='".SITEURL."/images/login_logo_03.png' border='0' ></a></td>

		  </tr>

		  <tr>

			<td valign='top' colspan='2' align='left'><strong></strong> </td>

		  </tr>

		   <tr>

			<td valign='top' colspan='2' align='left'><strong>Login email-id: </strong> ".$result->email." </td>

		  </tr>

		  <tr>

			<td valign='top' colspan='2' align='left'><strong> Password:</strong> ".$result->password." </td>

		  </tr>

		  <tr>

			<td valign='top' colspan='2' align='left'>&nbsp;</td>

		  </tr>

		  <tr>

			<td valign='top' colspan='2' align='left'>Thank You,<br />

			  Support Team, Kyle-CRM</td>

		  </tr>

		  

		</table></body>

</html>";

		

		//echo $msg; exit;

		mail($to,$subject,$msg,$headers);

		$_SESSION['err']="Password Sent Successfully";

		$callConfig->headerRedirect("ChangeEmployeePassword?err=Password Sent Successfully");
				
			}
			else
			{
			    $callConfig->headerRedirect(SITEURL."/ChangeEmployeePassword?ferr='Password changing failed'");
				
			}
	}

	function getemployeelist()
	{
		global $callConfig;
		$whr=" role='sales'";
		$query=$callConfig->selectQuery(TPREFIX.TBL_USER_LOGIN,'*',$whr,'','','');
		return $callConfig->getAllRows($query);
	}
	
	function updateemployee($emppid,$leadid)
	{
		global $callConfig;
		//$result=$this->getemployeelist($emppid);
	//print_r($result);
	    //$result2=$this->getleadlist($leadid);
		$fieldnames=array('user_id'=>$emppid);
		$res=$callConfig->updateRecord(TPREFIX.TBL_CUSTOMER_LIST,$fieldnames,'id',$leadid);
		//echo $res; 
		
		
	}
	function sortbystatus($status)
	{
		global $callConfig;
		if($status=="All")
		{
		$whr="";
		
		}
		else
		{
		$whr="status='".$status."'";
		}
		$query= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,'','','');
		//echo $query;exit;
		return $callConfig->getAllRows($query);
	}
	function getAllSeperateleedslist($start,$end,$sortfield,$order,$listname)

	{

		global $callConfig;

		if($sortfield!="" && $order!="") 

		$order=$sortfield.' '.$order;

		$whr='user_id=0 and listname="'.$listname.'"';

		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,$order,$start,$end);

		//echo "Empty Listname : ".$query;  

		return  $callConfig->getAllRows($query);
	}
	
	function getSearchdata($data,$status,$start,$end,$sortfield,$order,$listname)
	{
		global $callConfig;
		
		if($_SESSION['role']=='admin'){	
			$whr="(`firstname` LIKE '%".$data."%' or `lastname`='%".$data."%')";
		}else if($_SESSION['role']=='sales'){
			$whr="(`firstname` LIKE '%".$data."%' or `lastname`='%".$data."%') and user_id='".$_SESSION['id']."'";
		}
		if($status!="")
		{
			$whr.=" and status='".$status."'";
		}
		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,'','','');
		//echo $query;
		return $callConfig->getAllRows($query);
	}
	
	function getAllemployeeleads($id,$start,$limit,$sortfield,$order)
	{
		global $callConfig;
		if($sortfield!="" && $order!="") 

		$order=$sortfield.' '.$order;
		
		$whr="user_id='".$id."' and del='no'";
		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,$order,$start,$limit);
		//echo $query;
		return $callConfig->getAllRows($query);
	}
	
	function deleteemployeeleads($post)
	{
		global $callConfig;
		$fieldnames=array('`del`'=>'yes');
		for($i=0;$i<count($post['leadsid']);$i++){
			$res=$callConfig->updateRecord(TPREFIX.TBL_CUSTOMER_LIST,$fieldnames,'`id`',$post['leadsid'][$i]);
		}
		if($res>0){
			$callConfig->headerRedirect(SITEURL."/EmployeeLeads/1");
			exit;
		}
	}
	
	function insertRightnavtab1data($content,$hidden_tab)
	{
	//print_r($content,$hidden_tab); exit;
		global $callConfig;
		if($hidden_tab=="tab1")
		{
		$insertfields1=array('content_tab1'=>$content,'user_id'=>$_SESSION['id']);
		//echo $insertfields1; exit;
		}
		elseif($hidden_tab=="tab2")
		{
		$insertfields1=array('content_tab2'=>$content,'user_id'=>$_SESSION['id']);
		}
		elseif($hidden_tab=="tab3")
		{
		$insertfields1=array('content_tab3'=>$content,'user_id'=>$_SESSION['id']);
		}
		$res=$callConfig->insertRecord(TPREFIX.TBL_LEADS_NOTES,$insertfields1);
		return $res;
		
	}	
	
	function updateRightnavtab1data($content,$hidden_tab)
	{
		global $callConfig;
		if($hidden_tab=="tab1")
		{
		$updatefields1=array('content_tab1'=>$content,'user_id'=>$_SESSION['id']);
		}
		elseif($hidden_tab=="tab2")
		{
		$updatefields1=array('content_tab2'=>$content,'user_id'=>$_SESSION['id']);
		}
		elseif($hidden_tab=="tab3")
		{
		$updatefields1=array('content_tab3'=>$content,'user_id'=>$_SESSION['id']);
		}
		$res=$callConfig->updateRecord(TPREFIX.TBL_LEADS_NOTES,$updatefields1);
	}
	function getSalesEmployee()
	{
		global $callConfig;
		$whr=" role='sales'";
		$query=$callConfig->selectQuery(TPREFIX.TBL_USER_LOGIN,'*',$whr,'','','');
		return $callConfig->getAllRows($query);
	}
	function getemployeerate()
	{
		global $callConfig;

		$query=$callConfig->selectQuery(TPREFIX.TBL_USER_LOGIN,'employee_id',$fieldnames);



		return  $callConfig->getAllRows($query);
	}
		function getSearchdataCount($data,$status)
	{
		global $callConfig;
		
		if($sortfield!="" && $order!="") 

		$order=$sortfield.' '.$order;
		if($_SESSION['role']=='admin'){	
			$whr="(`firstname` LIKE '%".$data."%' or `lastname`='%".$data."%')";
		}else if($_SESSION['role']=='sales'){
			$whr="(`firstname` LIKE '%".$data."%' or `lastname`='%".$data."%') and user_id='".$_SESSION['id']."'";
		}
		if($status!="")
		{
			$whr.=" and status=".$status;
		}
		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,$order,$start,$end);
		return $callConfig->getCount($query);
	}
	function getEmployeeAmount($empid)
	{
		
		global $callConfig;
		$whr="employee_id=".$empid;
		$query	= $callConfig->selectQuery(TPREFIX.TBL_USER_PAID,'*',$whr,'','','');
		return  $callConfig->getAllRows($query);
	}
	function getAllDeleteEmployeeLeads($start,$limit,$sortfield,$order)
	{
		global $callConfig;
		if($sortfield!="" && $order!="") 

		$order=$sortfield.' '.$order;

		$whr=" del='yes'";
		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,$order,$start,$limit);
		return $callConfig->getAllRows($query);
	}
	function getRightnavtab1data()
	{
	    global $callConfig;
		$whr=" user_id=".$_SESSION['id'];
		$query =$callConfig->selectQuery(TPREFIX.TBL_LEADS_NOTES,'*',$whr,'','','');
		return $callConfig->getRow($query);
	}
	function deleteleadspermenant($post)
	{
		global $callConfig;
		for($i=0;$i<count($post['leadsid']);$i++){
			$res=$callConfig->deleteRecord(TPREFIX.TBL_CUSTOMER_LIST,'id',$post['leadsid'][$i]);
			
		}
		if($res>0){
			$_SESSION['err']="Deleted Successfully";
			$callConfig->headerRedirect(SITEURL."/DeleteLeads/1");
			exit;
		}
		else
		{
			$_SESSION['err']="Deleted Failed";
			$callConfig->headerRedirect(SITEURL."/DeleteLeads/1");
			exit;
		}
	}
	function getAllDeleteEmployeeLeadsCount()
	{
		global $callConfig;
		$whr=" del='yes'";
		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,'','','');
		return $callConfig->getCount($query);
	}
	function getAllemployeeleadscount($id)
	{
		global $callConfig;
		$whr="user_id='".$id."' and del='no'";
		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,'',$start,$limit);
		return $callConfig->getCount($query);
	}
	function updateIpaddress($post)
	{
		global $callConfig;
		$query = $callConfig->updateRecord(TPREFIX.TBL_IPADDRESS_LIST,array('iplist'=>$post['ipaddress']),'id',1);
			if($query>0)
	{

	
                //unset($_SESSION['err']);	
				//$_SESSION['err']="IP Address Changed Successfully";
                
				$callConfig->headerRedirect(SITEURL."/ipaddress.php?err=IP Address Changed Successfully");

			}

			else

			{
				
				//$_SESSION['ferr']="IP Address Changed Failed";

				$callConfig->headerRedirect(SITEURL."/ipaddress.php?ferr=IP Address Changed Failed");
    }
	
	}
	function getIpaddressList()
	{
	global $callConfig;
	
	$whr="id=1";
	$query	= $callConfig->selectQuery(TPREFIX.TBL_IPADDRESS_LIST,'*',$whr,'','','');
	//echo $query; 
	return $callConfig->getRow($query);
	
	}
	
	function getAllUsers() 
	{
		global $callConfig;
		$whr="";
		
		$query	= $callConfig->selectQuery(TPREFIX.TBL_USER_LOGIN,'id,firstname,lastname','','','','');
		return  $callConfig->getAllRows($query);
		
	}
	function getAllSavedDDRRequests()
	
	{

		global $callConfig;
	
		$whr="receive_user_id=0";
		
		$query1 = $callConfig->selectQuery('crm_data_drive_request','*',$whr,'','','');
		//echo $query1; exit;
		return $callConfig->getAllRows($query1);
	}
	
	function getAllDDRRequests($id)
	
	{
		//echo 'fn getAllDDRRequests';
	
		global $callConfig;
	
		$whr="receive_user_id=".$id;
	
		/* $query	= $callConfig->selectQuery('crm_data_drive_request','ddr_id',$whr,'','','');
	
		$row = $callConfig->getAllRows($query);
		$ddr_id = $row->ddr_id;

		$whr1="data_drive_request_id=".$ddr_id; */
		
		$query1	= $callConfig->selectQuery('crm_data_drive_request','*',$whr,'data_drive_request_id DESC','','');
		
		return $callConfig->getAllRows($query1);
		
		//return $callConfig->getAllRows($query);
	
		//return  $callConfig->getRow($query);
	
	}

	function saveDDRForm($fileds){
		global $callConfig;
		$curr_date =  date("Y-m-d h:i:s");
		//echo 'curr_date : '.$curr_date; exit;
		$insertfields1=array(
			'added_user_id'=>$fileds['added_user_id'],
			'receive_user_id'=>$fileds['receive_user_id'],
			'company_name'=>$fileds['company_name'],
			'dealer_name'=>$fileds['dealer_name'],
			'date_dealt'=>$fileds['date_dealt'],
			'client_name'=>$fileds['client_name'],
			'address_line1'=>$fileds['address_line1'],
			'address_line2'=>$fileds['address_line2'],
			'post_code'=>$fileds['post_code'],
			'phone_number'=>$fileds['phone_number'],
			'id_number'=>$fileds['id_number'],
			'product'=>$fileds['product'],
			'total_trade_value'=>$fileds['total_trade_value'],
			'alert_time'=>$fileds['alert_time'],
			'status'=>$fileds['status'],
			'client_situation'=>$fileds['client_situation'],
			'date_added'=>$curr_date,
			'date_updated'=>$curr_date,
		);
		$res=$callConfig->insertRecord('crm_data_drive_request',$insertfields1);
		//echo $res; exit;
		$insert_id = mysql_insert_id();
		if ($res) {
			$insertfields = array(
				'modified_user_id'=>$fileds['added_user_id'],
				'assigned_user_id'=>$fileds['receive_user_id'],
				'company_name'=>$fileds['company_name'],
				'dealer_name'=>$fileds['dealer_name'],
				'date_dealt'=>$fileds['date_dealt'],
				'client_name'=>$fileds['client_name'],
				'address_line1'=>$fileds['address_line1'],
				'address_line2'=>$fileds['address_line2'],
				'post_code'=>$fileds['post_code'],
				'phone_number'=>$fileds['phone_number'],
				'id_number'=>$fileds['id_number'],
				'product'=>$fileds['product'],
				'total_trade_value'=>$fileds['total_trade_value'],
				'alert_time'=>$fileds['alert_time'],
				'status'=>$fileds['status'],
				'client_situation'=>$fileds['client_situation'],
				'ddr_id'=>$insert_id,
				'date_added'=>$curr_date,
			);
			$res1 = $callConfig->insertRecord('ddr_update_history',$insertfields);
			return $res1;
		}
	}

	function getDDRCount($id)
 {
  global $callConfig;
  
  $whr="receive_user_id=".$id." AND clicked_count < 1";
  
  $query=$callConfig->selectQuery('crm_data_drive_request','count(*) as count',$whr,'','','') ; 
  //echo $query;
  $res = $callConfig->getRow($query);
  
  return $res->count;
 }
 
function getRecentDDRCount($id)
 {
  global $callConfig;
  $whr="receive_user_id=".$id." AND clicked_count < 1 AND date_added >= now() - interval 30 second";
  //$whr="date_added >= now() - interval 30 second";
  //echo $whr; 
  
  $query=$callConfig->selectQuery('crm_data_drive_request','count(*) AS count',$whr,'','','') ;
 
  $res = $callConfig->getRow($query);
  return $res->count;
 }
 
 function getUser_id($id)
 {
	global $callConfig;
	$whr="id=".$id."";
	$query= $callConfig->selectQuery(TPREFIX.TBL_USER_LOGIN,'*',$whr,'','','');
	//echo $query; exit;
	return $callConfig->getRow($query);	 
 }

function getdDDRDetails($data_drive_request_id)
	{
		global $callConfig;
		
		$whr="data_drive_request_id=$data_drive_request_id";
		$query	= $callConfig->selectQuery('crm_data_drive_request','*',$whr,'','','');
	//	echo $query; exit;
		return $callConfig->getAllRows($query);
	}	
 
 function getAllAlerts($id)
 {
		global $callConfig;
	
		$whr="receive_user_id=".$id."";
	
		$query=$callConfig->selectQuery('crm_data_drive_request','*',$whr,'','','') ;
	
		$res = $callConfig->getAllRows($query);
	
		return $res;
 }

function updateClickedCount($clicked_count, $data_drive_request_id)
	{
		global $callConfig;
		$updatefields=array(
				'clicked_count' => $clicked_count,
		);
		
		$res=$callConfig->updateRecord('crm_data_drive_request',$updatefields, 'data_drive_request_id',$data_drive_request_id);
		return $res;
	}

function updateDDRForm($fileds, $ddr_id){
		global $callConfig;
		$curr_date =  date("Y-m-d h:i:s");
		$updatefields=array(
				'added_user_id'=>$fileds['added_user_id'],
				'receive_user_id'=>$fileds['receive_user_id'],
				'company_name'=>$fileds['company_name'],
				'dealer_name'=>$fileds['dealer_name'],
				'date_dealt'=>$fileds['date_dealt'],
				'client_name'=>$fileds['client_name'],
				'address_line1'=>$fileds['address_line1'],
				'address_line2'=>$fileds['address_line2'],
				'post_code'=>$fileds['post_code'],
				'phone_number'=>$fileds['phone_number'],
				'id_number'=>$fileds['id_number'],
				'product'=>$fileds['product'],
				'total_trade_value'=>$fileds['total_trade_value'],
				'alert_time'=>$fileds['alert_time'],
				'status'=>$fileds['status'],
				'client_situation'=>$fileds['client_situation'],
				//'date_added'=>$curr_date,
				'date_updated'=>$curr_date,
		);
		
		$res=$callConfig->updateRecord('crm_data_drive_request',$updatefields, 'data_drive_request_id',$ddr_id);
		if($res) {
			$insertfields=array(
					'modified_user_id'=>$fileds['added_user_id'],
					'assigned_user_id'=>$fileds['receive_user_id'],
					'company_name'=>$fileds['company_name'],
					'dealer_name'=>$fileds['dealer_name'],
					'date_dealt'=>$fileds['date_dealt'],
					'client_name'=>$fileds['client_name'],
					'address_line1'=>$fileds['address_line1'],
					'address_line2'=>$fileds['address_line2'],
					'post_code'=>$fileds['post_code'],
					'phone_number'=>$fileds['phone_number'],
					'id_number'=>$fileds['id_number'],
					'product'=>$fileds['product'],
					'total_trade_value'=>$fileds['total_trade_value'],
					'alert_time'=>$fileds['alert_time'],
					'status'=>$fileds['status'],
					'client_situation'=>$fileds['client_situation'],
					'ddr_id'=>$ddr_id,
					'date_added'=>$curr_date,
			);
			$res1=$callConfig->insertRecord('ddr_update_history',$insertfields);
			
			return $res1;
		}
	}
	
function deleteDDR_list($id)
{
	//echo $id exit;
	global $callConfig;
	$res=$callConfig->deleteRecord(TPREFIX.TBL_DATA_DRIVE_REQUEST,'data_drive_request_id',$id);
	//echo $res; exit;
	if($res==1)
	{		  
		//$_SESSION['err']="Delete Successfully";
		$callConfig->headerRedirect(SITEURL."/DDR_LIST?err=Delete Successfully");
	}
	else
	{
		//$_SESSION['ferr']="Deletion Failed";
		$callConfig->headerRedirect(SITEURL."/DDR_LIST?ferr=Deletion Failed");
	}
}

function deleteSaved_DDR_list($id)
{
	//echo $id exit;
	global $callConfig;
	$res=$callConfig->deleteRecord(TPREFIX.TBL_DATA_DRIVE_REQUEST,'data_drive_request_id',$id);
	//echo $res; exit;
	if($res==1)
	{		  
		//$_SESSION['err']="Delete Successfully";
		$callConfig->headerRedirect(SITEURL."/SAVE_DDR_LIST?err=Delete Successfully");
	}
	else
	{
		//$_SESSION['ferr']="Deletion Failed";
		$callConfig->headerRedirect(SITEURL."/SAVE_DDR_LIST?ferr=Deletion Failed");
	}
}

	function getDDRHistory($data_drive_request_id)
	{
		global $callConfig;
	
		$whr="ddr_id=$data_drive_request_id";
		$query	= $callConfig->selectQuery('ddr_update_history','*',$whr,'history_id DESC','','');
		//echo $query;
		return $callConfig->getAllRows($query);
	}
	
	function getclickedstatus($id)

	{
	
		global $callConfig;
	
		$whr='data_drive_request_id="'.$id.'" ';
	
		$query=$callConfig->selectQuery(TPREFIX.TBL_DATA_DRIVE_REQUEST,'*',$whr,'','','');
	
		//echo $query; exit;
	
		$result=$callConfig->getRow($query);
		if($result ) {
			return $result->clicked_count; 
		}
	
	}
	
}

?>