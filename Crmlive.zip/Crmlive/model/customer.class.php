<?php 
class customerClass 
{
	function updateAnswers($post){
		
		
		}
	function getCustomerAnswer($id){
		global $callConfig;
		$whr="customer_id=".$id;
		$query	= $callConfig->selectQuery(TPREFIX.TBL_QUESTIONS,'*',$whr,'','',''); 
		return  $callConfig->getRow($query);
		
		}

	function getNextRecord($id,$status)

	{
		/* echo "id : ".$id;
		echo "status : ".$status; */
		global $callConfig;

		/* $whr="order_number='".$id."'" ;

		$query=$callConfig->selectQuery(TPREFIX.TBL_ORDER,'id',$whr,'','',''); 

		//echo $query; 

		$getid=$callConfig->getRow($query);	

		$presentid=$getid->id; */

		

		//previous
		if($_SESSION['role'] == 'admin') {
			$whr="id>".$id." and status='".$_GET['status']."'";
		} else {
			$whr="id>".$id." and user_id=".$_SESSION['id']." and status='".$_GET['status']."'";
		}
		$order='id ASC';

		$query=$callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,$order,'',''); 
		$next_ordernumber = 0;
		$nextid=$callConfig->getRow($query);
		if ($nextid)
			$next_ordernumber=$nextid->id;

		return $next_ordernumber; 	
	}
	function getCountOfCustomerList($status)
	{
		global $callConfig;
		if($_SESSION['role']=="admin")
		{
			$whr="status='".$status."'";
		}
		else
			$whr="status='".$status."' and user_id=".$_SESSION['id']." and del='no'";
		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,'','', '');
		//echo $query;
		return  count($callConfig->getAllRows($query));
	}
	
	function getCustomerList($status, $start, $end)
	{
		global $callConfig;
		if($_SESSION['role']=="admin")
		{
		$whr="status='".$status."'";
		}
		else 
		$whr="status='".$status."' and user_id=".$_SESSION['id']." and del='no'";
		if (!empty($end) && !empty($start)) {
		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,'',$start,$end); 
		} else {
			$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,'',0, 100);
		}
		//echo $query;
		return  $callConfig->getAllRows($query);
	}
	
	
	function getSerachByCompanyList($status, $start, $end)
	{
		global $callConfig;
		$post_serachvalue=$_POST['status_searchlead'];
		if($_SESSION['role']=="admin")
		{
			if($post_serachvalue!=''){
			$whr="status='".$status."' and company='".$post_serachvalue."'";
			}else{
				$whr="status='".$status."'";
			}
		}
		else {
		$whr="status='".$status."' and company='".$post_serachvalue." user_id=".$_SESSION['id']." and del='no'";
		}
		if (!empty($end) && !empty($start)) {
		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,'',$start,$end); 
		} else {
		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,'',0, 100);
		}
		//exit;
		return  $callConfig->getAllRows($query);
	}
	function customerRegistration($post)
	{
		global $callConfig;
	//	echo  date("Y/m/d");
		$password=$callConfig->passwordEncrypt($pword);
		$number="0".$post['phone_number'];
		//$fieldnames=array('email'=>$post['email'],'firstname'=>$post['firstname'],'lastname'=>$post['lastname'],'phone_number'=>"$number",
		//'comments'=>$post['comments'],'status'=>'Cold Lead','address'=>$post['address'],'mobile_number'=>$post['mobile_number']);
		//print_r($fieldnames); die;
		$email=$post['email'];
		$phone_number=$post['phone_number'];
		$firstname=	$post['firstname'];
		$lastname=$post['lastname'];
		$comments=$post['comments'];
		$status='Cold Lead';
		$address=$post['address'];
		$mobile_number=$post['mobile_number'];
		
		$query="insert into crm_customer_list (email,firstname,lastname,phone_number,comments,status,address,mobile_number) values ('".$post['email']."','".$post['firstname']."','".$post['lastname']."','".$number."','".$post['comments']."','".$post['status']."','".$post['address']."','".$post['mobile_number']."')";
		//echo $query; exit; 
		mysql_query($query);
		$res=mysql_insert_id();
		//$res=$callConfig->insertRecord(TPREFIX.TBL_CUSTOMER_LIST,$fieldnames);
		//echo $res; exit; 
		if($res!=""){
		$callConfig->headerRedirect(SITEURL."/Leads/1?err=Customer Added successfully");
		
		}
		else
		{
		//$_SESSION['ferr']="Customer Added fail Try again";
		$callConfig->headerRedirect(SITEURL."/Leads/1?ferr=Customer Added fail Try again");
		}

	}
	function getCustomerData($id)
	{
		global $callConfig;
		$whr="id=".$id;
		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,'','',''); 
		return  $callConfig->getRow($query);
	}
	
	function getComment($id)
	{
		global $callConfig;
		$whr="id=".$id;
		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*',$whr,'','',''); 
		//echo $query; exit;
		$res =  $callConfig->getRow($query);
		$cid = $res->id;
		
			$query1="select ap.*,p.* from crm_customer_list ap JOIN crm_comments p ON p.emp_id=ap.id where ap.id='".$cid."'";
			//echo $query1; exit;
			return  $callConfig->getAllRows($query1);
	}
	
	function getCommentnotify($id)
	{
		global $callConfig;
		$whr="name='admin' and emp_id='".$id."'" ;
		$query	= $callConfig->selectQuery('crm_comments','*',$whr,'','','');
		//echo $query;exit;   
		return  $callConfig->getCount($query);
	}
	
	function statusAsignToEmployee($post)

	{
		global $callConfig;
		$per_page = 20;
		if($_GET['status'] == 'Cold_Lead')
		{
			$total_results = $_SESSION['coldleadscount'];
		} else if ($_GET['status'] == 'Teed') {
			$total_results = $_SESSION['teedleadscount'];
		} else if ($_GET['status'] == 'Closed') {
			$total_results = $_SESSION['closedeadscount'];
		} else if ($_GET['status'] == 'Open') {
			$total_results = $_SESSION['openleadscount'];
		}
		else {
			$total_results =customerClass::getCountOfCustomerList($_GET['status']);
		}
		$total_pages = ceil($total_results / $per_page);//total pages we going to have
		//-------------if page is setcheck------------------//
		if (isset($_GET['page'])) {
			$show_page = $_GET['page'];             //it will telles the current page
			if ($show_page > 0 && $show_page <= $total_pages) {
				$start = ($show_page - 1) * $per_page;
				$end = $start + $per_page;
			} else {
				// error - show first set of results
				$start = 0;
				$end = $per_page;
			}
		} else {
			// if page isn't set, show first set of results
			$start = 0;
			$end = $per_page;
		}
		// display pagination
		$page = intval($_GET['page']);
		$tpages=$total_pages;
		if ($page <= 0)
		$page = 1;
		$nextid=customerClass::getNextRecord($post['hidden_id'],$_GET['status']);
		//print_r($post); exit;	
		$getstatusurl=$_SERVER['PHP_SELF']."?nextid=".$nextid."&status=".$_GET['status']."&tpages=" . $tpages."&page=" . $page;
		
		$leadsid=$post['staus_leads_list'];
		$i=0;
		foreach($leadsid as $leads_id)
		{
		$fieldnames=array('status'=>$post['change_status']);
		$res[$i]=$callConfig->updateRecord(TPREFIX.TBL_CUSTOMER_LIST,$fieldnames,'id',$leads_id);
		$i++;
		}
	
		if($res!=""){
		$_SESSION['err']="Customer Added successfully";
		$callConfig->headerRedirect($getstatusurl."&err=updated successfully");
		
		}
		else
		{
		$_SESSION['ferr']="Customer Added fail Try again";
		$callConfig->headerRedirect(SITEURL."/CustomerList/".$_GET['status']);
		}
	}
	
	
	function updateCustomerDetails($post)
	{
		global $callConfig;
		$per_page = 20;
		if($_GET['status'] == 'Cold_Lead')
		{
			$total_results = $_SESSION['coldleadscount'];
		} else if ($_GET['status'] == 'Teed') {
			$total_results = $_SESSION['teedleadscount'];
		} else if ($_GET['status'] == 'Closed') {
			$total_results = $_SESSION['closedeadscount'];
		} else if ($_GET['status'] == 'Open') {
			$total_results = $_SESSION['openleadscount'];
		}
		else {
			$total_results =customerClass::getCountOfCustomerList($_GET['status']);
		}
		$total_pages = ceil($total_results / $per_page);//total pages we going to have
		//-------------if page is setcheck------------------//
		if (isset($_GET['page'])) {
			$show_page = $_GET['page'];             //it will telles the current page
			if ($show_page > 0 && $show_page <= $total_pages) {
				$start = ($show_page - 1) * $per_page;
				$end = $start + $per_page;
			} else {
				// error - show first set of results
				$start = 0;
				$end = $per_page;
			}
		} else {
			// if page isn't set, show first set of results
			$start = 0;
			$end = $per_page;
		}
		// display pagination
		$page = intval($_GET['page']);
		$tpages=$total_pages;
		if ($page <= 0)
		$page = 1;
		$nextid=customerClass::getNextRecord($post['hidden_id'],$_GET['status']);
		//print_r($post); exit;	
		$getstatusurl=$_SERVER['PHP_SELF']."?nextid=".$nextid."&status=".$_GET['status']."&tpages=" . $tpages."&page=" . $page;
		//echo $getstatusurl; exit;	
		//$started = microtime(true);
		//echo ($started / 1000).' secs';
		//echo "nextid : ".$nextid;
		//exit;
		if($post['status']=="Closed")
		{
		
		$fieldnames=array('comments'=>$post['comments'],'closed_date'=>date("Y-m-d H:m:s"),'status'=>$post['status']);
		//print_r($fieldnames); die;
		$res=$callConfig->updateRecord(TPREFIX.TBL_CUSTOMER_LIST,$fieldnames,'id',$post['hidden_id']);	
		}
		else if($post['status']=="Teed")
		{
		$fieldnames=array('comments'=>$post['comments'],'teed_date'=>date("Y-m-d H:m:s"),'status'=>$post['status']);
		$res=$callConfig->updateRecord(TPREFIX.TBL_CUSTOMER_LIST,$fieldnames,'id',$post['hidden_id']);
		}
		else if($post['status']=="Open")
		{
		$fieldnames=array('comments'=>$post['comments'],'open_date'=>date("Y-m-d H:m:s"),'status'=>$post['status']);
		$res=$callConfig->updateRecord(TPREFIX.TBL_CUSTOMER_LIST,$fieldnames,'id',$post['hidden_id']);
	
		}
		else
		{
		$fieldnames=array('comments'=>$post['comments'],'drive_date'=>$post['drive_date'],'status'=>$post['status']);
		$res=$callConfig->updateRecord(TPREFIX.TBL_CUSTOMER_LIST,$fieldnames,'id',$post['hidden_id']);
		}
		
		if($res>0)
		{   
		global $callConfig;
		$fieldnames=array('customer_id'=>$post['hidden_id'],'q1_reco'=>$post['q1_reco'],'q2_retired'=>$post['q2_retired'],
		'q19_portfolio'=>$post['q19_portfolio'],'q3_broker'=>$post['q3_broker'],
		'q4_service'=>$post['q4_service'],'q5_investment'=>$post['q5_investment'],'q6_income'=>$post['q6_income'],'q7_decision'=>$post['q7_decision'],
		'q8_email'=>$post['q8_email'],'q9_call'=>$post['q9_call'],'q10_commodities'=>$post['q10_commodities'],'q11_money'=>$post['q11_money'],
		'q12_sectors'=>$post['q12_sectors'],'q13_company'=>$post['q13_company'],'q14_id'=>$post['q14_id'],'q15_hobbies'=>$post['q15_hobbies'],
		'q16_family'=>$post['q16_family'],'q17_internet'=>$post['q17_internet'],'q18_investor'=>$post['q18_investor'],);
		
		   if($post['action']!=""){
			
	$res=$callConfig->updateRecord(TPREFIX.TBL_QUESTIONS,$fieldnames,'customer_id',$post['action']);
			   
			   }
			   else{
				   $res=$callConfig->insertRecord(TPREFIX.TBL_QUESTIONS,$fieldnames);
				   }
			$res1 = $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*','id='.$post['hidden_id'],'','',''); 
			//echo $res1; exit;
			$query = $callConfig->getRow($res1);
			//echo $query->email; exit;
			$to=$query->email;
		$from='sushmagogula@themedia3.com';
		$subject="Status Changed";
		$message="<table cellspacing='0' cellpadding='5'  align='center' width='800' border='0' style='border:1px solid #CCCCCC; border-collapse:collapse; font-family:Verdana, Arial, Helvetica, sans-serif; font-size:11px;'>

		<tr>
		<td  colspan='2' align='left' valign='top'><a href='".SITEURL."'><img src='".SITEURL."/images/login_logo_03.png' border='0' ></a></td>
		</tr>
		<tr>

		<td  colspan='2' align='left' valign='top'><strong>Kyle-CRM </strong></td>

		</tr>

		<tr>

		<td valign='top' colspan='2' align='left'>Status Change to :: ".$query->status."</td>

		</tr>

		<tr>

		<td valign='top' colspan='2' align='left'>Thank You,<br />

		KYLE-CRM</td>

		</tr>

		</table>";
		
		$headers  = 'From: Kyle-CRM ' . "\r\n";	
		$headers .='Reply-To: '. $to . "\r\n" ;
		$headers .='X-Mailer: PHP/' . phpversion();
		$headers .= "MIME-Version: 1.0\r\n";
		$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";   
		
				mail($to,$subject,$message,$headers);
			//$end= microtime(true);
			//echo ($end / 1000).' secs';
			//$difference = $end - $started; 
			//$queryTime = number_format($difference, 10);
			//echo ($difference / 1000).' secs';
			$callConfig->headerRedirect($getstatusurl."&err=updated successfully");
		}
		else
		{
			$callConfig->headerRedirect(SITEURL."/CustomerList/".$_GET['status']."?nextid=".$post['hidden_id']."&err=updated failed");
		}
	}
	function insertcomments($post)
	{
		
		//print_r($_POST); die;
		global $callConfig;
		$fieldnames=array('name'=>$post['hidden_name'],'comments'=>mysql_real_escape_string($post['comments']),'emp_id'=>$post['hidden_id'],'inserted_on'=>date('Y-m-d H:i:s',strtotime('+2 hours')));
		//echo $fieldnames; exit;
		$res=$callConfig->insertRecord(TPREFIX.TBL_COMMENTS_LIST,$fieldnames);
		//echo $res; exit;
		$per_page = 20;
		if($_GET['status'] == 'Cold_Lead')
		{
			$total_results = $_SESSION['coldleadscount'];
		} else if ($_GET['status'] == 'Teed') {
			$total_results = $_SESSION['teedleadscount'];
		} else if ($_GET['status'] == 'Closed') {
			$total_results = $_SESSION['closedeadscount'];
		} else if ($_GET['status'] == 'Open') {
			$total_results = $_SESSION['openleadscount'];
		}
		else {
			//echo "status:".$_GET['status']; 
			$total_results =customerClass::getCountOfCustomerList($_GET['status']);
			//echo $total_results; exit;
		}
		$total_pages = ceil($total_results / $per_page);//total pages we going to have
		//-------------if page is setcheck------------------//
		if (isset($_GET['page'])) {
			$show_page = $_GET['page'];             //it will telles the current page
			if ($show_page > 0 && $show_page <= $total_pages) {
				$start = ($show_page - 1) * $per_page;
				$end = $start + $per_page;
			} else {
				// error - show first set of results
				$start = 0;
				$end = $per_page;
			}
		} else {
			// if page isn't set, show first set of results
			$start = 0;
			$end = $per_page;
		}
		// display pagination
		$page = intval($_GET['page']);
		$tpages=$total_pages;
		if ($page <= 0)
		$page = 1;
		$nextid=customerClass::getNextRecord($post['hidden_id'],$_GET['status']);
		//print_r($post); exit;	
		//$getstatusurl=$_SERVER['PHP_SELF']."?nextid=".$nextid."&status=".$_GET['status']."&tpages=" . $tpages."&page=" . $page;
		$getstatusurl=$_SERVER['PHP_SELF']."?nextid=".$post['hidden_id']."&status=".$_GET['status']."&tpages=" . $tpages."&page=" . $page;
		//echo $getstatusurl;exit;
		//$password=$callConfig->passwordEncrypt($pword);
		//print_r($_POST); die;
		
		
		//print_r($fieldnames); die;
		
		//echo $res; exit; 
		if($res!=""){
		$_SESSION['err']="Customer Added successfully";
		$callConfig->headerRedirect($getstatusurl."&err=updated successfully");
		
		}
		else
		{
		$_SESSION['ferr']="Customer Added fail Try again";
		$callConfig->headerRedirect(SITEURL."/CustomerList/".$GET['status']);
		}

	}
	function getCountNumber($status,$id)
	{
		global $callConfig;
		$whr="status='".$status."' and user_id=".$id." and del='no'";
		$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'count(*) as count',$whr,'','',''); 
		$res = $callConfig->getRow($query);
		return $res->count;
		//return  $callConfig->getCount($query);
	}
	function updateLeadQuestions($post)
	{
		global $callConfig;
		//print_r($post); exit;	
		//$nextid=customerClass::getNextRecord($post[hidden_id],$_GET['status']);
		//echo $nextid; 
		
		   
		$per_page = 20;
		if($_GET['status'] == 'Cold_Lead')
		{
			$total_results = $_SESSION['coldleadscount'];
		} else if ($_GET['status'] == 'Teed') {
			$total_results = $_SESSION['teedleadscount'];
		} else if ($_GET['status'] == 'Closed') {
			$total_results = $_SESSION['closedeadscount'];
		} else if ($_GET['status'] == 'Open') {
			$total_results = $_SESSION['openleadscount'];
		}
		else {
			//echo "status:".$_GET['status']; 
			$total_results =customerClass::getCountOfCustomerList($_GET['status']);
			//echo $total_results; exit;
		}
		$total_pages = ceil($total_results / $per_page);//total pages we going to have
		//-------------if page is setcheck------------------//
		if (isset($_GET['page'])) {
			$show_page = $_GET['page'];             //it will telles the current page
			if ($show_page > 0 && $show_page <= $total_pages) {
				$start = ($show_page - 1) * $per_page;
				$end = $start + $per_page;
			} else {
				// error - show first set of results
				$start = 0;
				$end = $per_page;
			}
		} else {
			// if page isn't set, show first set of results
			$start = 0;
			$end = $per_page;
		}
		// display pagination
		$page = intval($_GET['page']);
		$tpages=$total_pages;
		if ($page <= 0)
		$page = 1;
		$nextid=customerClass::getNextRecord($post['hidden_id'],$_GET['status']);
		//print_r($post); exit;	
		//$getstatusurl=$_SERVER['PHP_SELF']."?nextid=".$nextid."&status=".$_GET['status']."&tpages=" . $tpages."&page=" . $page;
		$getstatusurl=$_SERVER['PHP_SELF']."?nextid=".$post['hidden_id']."&status=".$_GET['status']."&tpages=" . $tpages."&page=" . $page;
		$fieldnames = array('customer_id' => $post['hidden_id'],'q1_reco'=>$post['q1_reco'],'q2_retired'=>$post['q2_retired'],
		'q19_portfolio'=>$post['q19_portfolio'],'q3_broker'=>$post['q3_broker'],
		'q4_service'=>$post['q4_service'],'q5_investment'=>$post['q5_investment'],'q6_income'=>$post['q6_income'],'q7_decision'=>$post['q7_decision'],
		'q8_email'=>$post['q8_email'],'q9_call'=>$post['q9_call'],'q10_commodities'=>$post['q10_commodities'],'q11_money'=>$post['q11_money'],
		'q12_sectors'=>$post['q12_sectors'],'q13_company'=>$post['q13_company'],'q14_id'=>$post['q14_id'],'q15_hobbies'=>$post['q15_hobbies'],
		'q16_family'=>$post['q16_family'],'q17_internet'=>$post['q17_internet'],'q18_investor'=>$post['q18_investor'],);
		
		   if($post['action']!=""){
			
	$res=$callConfig->updateRecord(TPREFIX.TBL_QUESTIONS,$fieldnames,'customer_id',$post['action']);
			   
			   }
			   else{
				   $res=$callConfig->insertRecord(TPREFIX.TBL_QUESTIONS,$fieldnames);
				   }
			$res1 = $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'*','id='.$post['hidden_id'],'','',''); 
			//echo $res1; exit;
			$query = $callConfig->getRow($res1);
			//echo $query->email; exit;
			
			$callConfig->headerRedirect($getstatusurl."&err=updated successfully");
			//$callConfig->headerRedirect(SITEURL."/CustomerList/".$_GET['status']."?nextid=".$post['hidden_id']."&err=updated successfully");
		
		
	}
	function updatecomments($post)
	{
		global $callConfig;
		
		//$password=$callConfig->passwordEncrypt($pword);
		//print_r($_POST); die;
		$fieldnames=array('name'=>$post['hidden_name'],'comments'=>mysql_real_escape_string($post['comments']),'emp_id'=>$post['hidden_id'],'inserted_on'=>date('Y-m-d H:i:s',strtotime('+2 hours')));
		//print_r($fieldnames); die;
		$res=$callConfig->insertRecord(TPREFIX.TBL_COMMENTS_LIST,$fieldnames);
		
		if($res!=""){
		$_SESSION['err']="Customer Added successfully";
		$callConfig->headerRedirect(SITEURL."/CustomerList/".$_GET['status']."?nextid=".$post['hidden_id']);
		
		}
		else
		{
		$_SESSION['ferr']="Customer Added fail Try again";
		$callConfig->headerRedirect(SITEURL."/CustomerList/".$GET['status']);
		}

	}
	function updateLeadComments($post)
	{
		global $callConfig;

		//$password=$callConfig->passwordEncrypt($pword);
		//print_r($_POST); die;
		$fieldnames=array('comments'=>mysql_real_escape_string($post['description']));
		//print_r($fieldnames); die;
		$res=$callConfig->updateRecord(TPREFIX.TBL_COMMENTS_LIST,$fieldnames,'id',$post['hdn_id']);
		
		if($res!=""){
		$_SESSION['err']="Comments updated successfully";
		$callConfig->headerRedirect(SITEURL."/CustomerList/".$_GET['status']."?nextid=".$post['lead_id']);
	
		}
		else
		{
		$_SESSION['ferr']="Comments updated falied";
		$callConfig->headerRedirect(SITEURL."/CustomerList/".$GET['status']);
		}
	}	
	function getleadCount($id)	
	{		
	global $callConfig;		
	$whr="user_id='".$id."' and del='no'";		
	$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'count(*) as count',$whr,'','',''); 		
	$res = $callConfig->getRow($query);		
	return $res->count;	
	}
	function getDeleteLeadCount()
	{
		global $callConfig;		
	$whr=" del='yes'";		
	$query	= $callConfig->selectQuery(TPREFIX.TBL_CUSTOMER_LIST,'count(*) as count',$whr,'','',''); 		
	$res = $callConfig->getRow($query);		
	return $res->count;
	}
}
?>