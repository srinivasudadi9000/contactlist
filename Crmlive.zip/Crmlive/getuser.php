<?php
include('dbconfig.php');
include('includes/dbconnection.php');
include("model/user.class.php");
$userObj=new userClass;
//echo $_GET['empid'];exit;
if($_GET['empid']!="" && $_GET['ldid']!="")
{
echo $id=$userObj->updateemployee($_GET['empid'],$_GET['ldid']);
}

?>