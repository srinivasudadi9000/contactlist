<?php include("includes/header.php");
 include("includes/leftnav.php");
     
	
if($_POST['submit']=="Update")
{
	//print_r($_POST); exit;
	$update=$userObj->updateLeadProfile($_POST);
}
?>
	
	<?php  
	$qq=mysql_query("select * from crm_customer_list where id='".$_GET['id']."'");
				           $profile=mysql_fetch_object($qq); 
						   //print_r($res);
?>
    <div class="wrapper">
      
      


      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12" style="width:72%;">
              <!-- /.box -->
<div class="box">
 <div class="box-header">
                  <h3 class="box-title">Edit Lead Details</h3>
                </div>
<form method="post"  name="customer" action="" onSubmit="return validate();">
<div style="border:0px solid #d3d3d3;margin:auto;min-height: 829px;" >
  <table style="position:relative;margin:15px auto;color:#2f4f4f;font-family:calibri;padding-left:120px;padding-top:15px;">
   
    <tr>
      <td class="tablespacing1">Title:</td>
      <td class="tablespacing">
	  <select name="title" class="inputfieldswrap" >
		<option value="">--Title--</option>
		<option value="Mr" <?php if($profile->title=="Mr") {?> selected<?php } ?>>Mr</option>
		<option value="Mrs" <?php if($profile->title=="Mrs") {?> selected<?php } ?>>Mrs</option>
		<option value="Miss" <?php if($profile->title=="Miss") {?> selected<?php } ?>>Miss</option>
	</select>
	  </td>
        
    </tr>
       <tr>
      <td class="tablespacing1">First Name:</td>
      <td class="tablespacing"><input type="text" name="firstname" class="inputfieldswrap" id="firstname" value="<?php echo $profile->firstname;?>">
        
    </tr>
       
        <tr>
            <td class="tablespacing1"><label>Last Name:</label></td>
            <td class="tablespacing"><input type="text" name="lastname" class="inputfieldswrap" id="lastname" value="<?php echo $profile->lastname;?>">
             </td>
        </tr>
        <tr>
            <td class="tablespacing1"><label >Email:</label></td>
            <td class="tablespacing"><input type="text" class="text_large required inputfieldswrap" name="email" id="email" value="<?php echo $profile->email;?>" onChange="return checkemail(this.value);" >
            <label id="display" style="color:#F00; font-size:16px;padding:0px 0px 0px 0px;"></label>
            </td> 
            
        </tr>
        <tr>
            <td class="tablespacing1"><label>Mobile Number:</label></td>
            <td class="tablespacing"><input type="text" name="mobilenumber" id="mobilenumber"  value="<?php echo $profile->mobile_number;?>" class="inputfieldswrap" />
             </td>
        </tr>
         <tr>
            <td class="tablespacing1"><label>Phone Number:</label></td>
            <td class="tablespacing"><input type="text" name="phonenumber" class="inputfieldswrap" id="phonenumber" value="<?php echo substr($profile->phone_number,1);?>"  />
			
             </td>
        </tr>
		 <tr>
            <td class="tablespacing1"><label>Company:</label></td>
            <td class="tablespacing"><input type="text" name="company" class="inputfieldswrap" id="company" value="<?php echo $profile->company;?>"  />
			
             </td>
        </tr>
         <tr>
            <td class="tablespacing1"><label>Address:</label></td>
            <td class="tablespacing">
            <textarea name="address" id="address" class="inputfields1wrap" rows="6" cols="36" /><?php echo $profile->address;?></textarea>
					</td>
		 </tr>
		 <tr>
            <td class="tablespacing1"><label>Country</label></td>
            <td class="tablespacing"><input type="text" name="country" class="inputfieldswrap" id="country" value="<?php echo $profile->country;?>">
             </td>
        </tr>
		<tr>
            <td class="tablespacing1"><label>Town</label></td>
            <td class="tablespacing"><input type="text" name="town" class="inputfieldswrap" id="town" value="<?php echo $profile->town;?>">
             </td>
        </tr>
		<tr>
            <td class="tablespacing1"><label>Post Code</label></td>
            <td class="tablespacing"><input type="text" name="postcode" class="inputfieldswrap" id="postcode" value="<?php echo $profile->postcode;?>">
             </td>
        </tr>
				 
        
        <tr>
        	<td class="tablespacing1"></td>
			<input type="hidden" name="hdn_id" class="inputfieldswrap" id="hdn_id" value="<?php echo $profile->id;?>">
			<td class="tablespacing">
           <div class="reg_btn"><input type="submit" name="submit" value="Update"  class="btn btn-primary" style="width:100px;margin-top:20px;"></div>
            </td>
            
                              
                                <div class="clear_fix"></div>
                              
            </td>
        </tr>
    </table>
    </div>
</form>
</div>
              <!-- /.row -->
          </div>
             <?php include("includes/rightnav.php"); ?>
          </div>
        </section><!-- /.content -->

      </div><!-- /.content-wrapper -->
     
    </div><!-- ./wrapper -->
<script type="text/javascript">
        function checkemail(value)
		{
			
		var xmlhttp;
        if (window.XMLHttpRequest)
          {// code for IE7+, Firefox, Chrome, Opera, Safari
          xmlhttp=new XMLHttpRequest();
          }
        else
          {// code for IE6, IE5
          xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
          }
        xmlhttp.onreadystatechange=function()
        {
          if (xmlhttp.readyState==4 && xmlhttp.status==200)
          {
			  //alert(xmlhttp.responseText);

            var res=xmlhttp.responseText;
			if(res==1){
				document.getElementById("display").innerHTML="Email already exists";
				document.customer.email.value="";
				document.customer.email.focus();
			}
			else{
				document.getElementById("display").innerHTML="";
			}
			
			  }
          }
        xmlhttp.open("GET","checkusemail.php?emailid="+value,true);
		//alert("first");
		
        xmlhttp.send();
		
		}
		
	
		
	
</script>

<script type="text/javascript">
function validate()
{
	 
 if(document.customer.firstname.value=="")
	{
		alert("Please enter firstname");
		document.customer.firstname.value='';
		document.customer.firstname.focus();
		return false;
		
	}
	
 	 if(document.customer.lastname.value=="")
	{
		alert("Please enter lastname");
		document.customer.lastname.value='';
		document.customer.lastname.focus();
		return false;
		
	}
	
	 var phoneno1 = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/; 	
 	 if(document.customer.mobilenumber.value.match(phoneno1)==null)
	{
		alert("Please enter mobilenumber");
		document.customer.mobilenumber.value='';
		document.customer.mobilenumber.focus();
		return false;
		
	}
	 var phoneno = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/; 	
 	 if(document.customer.phonenumber.value.match(phoneno)==null)
	{
		alert("Please enter phonenumber");
		document.customer.phonenumber.value='';
		document.customer.phonenumber.focus();
		return false;
		
	}
		
 	 if(document.customer.address.value=="")
	{
		alert("Please enter address");
		document.customer.address.value='';
		document.customer.address.focus();
		return false;
		
	}
	if(document.customer.company.value=="")
	{
		alert("Please enter company");
		document.customer.company.value='';
		document.customer.company.focus();
		return false;
		
	}if(document.customer.country.value=="")
	{
		alert("Please enter country");
		document.customer.country.value='';
		document.customer.country.focus();
		return false;
		
	}if(document.customer.town.value=="")
	{
		alert("Please enter town");
		document.customer.town.value='';
		document.customer.town.focus();
		return false;
		
	}
	if(document.customer.postcode.value=="")
	{
		alert("Please enter postcode");
		document.customer.postcode.value='';
		document.customer.postcode.focus();
		return false;
		
	}
	return true;
	
}
</script>






