<?php 
include ('includes/headermeta.php');
$ipaddress=$userObj->getIpaddressList();
if($_POST['submit']=='submit')
{
	$userObj->updateIpaddress($_POST);
}

?>

<style>
.input_ip input{ width:46%; padding:11px;border: medium none; border-radius: 4px;}
.submit_ip {color:#367fa9; font-family:sans-serif; font-size:20px; font-weight:bold; height:35px; margin-top:12px; text-transform:uppercase; width: 12%;}
</style>
<body style="background-color:#d2d6de">

<div align="center" style="margin-top:250px;">
<?php 
if($_GET['err']!="")
{
	echo "<span style='background-color: green; color:white; padding:5px;'>".$_GET['err']."</span>";
	//unset($_SESSION['err']);
	header('refresh: 5; url='.SITEURL.'/ipaddress.php');
}
else if($_GET['ferr']!="")
{
	echo "<span style='background-color: red; color:white; padding:10px;'>".$_GET['ferr']."</span>";
	header('refresh: 5; url='.SITEURL.'/ipaddress.php');
	//unset($_SESSION['ferr']);
    
}
?>
<form action="" method="post">

<div><label>Add Multiple IP Address with Comma (Ex: XX.XX.XX.XX,XX.XX.XX.XX,...)</label></div>
<div class="input_ip"><input type="text" name="ipaddress" id="ipaddress" value="<?php echo $ipaddress->iplist?>"></div>
<div><input type="submit" name="submit" value="submit" class="submit_ip"></div>


</form>
</div>
</body>
<?php 
include ('includes/footer.php');
?>