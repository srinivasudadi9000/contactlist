<?php
include('dbconfig.php');
include('includes/dbconnection.php');
//echo $_POST['id']; exit;
if($_POST['id'])
{
$id=$_POST['id'];
$select = "select * from crm_user_login where id= '".$id."'";
$res = mysql_query($select);
while(
$sec = mysql_fetch_array($res)){
	//echo $sec['status']; exit;
	
//echo "UPDATE crm_user_login SET status='Inactive' WHERE id='".$id."'";exit;
if($sec['status']=='Inactive'){ 
 $update = "UPDATE crm_user_login SET status='Active' WHERE id='".$id."'"; 

}else {
$update = "UPDATE crm_user_login SET status='Inactive' WHERE id='".$id."'";
}
mysql_query($update);
}
}
?>

   