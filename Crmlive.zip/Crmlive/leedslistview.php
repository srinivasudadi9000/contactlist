<?php include("includes/header.php");
include("includes/leftnav.php");
$userObj->checkloggedin();
//$allleads1=$userObj->getAllleedslist();
$limit = 20;
isset($_GET['page'])?$page=$_GET['page']:$page=1;
$start = (($page-1)*$limit);	
$rec_count=count($allleads1);
//echo $rec_count;
$pagecount = ceil($rec_count/$limit);
//echo $pagecount;
//$data =$frontObj->getallnewsdata($start,$limit); 

$allleadsview=$userObj->getleedview($_GET['id']);
//print_r($allleadsview);
?>
    <script>
function gotoRequiredPage(pageId){

	window.location.replace("<?php print SITEURL ?>/Leads/"+pageId);
	}
</script>
<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>
 
    <script>
  var popup=jQuery.noConflict();
 </script>
  <script type="text/javascript" src="<?php print SITEURL?>/js/checkuncheckall.js"></script>
<script type="text/javascript">
popup(function() {
setTimeout(function() { $(".index_suc").fadeOut(1500); }, 5000)
setTimeout(function() { $(".index_err").fadeOut(1500); }, 5000)
});
</script>
<script>
function checkEmp(){
	
	if(document.getElementById("employeename").value=='')
  {
     alert("Please Select Employee");
	 document.leedlist.employeename.focus;
	 return false;
  }
	
	if( popup('input[name="leadsid[]"]:checked').length == 0 )
    {
        alert("You must check atleast one Leed to assign");
        return false;
    }

	}
</script>
        <!-- Main content -->
        <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-6">
              <!-- general form elements -->
             
                <!-- /.box-header -->
                <!-- form start -->
              <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
             Lead PROFILE
            
          </h1>
          <!--<ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Tables</a></li>
            <li class="active">Data tables</li>
          </ol>-->
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12" style="width:72%;">
                          <div class="box" style="min-height:846px;">
                <div class="box-header">
                  <h3 class="box-title">Lead Details</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table class="table table-bordered">
                    <tr>
                      <th>Name</th><td><?php print $allleadsview->firstname?></td>
                    </tr>
                    <tr>
                      <th>Last Name</th><td><?php print $allleadsview->lastname?></td>
                    </tr>
                    <tr><th>Email</th><td><?php print $allleadsview->email?></td></tr>
                     	<tr><th>Phone Number</th><td><?php print $allleadsview->phone_number?></td></tr>
                        <tr><th>Mobile Number</th><td><?php print $allleadsview->mobile_number?></td></tr>
                     	<tr><th>Address</th><td><?php print $allleadsview->address?></td></tr>
                     	<tr><th>Status</th><td><?php print $allleadsview->status?></td></tr>
                         
                  </table>
                   <div class="box-footer" style=" margin-left: 80%;"><tr><td><input type="button" name="button"  onclick="window.location.href='<?php print SITEURL?>/editleadprofile.php?id=<?php echo $allleadsview->id; ?>&page=<?php echo $_GET['page']?>'" value="Edit"  class="btn btn-primary"/> <input type="button" name="button"  onclick="window.location.href='<?php print SITEURL?>/Leads/<?php echo $_GET['page']?>'" value="Back" class="btn btn-primary"/></td></tr></div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
             <?php include("includes/rightnav.php"); ?>
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div>
             

              <!-- Form Element sizes -->
              <!-- /.box -->

              <!-- /.box -->

              <!-- Input addon -->
              <!-- /.box -->

            </div><!--/.col (left) -->
            
                      
            <!-- right column -->
            <!--/.col (right) -->
          </div>   <!-- /.row -->
        </section><!-- /.content -->
     
      
<?php  include("includes/footer.php");?>


