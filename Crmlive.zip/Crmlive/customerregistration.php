<?php include("includes/header.php");
include("includes/leftnav.php");
if($_POST['submit']=="submit")
{
	//print_r($_POST); die;
	$customerObj->customerRegistration($_POST);
}
?>

<script type="text/javascript" src="<?php print SITEURL?>js/fancy/lib/jquery-1.10.1.min.js"></script>

    <div class="wrapper">
      
      
      <!-- Left side column. contains the logo and sidebar -->
     

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
           Lead Registration
            
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Lead Registration</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-6" style="width:72%">
              <!-- general form elements -->
              <div class="box box-primary">
                <!-- /.box-header -->
                <!-- form start -->
              <form method="post"  name="customer" action="" class="form">
                  <div class="box-body">
                   <div class="form-group">
                      <label class="fieldname"  for="exampleInputEmail1">First Name</label>
                      <input type="text" class="form-control" name="firstname" id="fname" style="width:50%;" >
                      <label id="efname" style="visibility:hidden;color:red; margin-left: 121px; margin-top: 7px;">Please enter First Name</label>
                    </div>
                       <div class="form-group">
                      <label class="fieldname" for="exampleInputEmail1">Last Name</label>
                      <input type="text" class="form-control" name="lastname" id="lname"  style="width:50%;">
                      <label id="elname" style="visibility:hidden;color:red; margin-left: 121px; margin-top: 7px;">Please enter Last Name</label>
                    </div>
                    <div class="form-group">
                      <label class="fieldname" for="exampleInputEmail1">Email address</label>
                      <input type="email" class="form-control" id="email" name="email"  style="width:50%;" onChange="checkemail(this.value);" >
                        <label id="display" style="color:#F00; font-size:16px;padding:0px 0px 0px 0px;"></label>
                      <label id="eemail" style="visibility:hidden;color:red; margin-left: 121px; margin-top: 7px;">Please enter email</label>
                    </div>
  
                      <div class="form-group">
                      <label class="fieldname" for="exampleInputPassword1">Mobile Number</label>
                      <input type="text" class="form-control" id="mobile_number"  style="width:50%;"  name="mobile_number" >
                       <label id="emobile" style="visibility:hidden;color:red; margin-left: 121px; margin-top: 7px;">Please enter Mobile number</label>
                      
                    </div>

                     <div class="form-group">
                      <label  class="fieldname"for="exampleInputPassword1">Phone</label>
                      <input type="text" class="form-control" id="phone_number" name="phone_number"  style="width:50%;" >
                       <label id="ephone" style="visibility:hidden;color:red;margin-left: 121px; margin-top: 7px;">Enter valid Phone number</label>
                      
                    </div>
                     <div class="form-group">
                      <label  class="fieldname" for="exampleInputPassword1">Address</label>
                      <textarea rows="6" class="form-control" cols="36" name="address" id="address"   style="width:50%;"></textarea>
                      <label id="eaddress" style="visibility:hidden;color:red; margin-left: 121px; margin-top: 7px;">Enter Address</label>
                      
                    </div>
                    <div class="form-group">
                      <label class="fieldname" for="exampleInputPassword1">About Lead</label>
                      <textarea rows="6" class="form-control" cols="36" name="comments" id="comments"  style="width:50%;" ></textarea>
                      <label id="eaddr" style="visibility:hidden;color:red; margin-left: 121px; margin-top: 7px;">Please enter comments</label>
                      
                    </div>
                  </div><!-- /.box-body -->

                  <div class="box-footer">
                    <input type="submit"   name="submit" value="submit" class="btn btn-primary">
                  </div>
                </form>
              </div><!-- /.box -->

              <!-- Form Element sizes -->
              <!-- /.box -->

              <!-- /.box -->

              <!-- Input addon -->
              <!-- /.box -->

            </div><!--/.col (left) -->
            <?php include('includes/rightnav.php'); ?>
            <!-- right column -->
            <!--/.col (right) -->
          </div>   <!-- /.row -->
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
    
    <?php include('includes/footer.php');?>
 <script type="text/javascript">
        function checkemail(value)
		{
			
		var xmlhttp;
        if (window.XMLHttpRequest)
          {// code for IE7+, Firefox, Chrome, Opera, Safari
          xmlhttp=new XMLHttpRequest();
          }
        else
          {// code for IE6, IE5
          xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
          }
        xmlhttp.onreadystatechange=function()
        { //alert(value);
          if (xmlhttp.readyState==4 && xmlhttp.status==200)
          {
			  //alert(xmlhttp.responseText);
				if(xmlhttp.responseText==1){
					//alert(xmlhttp.responseText);
					document.getElementById("display").innerHTML="Email already exists";
					document.customer.email.value="";
					document.customer.email.focus();
				}
				else if(xmlhttp.responseText==2){
					document.getElementById("display").innerHTML="";
				}
			
		}
          }
        xmlhttp.open("GET","checkusemail.php?emailid="+value,false);
        xmlhttp.send();
		
		}
		
	
		
	
</script>


   
          
           
     
<script>
$(document).ready(function(){
	
	 $("#email").blur(function(){
 var remail=new RegExp("^[a-z0-9.]+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$");
 var email = $("#email").val();
 // alert(email);
 if(remail.test(email)){
		 // $("#email").css("border","1px solid #abadb3");
		$("#eemail").css("visibility","hidden");
		
		}
	else
	  {
	   //$("#email").css("border","1px solid red");
	  $("#eemail").css("visibility","visible");
	}
 });
 $("#email").keyup(function(){
 var remail=new RegExp("^[a-z0-9.]+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$");
 var email = $("#email").val();
 // alert(email);
 if(remail.test(email)){
		//$("#email").css("border","1px solid #abadb3)");
		$("#eemail").css("visibility","hidden");
		}
	else
	  {
	  //$("#email").css("border","1px solid red");
	  $("#eemail").css("visibility","visible");
	}
 });
 	$("#fname").blur(function(){
	var rfname=new RegExp("^[a-zA-Z ]{1,}$");
	var fname=$("#fname").val();
	if(rfname.test(fname)){
		
		//$("#fname").css("border","1px solid #abadb3)");
		$("#efname").css("visibility","hidden");
		}
	else
	  {
	
	   //$("#fname").css("border","1px solid red");
	  $("#efname").css("visibility","visible");
	}
  });
$("#fname").keyup(function(){
	var rfname=new RegExp("^[a-zA-Z ]{1,}$");
	var fname=$("#fname").val();
	if(rfname.test(fname)){
		
	//	$("#fname").css("border","1px solid #abadb3)");
		$("#efname").css("visibility","hidden");
		}
	else
	  {
	
	  // $("#fname").css("border","1px solid red");
	  $("#efname").css("visibility","visible");
	}
  });
	
 $("#lname").blur(function(){
	var rlname=new RegExp("^[a-zA-Z ]{1,}$");
	var lname=$("#lname").val();
	if(rlname.test(lname)){
		
		//$("#lname").css("border","1px solid #abadb3)");
		$("#elname").css("visibility","hidden");
		}
	else
	  {
	
	   //$("#lname").css("border","1px solid red");
	  $("#elname").css("visibility","visible");
	}
  });
$("#lname").keyup(function(){
	var rlname=new RegExp("^[a-zA-Z ]{1,}$");
	var lname=$("#lname").val();
	if(rlname.test(lname)){
		
		//$("#lname").css("border","1px solid #abadb3)");
		$("#elname").css("visibility","hidden");
		}
	else
	  {
	
	   //$("#lname").css("border","1px solid red");
	  $("#elname").css("visibility","visible");
	}
  });
  $("#phone_number").blur(function(){
 var rphone=new RegExp("^[0-9]{10}$");
 var phone = $("#phone_number").val();
 if(rphone.test(phone)){
	//	$("#phone_number").css("border","1px solid #abadb3)");
		$("#ephone").css("visibility","hidden");
		}
	else
	  {
	  // $("#phone_number").css("border","1px solid red");
	  $("#ephone").css("visibility","visible");
	}
 });
 $("#phone_number").keyup(function(){
 var rphone=new RegExp("^[0-9]{10}$");
 var phone = $("#phone_number").val();
 if(rphone.test(phone)){
		//$("#phone_number").css("border","1px solid #abadb3)");
		$("#ephone").css("visibility","hidden");
		}
	else
	  {
	   //$("#phone_number").css("border","1px solid red");
	  $("#ephone").css("visibility","visible");
	}
 });
 
 $("#mobile_number").blur(function(){
 var rmobile=new RegExp("^[0-9]{10}$");
 var mobile = $("#mobile_number").val();
 if(rmobile.test(mobile)){
		//$("#mobile_number").css("border","1px solid #abadb3)");
		$("#emobile").css("visibility","hidden");
		}
	else
	  {
	   //$("#mobile_number").css("border","1px solid red");
	  $("#emobile").css("visibility","visible");
	}
 });
 $("#mobile_number").keyup(function(){
 var rmobile=new RegExp("^[0-9]{10}$");
 var mobile = $("#mobile_number").val();
 if(rmobile.test(mobile)){
		//$("#mobile_number").css("border","1px solid #abadb3)");
		$("#emobile").css("visibility","hidden");
		}
	else
	  {
	   //$("#mobile_number").css("border","1px solid red");
	  $("#emobile").css("visibility","visible");
	}
 });
 
 
 $("#address").blur(function(){
 
 var address = $("#address").val();
 if(address!=''){
		//$("#address").css("border","1px solid #abadb3)");
		$("#eaddress").css("visibility","hidden");
		}
	else
	  {
	   //$("#address").css("border","1px solid red");
	  $("#eaddress").css("visibility","visible");
	}
 });
 $("#address").keyup(function(){
 
 var address = $("#address").val();
 if(address!=''){
		//$("#address").css("border","1px solid #abadb3)");
		$("#eaddress").css("visibility","hidden");
		}
	else
	  {
	   //$("#address").css("border","1px solid red");
	  $("#eaddress").css("visibility","visible");
	}
 });
 
 
 $("#comments").blur(function(){
 
 var addr = $("#comments").val();
 if(addr!=''){
		//$("#comments").css("border","1px solid #abadb3)");
		$("#eaddr").css("visibility","hidden");
		}
	else
	  {
	   //$("#comments").css("border","1px solid red");
	  $("#eaddr").css("visibility","visible");
	}
 });
 $("#comments").keyup(function(){
 
 var addr = $("#addr").val();
 if(addr!=''){
		//$("#comments").css("border","1px solid #abadb3)");
		$("#eaddr").css("visibility","hidden");
		}
	else
	  {
	   //$("#comments").css("border","1px solid red");
	  $("#eaddr").css("visibility","visible");
	}
 });
  

 
});

$("form").submit(function(event){
	var remail=new RegExp("^[a-z0-9.]+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$");
 var email = $("#email").val();
 
	var rfname=new RegExp("^[a-zA-Z ]{1,}$");
	var fname=$("#fname").val();
	var rlname=new RegExp("^[a-zA-Z ]{1,}$");
	var lname=$("#lname").val();
	var rphone=new RegExp("^[0-9]{10}$");
 var phone = $("#phone_number").val();
 var rmobile=new RegExp("^[0-9]{10}$");
 var mobile = $("#mobile_number").val();
  var addr = $("#comments").val();
  var address = $("#address").val();
 
 
	

var count=1;

 

if(addr!=''){
		//$("#comments").css("border","1px solid #abadb3)");
		$("#eaddr").css("visibility","hidden");
		}
	else
	  {
		  count=0;
	   //$("#comments").css("border","1px solid red");
	  $("#eaddr").css("visibility","visible");
	}
	if(address!=''){
		//$("#address").css("border","1px solid #abadb3)");
		$("#eaddress").css("visibility","hidden");
		}
	else
	  {
		  count=0;
	   //$("#address").css("border","1px solid red");
	  $("#eaddress").css("visibility","visible");
	}
	
	if(rmobile.test(phone)){
	//	$("#mobile_number").css("border","1px solid #abadb3)");
		$("#emobile").css("visibility","hidden");
		}
	else
	  {
		  count=0;
	  // $("#mobile_number").css("border","1px solid red");
	  $("#emobile").css("visibility","visible");
	}
 	

if(rphone.test(phone)){
		//$("#phone_number").css("border","1px solid #abadb3)");
		$("#ephone").css("visibility","hidden");
		}
	else
	  {
		  count=0;
	   //$("#phone_number").css("border","1px solid red");
	  $("#ephone").css("visibility","visible");
	}
 	
if(rlname.test(lname)){
		
		//$("#lname").css("border","1px solid #abadb3)");
		$("#elname").css("visibility","hidden");
		}
	else
	  {
	count=0;
	   //$("#lname").css("border","1px solid red");
	  $("#elname").css("visibility","visible");
	}
if(rfname.test(fname)){
		
		//$("#fname").css("border","1px solid #abadb3)");
		$("#efname").css("visibility","hidden");
		}
	else
	  {
	count=0;
	   //$("#fname").css("border","1px solid red");
	  $("#efname").css("visibility","visible");
	}
if(remail.test(email)){
		//$("#email").css("border","1px solid #abadb3)");
		$("#eemail").css("visibility","hidden");
		}
	else
	  {
	  count=0;
	   //$("#email").css("border","1px solid red");
	  $("#eemail").css("visibility","visible");
	}
	

	if(count==0)
	{
		event.preventDefault();
	
	}
 });

 

</script>
