<?php 

include("includes/headermeta.php");

include("includes/leftnav.php");

$userObj->checkloggedin();

$allcustomers1=$userObj->getAllemployeeslist();

//print_r($allcustomers1);  exit;



if ($_SERVER["REQUEST_METHOD"] == "POST") {

	$userObj->registerPaid($_POST);

	}

?>



          <div class="full_wrapper res_row">

            <div class="site_container">



               <?php include("includes/leftnav.php"); ?>

                 

                 <div class="banner_right">



                      <div class="dashboard_inner_wrapper">



                        <!--   <h4><img src="images/icons1_24.png"> DASHBOARD</h4>

                           <div class="graph_img"><img src="images/home_banner_11.png" class="res_images"></div>-->

                           <h4>Paid Business</h4>
                            <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Paid Business</li>
          </ol>

                               <?php 

							  

                         if($_SESSION['err']!="" )

                          {

						  	echo '<p class="index_suc">'.$_SESSION['err'].'</p>';

							unset($_SESSION['err']);

						  

						  }

						  else if($_SESSION['ferr']!="")

						  {

							echo '<p class="index_err">'.$_SESSION['ferr'].'</p>';

							unset($_SESSION['ferr']);

						  }

						  ?>

                       <div class="fullform">

                      

                      

<?php /*?>                      <?php include("importorderentry.php");?>

<?php */?>                      

                      <form id="paidbusiness" name="paidbusiness" method="post" action="">







   <table class="table_form" style="position:relative;margin:15px auto;color:#5a5f5f; font-family:'Open Sans', sans-serif; font-weight:400; font-size:14px; padding-top:15px;">

   <tr>

      <td >Employee  <span style="margin-left:40px;"></span></td>

      <td><select name="username" id="username" class="text_large required">

				<option  value="">Select</option>

	<?php 

 foreach ($allcustomers1 as $list) {

?>

					

				<option  value="<?php echo $list->username; ?>"><?php echo $list->username; ?></option>

		<?php }?>

		

		</select>

         <label id="euname" style="visibility:hidden;color:red;"> Please Select User </label></td>     

        

           

    </tr>

  

    <tr>

      <td >Amount   <span></span></td>

    <td>  <input type="text" name="amount" id="amount" />

        <label id="eamount" style="visibility:hidden;color:red;">Please enter Amount</label></td>

    </tr>

    <tr>

      <td>Period</td><span></span>

      <td><select id="month" name="month" class="text_short">

        <option value="">Select Month</option>

        <option value="1">Jan</option>

         <option value="2">Feb</option>

          <option value="3">Mar</option>

           <option value="4">Apr</option>

            <option value="5">May</option>

             <option value="6">Jun</option>

              <option value="7">Jul</option>

               <option value="8">Aug</option>

                <option value="9">Sep</option>

                 <option value="10">Oct</option>

                 <option value="11">Nov</option>

                 <option value="12">Dec</option>

        </select>

         <select id="year" name="year" class="text_short">

        <option value="">Select Year</option>

        <option value="2012">2012</option>

        <option value="2013">2013</option>

        <option value="2014">2014</option>

         <option value="2015">2015</option>

          <option value="2016">2016</option>

           <option value="2017">2017</option>

             <option value="2018">2018</option>

              <option value="2019">2019</option>
        
              
              
              <option value="2020">2020</option>

               <option value="2021">2021</option>

                <option value="2022">2022</option>

                 <option value="2023">2023</option>

                  <option value="2024">2024</option>

                   <option value="2025">2025</option>

                    <option value="2026">2026</option>

                     <option value="2027">2027</option>
                     
                      <option value="2028">2028</option>

                      <option value="2029">2029</option>

                       <option value="2030">2030</option>

                        <option value="2031">2031</option>

                         <option value="2032">2032</option>

                          <option value="2033">2033</option>

                           <option value="2034">2034</option>

                           <option value="2035">2035</option>

        </select>

        <label id="emonthyear" style="visibility:hidden;color:red;">Please Select Month & Year</label></td>

    </tr>

   

    <tr>

      <td>Written</td><span></span>

      <td>  <input type="text" class="text_large required" name="written" id="written" >

          

            <label id="ewritten" style="visibility:hidden;color:red;">Please Fill out this field</label></td>

    </tr>

   

      <tr>

            <td>Cleared</td><span></span>

            <td><input type="text" name="cleared" id="cleared"  />

             <label id="ecleared" style="visibility:hidden;color:red;">Please Fill out this field</label></td>

        </tr>

   

    <!-- </table>

  

 <table style="position:relative;left:200px;" >-->

  <tr><td></td><td>

  <div class="reg_btn" style="float:left;"><input type="submit" id="submit" value="submit" style="width:100px;margin-top:20px;"></div>

  

  

 <div class="reg_btn" style="float:left;margin-left:10px;"><input type="reset" value="clear" style="width:100px;margin-top:20px;"></div></td></tr>

</table>



</form>

</div>

</div>

                      

                      <!--<div class="calender_part">

                      

                          <div class="calender_img"><a href="to-do-list.php"><img src="images/calender_img_07.png"></a></div>

                          <div class="do_list_wrap">To do List</div>

                          <div class="today_wrapper">

                            

                            <h4>TODAY</h4>

                            <h1>FRIDAY</h1>

                            <ul class="food_timings">

                          

                               <li><a href="#">Lunch with John @3:30 <span><img src="images/delete_img_19.png"></span></a></li>

                               <li><a href="#">Coffee meeting with Leesa @4:30 <span><img src="images/delete_img_19.png"></span></a></li>

                               <li><a href="#">Skype Conf with Patrick @5:45 <span><img src="images/delete_img_19.png"></span></a></li>

                               <li><a href="#">Gym @ 7:00 <span><img src="images/delete_img_19.png"></span></a></li>

                               <li><a href="#">Dinner with daniel @9:30 <span><img src="images/delete_img_19.png"></span></a></li>

                            

                            <div class="clear_fix"></div>

                            </ul>

                          

                          </div>

                      

                      </div>-->

                      <?php include('includes/rightnav.php'); ?>

                      

                 

                 </div>	



                <div class="clear_fix"></div>



            </div>        

          </div>



<script>

$(document).ready(function(){

	 $("#written").blur(function(){

 var written = $("#written").val();

 // alert(written);

 if(written!=''){

		$("#written").css("background-color","#FFFFFF");

		$("#ewritten").css("visibility","hidden");

		

		}

	else

	  {

	   $("#written").css("background-color","#F5DADB");

	  $("#ewritten").css("visibility","visible");

	}

 });

 	 $("#written").keyup(function(){

 var written = $("#written").val();

 // alert(written);

 if(written!=''){

		$("#written").css("background-color","#FFFFFF");

		$("#ewritten").css("visibility","hidden");

		

		}

	else

	  {

	   $("#written").css("background-color","#F5DADB");

	  $("#ewritten").css("visibility","visible");

	}

 });



 

 	$("#amount").blur(function(){

	var amount=$("#amount").val();

	if(amount!=''){

		

		$("#amount").css("background-color","#FFFFFF");

		$("#eamount").css("visibility","hidden");

		}

	else

	  {

	

	   $("#amount").css("background-color","#F5DADB");

	  $("#eamount").css("visibility","visible");

	}

  });

  $("#amount").keyup(function(){

	var amount=$("#amount").val();

	if(amount!=''){

		

		$("#amount").css("background-color","#FFFFFF");

		$("#eamount").css("visibility","hidden");

		}

	else

	  {

	

	   $("#amount").css("background-color","#F5DADB");

	  $("#eamount").css("visibility","visible");

	}

  });



 

 $("#cleared").blur(function(){

 var cleared = $("#cleared").val();

 if(cleared!=''){

		$("#cleared").css("background-color","#FFFFFF");

		$("#ecleared").css("visibility","hidden");

		}

	else

	  {

	   $("#cleared").css("background-color","#F5DADB");

	  $("#ecleared").css("visibility","visible");

	}

 });

  $("#cleared").keyup(function(){

 var cleared = $("#cleared").val();

 if(cleared!=''){

		$("#cleared").css("background-color","#FFFFFF");

		$("#ecleared").css("visibility","hidden");

		}

	else

	  {

	   $("#cleared").css("background-color","#F5DADB");

	  $("#ecleared").css("visibility","visible");

	}

 });

 $("form").submit(function(event){

	

 var written = $("#written").val();

	var amount=$("#amount").val();

	 var cleared = $("#cleared").val();

	 	 var username = $("#username").val();

		var month = $("#month").val();

		var year = $("#year").val();



	



var count=1;



if(username!=''){

		

		$("#username").css("background-color","#FFFFFF");

		$("#euname").css("visibility","hidden");

		}

	else

	  {

	 count=0;

	   $("#username").css("background-color","#F5DADB");

	  $("#euname").css("visibility","visible");

	}

	if(month!=''){

		

		$("#month").css("background-color","#FFFFFF");

		$("#emonthyear").css("visibility","hidden");

		}

	else

	  {

	 count=0;

	   $("#month").css("background-color","#F5DADB");

	  $("#emonthyear").css("visibility","visible");

	}

		if(year!=''){

		

		$("#year").css("background-color","#FFFFFF");

		$("#emonthyear").css("visibility","hidden");

		}

	else

	  {

	 count=0;

	   $("#year").css("background-color","#F5DADB");

	  $("#emonthyear").css("visibility","visible");

	}

if(amount!=''){

		

		$("#amount").css("background-color","#FFFFFF");

		$("#eamount").css("visibility","hidden");

		}

	else

	  {

	 count=0;

	   $("#amount").css("background-color","#F5DADB");

	  $("#eamount").css("visibility","visible");

	}

	if(written!=''){

		$("#written").css("background-color","#FFFFFF");

		$("#ewritten").css("visibility","hidden");

		

		}

	else

	  {

		   count=0;

	   $("#written").css("background-color","#F5DADB");

	  $("#ewritten").css("visibility","visible");

	}

  if(cleared!=''){

		$("#cleared").css("background-color","#FFFFFF");

		$("#ecleared").css("visibility","hidden");

		}

	else

	  {

		  count=0;

	   $("#cleared").css("background-color","#F5DADB");

	  $("#ecleared").css("visibility","visible");

	}

	



	if(count==0)

	{

		event.preventDefault();

	

	}

 });



 

});



</script>





