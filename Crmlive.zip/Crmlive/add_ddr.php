 <?php 
 
include('dbconfig.php');
include('includes/dbconnection.php');

include("model/user.class.php");
include("model/customer.class.php");
include("model/employee.class.php");
$userObj=new userClass();
$getAllUsers = $userObj->getAllUsers();

 if($_POST['submit'] ) {
	$saveResult = $userObj->saveDDRForm($_POST);
	if($saveResult) {
		echo 'DDR  FORM Details saved successfully';
	}
 } 
 ?>
 <form method="post">
 <div class="form_blg">
 
            	<ul>
            	
                	<li>
                    	<div class="frmlist_blg">
                        	<div class="frmlist_left">
                            	<p>Company Name: </p>
                            </div><!--frmlist_left-->
                            <div class="frmlist_right">
                            	<input type="text" placeholder="" name="company_name">
                            	
                            	<input type="hidden" name="added_user_id" value="<?php echo $_SESSION['id'];?>">
                            </div><!--frmlist_right-->
                            <div class="clear_fix"></div>
                        </div><!--frmlist_blg-->
                    </li>
                    
                    <li>
                    	<div class="frmlist_blg">
                        	<div class="frmlist_left">
                            	<p>Dealer Name:  </p>
                            </div><!--frmlist_left-->
                            <div class="frmlist_right">
                            	<input type="text" placeholder="" name="dealer_name">
                            </div><!--frmlist_right-->
                            <div class="clear_fix"></div>
                        </div><!--frmlist_blg-->
                    </li>
                    <li>
                    	<div class="frmlist_blg">
                        	<div class="frmlist_left">
                            	<p>Date Dealt:  </p>
                            </div><!--frmlist_left-->
                            <div class="frmlist_right">
                            	<input type="text" placeholder="" name="date_dealt">
                            </div><!--frmlist_right-->
                            <div class="clear_fix"></div>
                        </div><!--frmlist_blg-->
                    </li>
                    <li>
                    	<div class="frmlist_blg">
                        	<div class="frmlist_left">
                            	<p>Client Name: </p>
                            </div><!--frmlist_left-->
                            <div class="frmlist_right">
                            	<input type="text" placeholder="" name="client_name">
                            </div><!--frmlist_right-->
                            <div class="clear_fix"></div>
                        </div><!--frmlist_blg-->
                    </li>
                    
                    <li>
                    	<div class="frmlist_blg">
                        	<div class="frmlist_left">
                            	<p>Address Line1:  </p>
                            </div><!--frmlist_left-->
                            <div class="frmlist_right">
                            	<input type="text" placeholder="" name="address_line1">
                            </div><!--frmlist_right-->
                            <div class="clear_fix"></div>
                        </div><!--frmlist_blg-->
                    </li>
                    <li>
                    	<div class="frmlist_blg">
                        	<div class="frmlist_left">
                            	<p>Address Line2:  </p>
                            </div><!--frmlist_left-->
                            <div class="frmlist_right">
                            	<input type="text" placeholder="" name="address_line2">
                            </div><!--frmlist_right-->
                            <div class="clear_fix"></div>
                        </div><!--frmlist_blg-->
                    </li>
                    <li>
                    	<div class="frmlist_blg">
                        	<div class="frmlist_left">
                            	<p>Post Code:  </p>
                            </div><!--frmlist_left-->
                            <div class="frmlist_right">
                            	<input type="text" placeholder="" name="post_code">
                            </div><!--frmlist_right-->
                            <div class="clear_fix"></div>
                        </div><!--frmlist_blg-->
                    </li>
                    <li>
                    	<div class="frmlist_blg">
                        	<div class="frmlist_left">
                            	<p>Phone Number:  </p>
                            </div><!--frmlist_left-->
                            <div class="frmlist_right">
                            	<input type="text" placeholder="" name="phone_number">
                            </div><!--frmlist_right-->
                            <div class="clear_fix"></div>
                        </div><!--frmlist_blg-->
                    </li>
                    <li>
                    	<div class="frmlist_blg">
                        	<div class="frmlist_left">
                            	<p>ID Number:  </p>
                            </div><!--frmlist_left-->
                            <div class="frmlist_right">
                            	<input type="text" placeholder="" name="id_number">
                            </div><!--frmlist_right-->
                            <div class="clear_fix"></div>
                        </div><!--frmlist_blg-->
                    </li>
                    <li>
                    	<div class="frmlist_blg">
                        	<div class="frmlist_left">
                            	<p>Product:  </p>
                            </div><!--frmlist_left-->
                            <div class="frmlist_right">
                            	<input type="text" placeholder="" name="product">
                            </div><!--frmlist_right-->
                            <div class="clear_fix"></div>
                        </div><!--frmlist_blg-->
                    </li>
                    
                    <li>
                    	<div class="frmlist_blg">
                        	<div class="frmlist_left">
                            	<p>Total Trade Value:  </p>
                            </div><!--frmlist_left-->
                            <div class="frmlist_right">
                            	<input type="text" placeholder="" name="total_trade_value">
                            </div><!--frmlist_right-->
                            <div class="clear_fix"></div>
                        </div><!--frmlist_blg-->
                    </li>
                    
                    <li>
                    	<div class="frmlist_blg">
                        	<div class="frmlist_left">
                            	<p>Alert me:  </p>
                                <span>(next – 1 hour or Time & date)</span>
                            </div><!--frmlist_left-->
                            <div class="frmlist_right">
                            	<input type="text" placeholder="" class="alert_blg" name="alert_time">
                            </div><!--frmlist_right-->
                            <div class="clear_fix"></div>
                        </div><!--frmlist_blg-->
                    </li>
                    
                    <li>
                    	<div class="frmlist_blg">
                        	<div class="frmlist_left">
                            	<p>Status:  </p>
                               
                            </div><!--frmlist_left-->
                            <div class="frmlist_right">
                            	<img src="images/green_06.png" alt="">
                                <span><input type="radio" name="status" value="Green"></span>
                                <img src="images/yellow_08.png" alt="">
                                <span><input type="radio" name="status" value="Yellow"></span>
                                <img src="images/red_03.png" alt="">
                                <span><input type="radio" name="status" value="Red"></span>
                                <input type="submit" value="Return to sender">
                            </div><!--frmlist_right-->
                            <div class="clear_fix"></div>
                        </div><!--frmlist_blg-->
                    </li>
                    
                     <li>
                    	<div class="frmlist_blg">
                        	<div class="frmlist_left">
                            	<p>Client Situation: :  </p>
                               
                            </div><!--frmlist_left-->
                            <div class="frmlist_right">
                            	<textarea name="client_situation"></textarea>
                                
                            </div><!--frmlist_right-->
                            <div class="clear_fix"></div>
                        </div><!--frmlist_blg-->
                    </li>
                    
                    
                     <li>
                    	<div class="frmlist_blg">
                        	<div class="frmlist_left">
                            	<p>Users :  </p>
                            </div><!--frmlist_left-->
                            
                            <div class="frmlist_right">
                            <select name="receive_user_id">
							<?php
							    foreach($getAllUsers as $row) {
							    	$val = $row->id;
							    	echo '<option value="'.$row->id.'">'.$row->firstname.' '.$row->lastname.'</option>';
							    }
							?>
							</select>
							  <div class="clear_fix"></div><br/>
                                <input type="submit" value="Edit" class="edit_btn">
                                <input type="submit" value="Save" class="edit_btn">
                                <input type="hidden" name="submit" value="1">
                                <input type="submit" value="Send To User" class="edit_btn">
                            </div><!--frmlist_right-->
                            <div class="clear_fix"></div>
                        </div><!--frmlist_blg-->
                    </li>
                    
                </ul>
            </div><!--form_blg-->
</form>