 angular.module('myApp', []).controller('namesCtrl', function($scope,$http) {
    $scope.names = [
        {name:'Jani',country:'Norway'},
        {name:'Hege',country:'Sweden'},
        {name:'Kai',country:'Denmark'}
    ];
    var refresh= function(){
    	$http.get('/contactlist/').success(function(response){
    	console.log("I god i req");
    	$scope.contactlist = response;
    	$scope.contact="";
    });
    };
    
   refresh();
   $scope.addContact = function(){
   	console.log($scope.contact);
   	// $http.post('/contactlist',$scope.contact);
   	$http.post('/contactlist/',$scope.contact).success(function(response){
   		console.log(response);
   		 refresh();
   	});
   }

   $scope.remove = function(id){
   	 console.log(id);
      $http.delete('/contactlist/'+id);
      refresh();
   }

   $scope.edit=function(id){
   	console.log('goooosadofasdfosadif    '+id);
       $http.get('/contactlist/'+id).success(function(response){
                 $scope.contact=response;
                 console.log(response);
      }); 
     
   }
   
   $scope.update = function(){
   	 console.log('good srinivas  '+$scope.contact._id);
	 
	/* $http.put('/contactlist/'+$scope.contact._id).success(function(response){
                 $scope.contact=response;
                 console.log(response);
      }); */
       $http.put('/contactlist/'+$scope.contact._id,$scope.contact).success(function(response){
            refresh();
       });
    
   }

   $scope.deselect=function(){
   	  $scope.contact="";
   }

}); 
 
